import { lazy, Suspense } from "react";
import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "next-themes";
import NotFound from "@/pages/not-found";

import Landing from "@/pages/Landing";
import StudentLogin from "@/pages/StudentLogin";
import CompanyLogin from "@/pages/CompanyLogin";
import StudentSignup from "@/pages/StudentSignup";
import CompanySignup from "@/pages/CompanySignup";
import StudentOnboarding from "@/pages/StudentOnboarding";
import StudentDashboard from "@/pages/StudentDashboard";
import SkillGap from "@/pages/SkillGap";
import ResumeAnalyzer from "@/pages/ResumeAnalyzer";
import LearningPath from "@/pages/LearningPath";
import Projects from "@/pages/Projects";
import Jobs from "@/pages/Jobs";
import CompanyDashboard from "@/pages/CompanyDashboard";
import CompanyTalentPool from "@/pages/CompanyTalentPool";
import CompanyPostProject from "@/pages/CompanyPostProject";
import CompanyPostJob from "@/pages/CompanyPostJob";
import CompanyApplications from "@/pages/CompanyApplications";
import CompanySubmissions from "@/pages/CompanySubmissions";
import Profile from "@/pages/Profile";
import Mentors from "@/pages/Mentors";
const SkillLab = lazy(() => import("@/pages/SkillLab"));

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
    },
  },
});

function Router() {
  return (
    <Switch>
      <Route path="/" component={Landing} />
      <Route path="/login/student" component={StudentLogin} />
      <Route path="/login/company" component={CompanyLogin} />
      <Route path="/signup/student" component={StudentSignup} />
      <Route path="/signup/company" component={CompanySignup} />
      <Route path="/onboarding/student" component={StudentOnboarding} />
      <Route path="/student-dashboard" component={StudentDashboard} />
      <Route path="/skill-gap" component={SkillGap} />
      <Route path="/resume-analyzer" component={ResumeAnalyzer} />
      <Route path="/learning-path" component={LearningPath} />
      <Route
        path="/skill-lab"
        component={() => (
          <Suspense fallback={<div className="p-6 text-sm text-muted-foreground">Loading Skill Lab…</div>}>
            <SkillLab />
          </Suspense>
        )}
      />
      <Route path="/projects" component={Projects} />
      <Route path="/jobs" component={Jobs} />
      <Route path="/company-dashboard" component={CompanyDashboard} />
      <Route path="/company-talent-pool" component={CompanyTalentPool} />
      <Route path="/company-post-project" component={CompanyPostProject} />
      <Route path="/company-post-job" component={CompanyPostJob} />
      <Route path="/company-applications" component={CompanyApplications} />
      <Route path="/company-submissions" component={CompanySubmissions} />
      <Route path="/profile" component={Profile} />
      <Route path="/mentors" component={Mentors} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false}>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
