import { useEffect, useMemo, useRef, useState } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { useListProjects, useApplyToProject, getListProjectsQueryKey } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Sparkles } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { demoProjects } from "@/lib/demo-data";
import { fetchProjectsFromSupabase } from "@/lib/supabase/data";
import {
  applyToProjectLocal,
  computeBoostPercent,
  computeMatchScore,
  computeWhyThisProject,
  loadAppliedProjects,
  loadMissingSkillsFromStorage,
  loadUserSkillsFromStorage,
  updateProjectStatusLocal,
  upsertProjectGithubRepoLocal,
  type AppliedProjectRecord,
} from "@/lib/project-marketplace";
import { incrementReadinessScore } from "@/lib/student-consistency";
import { calculateSubmissionScore } from "@/lib/project-scoring";
import { ApplySuccessModal } from "@/components/projects-marketplace/ApplySuccessModal";
import { ProjectCard, type MarketplaceProject } from "@/components/projects-marketplace/ProjectCard";
import { ProjectSubmissionModal } from "@/components/projects-marketplace/ProjectSubmissionModal";
import { submitGithubProof } from "@/lib/supabase/hiring";
import { ensureCurrentStudentIdForSession, getCurrentStudentId } from "@/lib/current-student";

export default function Projects() {
  const [skillFilter, setSkillFilter] = useState<string>("");
  const [difficultyFilter, setDifficultyFilter] = useState<string>("all");
  const [matchFilter, setMatchFilter] = useState<string>("all");
  const [gapRelevance, setGapRelevance] = useState<string>("all");
  const [durationFilter, setDurationFilter] = useState<string>("all");
  
  const { data, isLoading, isError } = useListProjects(
    { skill: skillFilter || undefined, difficulty: difficultyFilter !== 'all' ? difficultyFilter : undefined },
    { query: { queryKey: getListProjectsQueryKey({ skill: skillFilter, difficulty: difficultyFilter }) } }
  );

  const applyMutation = useApplyToProject();
  const { toast } = useToast();
  const [supabaseProjects, setSupabaseProjects] = useState<typeof demoProjects | null>(null);
  const [applied, setApplied] = useState<AppliedProjectRecord[]>(() => loadAppliedProjects());
  const [applyModalOpen, setApplyModalOpen] = useState(false);
  const [submissionOpen, setSubmissionOpen] = useState(false);
  const myProjectsRef = useRef<HTMLDivElement | null>(null);

  const projectList =
    (Array.isArray(supabaseProjects) && supabaseProjects.length > 0 && supabaseProjects) ||
    (Array.isArray(data) && data.length > 0 ? data : demoProjects);

  const userSkills = useMemo(() => loadUserSkillsFromStorage(), [localAnalysisKeyBump(applied.length)]);
  const missingSkills = useMemo(() => loadMissingSkillsFromStorage(), [localAnalysisKeyBump(applied.length)]);

  const enriched = useMemo(() => {
    const appliedMap = new Map(applied.map((r) => [r.projectId, r]));
    return (projectList as MarketplaceProject[]).map((p) => {
      const { matchPercent, missingSkill } = computeMatchScore(p.requiredSkills ?? [], userSkills);
      const industry = projectIndustry(p.title);
      const useCase = projectUseCase(p.title);
      const boostPercent = computeBoostPercent(p.difficulty);
      const why = computeWhyThisProject({
        requiredSkills: p.requiredSkills ?? [],
        missingSkills,
        industryUseCase: useCase,
      });
      const isGapRelevant = (p.requiredSkills ?? []).some((s) =>
        missingSkills.map((x) => x.toLowerCase()).includes(s.toLowerCase())
      );
      const record = appliedMap.get(p.id) ?? null;
      return {
        project: p,
        matchPercent,
        missingSkill,
        industry,
        useCase,
        boostPercent,
        why,
        isGapRelevant,
        appliedRecord: record,
      };
    });
  }, [applied, projectList, userSkills, missingSkills]);

  const filtered = useMemo(() => {
    const minMatch =
      matchFilter === "80" ? 80 : matchFilter === "60" ? 60 : matchFilter === "40" ? 40 : 0;

    return enriched
      .filter(({ project, matchPercent, isGapRelevant }) => {
        const matchesSkill =
          !skillFilter ||
          (project.requiredSkills ?? []).some((skill) => skill.toLowerCase().includes(skillFilter.toLowerCase()));
        const matchesDifficulty = difficultyFilter === "all" || project.difficulty === difficultyFilter;
        const matchesMatch = matchPercent >= minMatch;
        const matchesGap =
          gapRelevance === "all" ? true : gapRelevance === "relevant" ? isGapRelevant : !isGapRelevant;
        const matchesDuration = durationMatches(project.duration, durationFilter);
        return matchesSkill && matchesDifficulty && matchesMatch && matchesGap && matchesDuration;
      })
      .sort((a, b) => b.matchPercent - a.matchPercent);
  }, [enriched, skillFilter, difficultyFilter, matchFilter, gapRelevance, durationFilter]);

  const myProjects = useMemo(() => filtered.filter((x) => x.appliedRecord), [filtered]);
  const recommended = useMemo(() => {
    return filtered
      .filter((x) => !x.appliedRecord)
      .sort((a, b) => {
        const ar = (a.isGapRelevant ? 1000 : 0) + a.matchPercent;
        const br = (b.isGapRelevant ? 1000 : 0) + b.matchPercent;
        return br - ar;
      })
      .slice(0, 3);
  }, [filtered]);

  useEffect(() => {
    ensureCurrentStudentIdForSession();
  }, []);

  useEffect(() => {
    const loadProjects = async () => {
      const rows = await fetchProjectsFromSupabase();
      if (rows && rows.length > 0) setSupabaseProjects(rows);
    };
    void loadProjects();
  }, []);

  const refreshApplied = () => setApplied(loadAppliedProjects());

  const handleApply = (projectId: number) => {
    const local = applyToProjectLocal(projectId);
    refreshApplied();

    if (!local.created) {
      toast({ title: "Already applied", description: "You’ve already applied to this project." });
      return;
    }

    // Keep existing API call in background if available, but localStorage is the source of truth for the demo.
    applyMutation.mutate({
      id: projectId,
      data: { studentId: getCurrentStudentId(), message: "I am interested in this project." },
    });

    toast({ title: "Applied", description: "Saved to My Projects. Track progress and submit your repo." });
    setApplyModalOpen(true);
  };

  const handleStatusChange = (projectId: number, status: "Not Started" | "In Progress" | "Completed") => {
    updateProjectStatusLocal(projectId, status);
    refreshApplied();
    toast({ title: "Status updated", description: `Project marked as ${status}.` });
  };

  const handleSubmitRepo = (projectId: number, url: string) => {
    upsertProjectGithubRepoLocal(projectId, url.trim());
    refreshApplied();
    toast({ title: "Repo submitted", description: "Saved your GitHub repo link for verification." });
  };

  const handleMarkCompleted = (projectId: number, boostPercent: number) => {
    updateProjectStatusLocal(projectId, "Completed");
    refreshApplied();
    incrementReadinessScore(boostPercent);
    toast({ title: "Project completed!", description: `Readiness increased (+${boostPercent}).` });
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Project Marketplace</h1>
            <p className="text-muted-foreground">Build your portfolio with real industry projects.</p>
          </div>
          <Button
            variant="outline"
            className="border-primary/30"
            onClick={() => setSubmissionOpen(true)}
          >
            Submit GitHub Proof
          </Button>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 bg-card p-4 rounded-xl border border-border">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Filter by skill (e.g. React, Python)" 
              className="pl-9"
              value={skillFilter}
              onChange={(e) => setSkillFilter(e.target.value)}
              data-testid="filter-skill"
            />
          </div>
          <Select value={difficultyFilter} onValueChange={setDifficultyFilter}>
            <SelectTrigger className="w-full sm:w-[200px]" data-testid="filter-difficulty">
              <SelectValue placeholder="Difficulty" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Levels</SelectItem>
              <SelectItem value="Beginner">Beginner</SelectItem>
              <SelectItem value="Intermediate">Intermediate</SelectItem>
              <SelectItem value="Advanced">Advanced</SelectItem>
            </SelectContent>
          </Select>
          <Select value={matchFilter} onValueChange={setMatchFilter}>
            <SelectTrigger className="w-full sm:w-[200px]">
              <SelectValue placeholder="Match %" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Any Match</SelectItem>
              <SelectItem value="80">80%+</SelectItem>
              <SelectItem value="60">60%+</SelectItem>
              <SelectItem value="40">40%+</SelectItem>
            </SelectContent>
          </Select>
          <Select value={gapRelevance} onValueChange={setGapRelevance}>
            <SelectTrigger className="w-full sm:w-[220px]">
              <SelectValue placeholder="Skill gap relevance" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Projects</SelectItem>
              <SelectItem value="relevant">Matches Skill Gap</SelectItem>
              <SelectItem value="not_relevant">Not Skill Gap</SelectItem>
            </SelectContent>
          </Select>
          <Select value={durationFilter} onValueChange={setDurationFilter}>
            <SelectTrigger className="w-full sm:w-[200px]">
              <SelectValue placeholder="Duration" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Any Duration</SelectItem>
              <SelectItem value="short">≤ 2 weeks</SelectItem>
              <SelectItem value="mid">3–4 weeks</SelectItem>
              <SelectItem value="long">5+ weeks</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-64 w-full" />)}
          </div>
        ) : (
          <div className="space-y-10">
            <ApplySuccessModal
              open={applyModalOpen}
              onOpenChange={setApplyModalOpen}
              onGoToMyProjects={() => {
                setApplyModalOpen(false);
                myProjectsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
              }}
            />
            <ProjectSubmissionModal
              open={submissionOpen}
              onOpenChange={setSubmissionOpen}
              onSubmit={async ({ projectTitle, githubLink, skillTag }) => {
                try {
                  await submitGithubProof({ projectTitle, githubLink, skillTag });
                  const autoScore = calculateSubmissionScore(githubLink, projectTitle);
                  if (autoScore > 70) incrementReadinessScore(10);
                  toast({
                    title: "Submitted",
                    description:
                      autoScore > 70
                        ? `Sent for review. Auto project score ${autoScore}/100 — readiness +10 for a strong submission.`
                        : `Sent for admin verification review. Project score ${autoScore}/100.`,
                  });
                  setSubmissionOpen(false);
                } catch (e: any) {
                  toast({ title: "Submission failed", description: e?.message ?? "Please try again." });
                }
              }}
            />

            {myProjects.length > 0 ? (
              <div ref={myProjectsRef} className="space-y-4">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-primary" />
                  <h2 className="text-xl font-semibold">My Projects</h2>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {myProjects.map((x) => (
                    <ProjectCard
                      key={`my-${x.project.id}`}
                      project={x.project}
                      matchPercent={x.matchPercent}
                      missingSkill={x.missingSkill}
                      whyThisProject={x.why}
                      boostPercent={x.boostPercent}
                      industry={x.industry}
                      useCase={x.useCase}
                      appliedRecord={x.appliedRecord}
                      onApply={() => {}}
                      onStatusChange={(s) => handleStatusChange(x.project.id, s)}
                      onSubmitRepo={(url) => handleSubmitRepo(x.project.id, url)}
                      onMarkCompleted={() => handleMarkCompleted(x.project.id, x.boostPercent)}
                      recommended
                    />
                  ))}
                </div>
              </div>
            ) : null}

            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-primary" />
                <h2 className="text-xl font-semibold">Recommended for You</h2>
              </div>
              <div className="text-sm text-muted-foreground">
                Based on your skills + your latest skill gap analysis.
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {recommended.length === 0 ? (
                  <div className="col-span-full py-10 text-center text-muted-foreground bg-secondary/20 rounded-xl border border-dashed border-border">
                    No recommendations found. Try lowering filters or run Skill Gap Analysis.
                  </div>
                ) : (
                  recommended.map((x) => (
                    <ProjectCard
                      key={`rec-${x.project.id}`}
                      project={x.project}
                      matchPercent={x.matchPercent}
                      missingSkill={x.missingSkill}
                      whyThisProject={x.why}
                      boostPercent={x.boostPercent}
                      industry={x.industry}
                      useCase={x.useCase}
                      appliedRecord={x.appliedRecord}
                      onApply={() => handleApply(x.project.id)}
                      onStatusChange={(s) => handleStatusChange(x.project.id, s)}
                      onSubmitRepo={(url) => handleSubmitRepo(x.project.id, url)}
                      onMarkCompleted={() => handleMarkCompleted(x.project.id, x.boostPercent)}
                      recommended
                    />
                  ))
                )}
              </div>
            </div>

            <div className="space-y-4">
              <h2 className="text-xl font-semibold">All Projects</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filtered.length === 0 ? (
                  <div className="col-span-full py-12 text-center text-muted-foreground bg-secondary/20 rounded-xl border border-dashed border-border">
                    No projects found matching your criteria.
                  </div>
                ) : (
                  filtered.map((x) => (
                    <ProjectCard
                      key={x.project.id}
                      project={x.project}
                      matchPercent={x.matchPercent}
                      missingSkill={x.missingSkill}
                      whyThisProject={x.why}
                      boostPercent={x.boostPercent}
                      industry={x.industry}
                      useCase={x.useCase}
                      appliedRecord={x.appliedRecord}
                      onApply={() => handleApply(x.project.id)}
                      onStatusChange={(s) => handleStatusChange(x.project.id, s)}
                      onSubmitRepo={(url) => handleSubmitRepo(x.project.id, url)}
                      onMarkCompleted={() => handleMarkCompleted(x.project.id, x.boostPercent)}
                      recommended={x.isGapRelevant}
                    />
                  ))
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}

function durationMatches(durationText: string, filter: string) {
  if (filter === "all") return true;
  const weeks = parseWeeks(durationText);
  if (weeks == null) return true;
  if (filter === "short") return weeks <= 2;
  if (filter === "mid") return weeks >= 3 && weeks <= 4;
  if (filter === "long") return weeks >= 5;
  return true;
}

function parseWeeks(durationText: string) {
  const m = durationText.match(/(\d+)\s*week/i);
  if (!m) return null;
  const n = Number(m[1]);
  return Number.isFinite(n) ? n : null;
}

function projectIndustry(title: string) {
  const t = title.toLowerCase();
  if (t.includes("analytics") || t.includes("admin") || t.includes("dashboard")) return "SaaS";
  if (t.includes("campus") || t.includes("mentor") || t.includes("event")) return "EdTech";
  if (t.includes("portfolio") || t.includes("resume")) return "Career";
  return "SaaS";
}

function projectUseCase(title: string) {
  const t = title.toLowerCase();
  if (t.includes("analytics") || t.includes("admin") || t.includes("dashboard"))
    return "Used in SaaS dashboards for analytics platforms and internal ops tools";
  if (t.includes("campus") || t.includes("event"))
    return "Used for event registration flows, schedules, and community updates in student platforms";
  if (t.includes("mentor"))
    return "Used in marketplace-style matching systems (mentors, freelancers, cohorts)";
  if (t.includes("portfolio"))
    return "Used to present proof-of-work to recruiters with measurable outcomes and strong UX polish";
  return "Used in real-world product teams to ship portfolio-grade features";
}

function localAnalysisKeyBump(n: number) {
  // tiny helper to keep useMemo dependency stable but reactive
  return n;
}
