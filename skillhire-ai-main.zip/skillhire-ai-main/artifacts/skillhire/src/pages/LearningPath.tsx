import { useEffect, useState } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { useGetStudentDashboard, getGetStudentDashboardQueryKey } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import { demoStudentDashboard } from "@/lib/demo-data";
import { loadSkillGapResult } from "@/lib/skill-gap";
import { getScopedStorageKey } from "@/lib/session-scope";
import { ProgressBar } from "@/components/learning-path/ProgressBar";
import { LearningStepCard } from "@/components/learning-path/LearningStepCard";
import { useToast } from "@/hooks/use-toast";
import { incrementReadinessScore } from "@/lib/student-consistency";
import { ensureCurrentStudentIdForSession, getCurrentStudentId } from "@/lib/current-student";

function getW3SchoolsLinkForTitle(title: string): string | null {
  const t = title.toLowerCase();
  if (t.includes("node")) return "https://www.w3schools.com/nodejs/";
  if (t.includes("sql") || t.includes("database")) return "https://www.w3schools.com/sql/";
  if (t.includes("rest") || t.includes("api")) return "https://www.w3schools.com/js/js_api_intro.asp";
  if (t.includes("javascript")) return "https://www.w3schools.com/js/";
  if (t.includes("typescript")) return "https://www.w3schools.com/typescript/";
  if (t.includes("react")) return "https://www.w3schools.com/react/";
  if (t.includes("html")) return "https://www.w3schools.com/html/";
  if (t.includes("css")) return "https://www.w3schools.com/css/";
  if (t.includes("git")) return "https://www.w3schools.com/git/";
  if (t.includes("python")) return "https://www.w3schools.com/python/";
  return null;
}

export default function LearningPath() {
  useEffect(() => {
    ensureCurrentStudentIdForSession();
  }, []);

  const studentId = getCurrentStudentId();

  const { data, isLoading, isError } = useGetStudentDashboard(studentId, {
    query: {
      enabled: true,
      queryKey: getGetStudentDashboardQueryKey(studentId),
    },
  });

  const [completedStepIds, setCompletedStepIds] = useState<number[]>([]);
  const learningCompletedKey = getScopedStorageKey("skillhire_learning_completed");
  const learningInProgressKey = getScopedStorageKey("skillhire_learning_in_progress");
  const [inProgressStepId, setInProgressStepId] = useState<number | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const stored = localStorage.getItem(learningCompletedKey);
    if (stored) {
      try {
        const parsed = JSON.parse(stored) as number[];
        if (Array.isArray(parsed)) setCompletedStepIds(parsed);
      } catch {
        // Ignore malformed local state.
      }
    }
  }, [learningCompletedKey]);

  useEffect(() => {
    const stored = localStorage.getItem(learningInProgressKey);
    if (stored) {
      const n = Number(stored);
      if (!Number.isNaN(n)) setInProgressStepId(n);
    }
  }, [learningInProgressKey]);

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="space-y-6">
          <Skeleton className="h-10 w-64" />
          <Skeleton className="h-4 w-96 mb-8" />
          {[1, 2, 3, 4].map(i => (
            <Skeleton key={i} className="h-24 w-full" />
          ))}
        </div>
      </DashboardLayout>
    );
  }

  const savedGap = loadSkillGapResult();
  const learningPath =
    savedGap?.learningPath?.length
      ? savedGap.learningPath
      : !isError && data?.learningPath?.length
      ? data.learningPath
      : demoStudentDashboard.learningPath;
  const mergedPath = learningPath.map((step) => ({
    ...step,
    completed: step.completed || completedStepIds.includes(step.step),
  }));

  // Calculate progress
  const completedSteps = mergedPath.filter(step => step.completed).length;
  const totalSteps = mergedPath.length;
  const progressPercent = totalSteps > 0 ? Math.round((completedSteps / totalSteps) * 100) : 0;

  const handleMarkCompleted = (stepId: number) => {
    setCompletedStepIds((prev) => {
      if (prev.includes(stepId)) return prev;
      const next = [...prev, stepId];
      localStorage.setItem(learningCompletedKey, JSON.stringify(next));
      return next;
    });

    if (inProgressStepId === stepId) {
      setInProgressStepId(null);
      localStorage.removeItem(learningInProgressKey);
    }

    const points = stepId === 1 ? 10 : 5;
    incrementReadinessScore(points);
    toast({ title: "Step Completed!", description: `Readiness Score Increased (+${points})` });
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {isError ? (
          <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-sm text-muted-foreground">
            Learning path API is unavailable. Using your saved Skill Gap path and demo steps.
          </div>
        ) : null}
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Your Learning Path</h1>
          <p className="text-muted-foreground mt-2 max-w-2xl">
            A step-by-step roadmap to bridge your skill gap and become industry-ready. Follow these tailored recommendations.
          </p>
        </div>

        <ProgressBar progressPercent={progressPercent} completedSteps={completedSteps} totalSteps={totalSteps} />

        <div className="relative pl-6 md:pl-8 space-y-6 before:absolute before:inset-0 before:left-[19px] md:before:left-[27px] before:w-[2px] before:bg-border before:-z-10">
          {mergedPath.map((step, index) => {
            const isCompleted = step.completed;
            const isNext = !isCompleted && (index === 0 || mergedPath[index-1]?.completed);
            const isLocked = !isCompleted && !isNext;
            const status =
              isCompleted
                ? "completed"
                : inProgressStepId === step.step
                ? "in_progress"
                : isLocked
                ? "locked"
                : "unlocked";
            const link = getW3SchoolsLinkForTitle(step.title);
            
            return (
              <div key={step.step} className={cn(
                "relative group",
                !isCompleted && !isNext ? "opacity-60" : ""
              )}>
                {/* Timeline node */}
                <div className={cn(
                  "absolute -left-10 md:-left-12 w-8 h-8 rounded-full flex items-center justify-center border-2 bg-background z-10 transition-all",
                  isCompleted ? "border-primary text-primary shadow-[0_0_18px_rgba(16,185,129,0.18)]" : 
                  isNext ? "border-primary bg-primary/10 text-primary" : 
                  "border-muted text-muted-foreground"
                )}>
                  {isCompleted ? (
                    <span className="text-xs font-bold">✓</span>
                  ) : (
                    <span className="text-xs font-bold">{step.step}</span>
                  )}
                </div>

                <LearningStepCard
                  stepNumber={step.step}
                  title={step.title}
                  type={step.type}
                  estimatedDuration={step.estimatedDuration}
                  description={step.description}
                  link={link}
                  status={status}
                  isNext={isNext}
                  onStartLearning={() => {
                    if (isLocked) return;
                    if (link) window.open(link, "_blank", "noopener,noreferrer");
                    setInProgressStepId(step.step);
                    localStorage.setItem(learningInProgressKey, String(step.step));
                  }}
                  onMarkCompleted={() => handleMarkCompleted(step.step)}
                />
              </div>
            );
          })}
        </div>
      </div>
    </DashboardLayout>
  );
}
