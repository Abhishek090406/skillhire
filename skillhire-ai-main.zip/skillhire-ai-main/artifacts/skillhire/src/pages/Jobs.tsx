import { useEffect, useMemo, useState } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { useListJobs, useApplyToJob, getListJobsQueryKey } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { demoJobs } from "@/lib/demo-data";
import { fetchJobsFromSupabase } from "@/lib/supabase/data";
import { ApplyModal } from "@/components/jobs-workflow/ApplyModal";
import { JobCard, type MarketplaceJob } from "@/components/jobs-workflow/JobCard";
import {
  computeJobMatch,
  computeWhyMatch,
  getApplicationForJob,
  getUserSkillsForMatching,
  loadApplications,
  submitJobApplication,
  type JobApplication,
} from "@/lib/hiring-workflow";
import { ensureCurrentStudentIdForSession, getCurrentStudentId } from "@/lib/current-student";

export default function Jobs() {
  const [skillFilter, setSkillFilter] = useState<string>("");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [applyOpen, setApplyOpen] = useState(false);
  const [activeJob, setActiveJob] = useState<MarketplaceJob | null>(null);
  const [applications, setApplications] = useState<JobApplication[]>(() => loadApplications());
  
  const { data, isLoading, isError } = useListJobs(
    { skill: skillFilter || undefined, type: typeFilter !== 'all' ? typeFilter : undefined },
    { query: { queryKey: getListJobsQueryKey({ skill: skillFilter, type: typeFilter }) } }
  );

  const applyMutation = useApplyToJob();
  const { toast } = useToast();
  const [supabaseJobs, setSupabaseJobs] = useState<typeof demoJobs | null>(null);
  const jobList =
    (Array.isArray(supabaseJobs) && supabaseJobs.length > 0 && supabaseJobs) ||
    (Array.isArray(data) && data.length > 0 ? data : demoJobs);
  const jobs = jobList.filter((job) => {
    const matchesSkill = !skillFilter || job.requiredSkills.some((skill) => skill.toLowerCase().includes(skillFilter.toLowerCase()));
    const matchesType = typeFilter === "all" || job.type === typeFilter;
    return matchesSkill && matchesType;
  });

  const userSkills = useMemo(() => getUserSkillsForMatching(), [applications.length]);

  useEffect(() => {
    ensureCurrentStudentIdForSession();
  }, []);

  useEffect(() => {
    const loadJobs = async () => {
      const rows = await fetchJobsFromSupabase();
      if (rows && rows.length > 0) setSupabaseJobs(rows);
    };
    void loadJobs();
  }, []);

  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key && e.key.includes("skillhire_appliedJobs_v1")) {
        setApplications(loadApplications());
      }
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  const refreshApplications = () => setApplications(loadApplications());

  const openApply = (job: MarketplaceJob) => {
    setActiveJob(job);
    setApplyOpen(true);
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Jobs & Internships</h1>
            <p className="text-muted-foreground">Find opportunities that match your current skill level.</p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 bg-card p-4 rounded-xl border border-border">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Filter by skill (e.g. React, Python)" 
              className="pl-9"
              value={skillFilter}
              onChange={(e) => setSkillFilter(e.target.value)}
              data-testid="filter-skill"
            />
          </div>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-full sm:w-[200px]" data-testid="filter-type">
              <SelectValue placeholder="Job Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="Internship">Internship</SelectItem>
              <SelectItem value="Full-time">Full-time</SelectItem>
              <SelectItem value="Part-time">Part-time</SelectItem>
              <SelectItem value="Contract">Contract</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-64 w-full" />)}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {jobs.length === 0 ? (
              <div className="col-span-full py-12 text-center text-muted-foreground bg-secondary/20 rounded-xl border border-dashed border-border">
                No jobs found matching your criteria.
              </div>
            ) : (
              (jobs as MarketplaceJob[]).map((job) => {
                const match = computeJobMatch(job.requiredSkills ?? [], userSkills);
                const why = computeWhyMatch(match.verifiedSkills, match.missingSkills);
                const app = getApplicationForJob(job.id, getCurrentStudentId());

                return (
                  <JobCard
                    key={job.id}
                    job={job}
                    matchPercent={match.matchPercent}
                    whyMatch={why}
                    missingSkills={match.missingSkills}
                    verifiedSkills={match.verifiedSkills}
                    applicationStatus={app?.status ?? null}
                    onApply={() => openApply(job)}
                  />
                );
              })
            )}
          </div>
        )}

        <ApplyModal
          open={applyOpen}
          onOpenChange={setApplyOpen}
          jobTitle={activeJob?.title ?? "this job"}
          onSubmit={({ githubLink, portfolioLink }) => {
            if (!activeJob) return;
            const res = submitJobApplication({
              jobId: activeJob.id,
              studentId: getCurrentStudentId(),
              githubLink,
              portfolioLink,
            });
            refreshApplications();
            setApplyOpen(false);

            if (!res.created) {
              toast({ title: "Already applied", description: "You have already submitted proof for this job." });
              return;
            }

            // keep existing API mutate (non-blocking demo)
            applyMutation.mutate({
              id: activeJob.id,
              data: { studentId: getCurrentStudentId(), message: "GitHub proof submitted." },
            });

            toast({
              title: "Application submitted",
              description: "Saved with GitHub proof. Status will update after admin review.",
            });
          }}
        />
      </div>
    </DashboardLayout>
  );
}
