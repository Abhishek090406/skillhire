import { useEffect, useMemo, useState } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { ChallengeCard } from "@/components/skill-lab/ChallengeCard";
import { CodeEditor } from "@/components/skill-lab/CodeEditor";
import { ResultPanel } from "@/components/skill-lab/ResultPanel";
import { incrementReadinessScore } from "@/lib/student-consistency";
import {
  evaluateChallenge,
  getSkillLabChallenges,
  getSuggestedChallengeIdsFromSkillGap,
  loadCompletedChallenges,
  loadSkillLabVerifiedSkills,
  markChallengeCompleted,
  verifySkill,
} from "@/lib/skill-lab";
import { TopProgressBar } from "@/components/skill-lab/TopProgressBar";
import { Play, Loader2 } from "lucide-react";

export default function SkillLab() {
  const { toast } = useToast();
  const challenges = useMemo(() => getSkillLabChallenges(), []);
  const suggestedIds = useMemo(() => new Set(getSuggestedChallengeIdsFromSkillGap()), []);

  const [selectedId, setSelectedId] = useState(challenges[0]?.id ?? "");
  const selected = challenges.find((c) => c.id === selectedId) ?? challenges[0];

  const [code, setCode] = useState(selected?.starterCode ?? "");
  const [status, setStatus] = useState<"idle" | "pass" | "fail">("idle");
  const [output, setOutput] = useState("Write code, click Run, and get verified.");
  const [missingTokens, setMissingTokens] = useState<string[]>([]);
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [successDetails, setSuccessDetails] = useState<{ verifiedSkill: string; scoreDelta: number } | null>(null);

  const [completed, setCompleted] = useState<string[]>(() => loadCompletedChallenges());
  const [verified, setVerified] = useState<string[]>(() => loadSkillLabVerifiedSkills());

  useEffect(() => {
    if (!selected) return;
    setCode(selected.starterCode);
    setStatus("idle");
    setOutput("Write code, click Run, and get verified.");
    setMissingTokens([]);
    setIsEvaluating(false);
    setSuccessDetails(null);
  }, [selectedId]);

  const onRun = () => {
    if (!selected) return;
    setIsEvaluating(true);
    setStatus("idle");
    setOutput("Evaluating...");
    setMissingTokens([]);
    setSuccessDetails(null);

    window.setTimeout(() => {
      const res = evaluateChallenge(code, selected);
      setStatus(res.pass ? "pass" : "fail");
      setOutput(res.output);
      setMissingTokens(res.missingTokens);
      setIsEvaluating(false);

      if (res.pass) {
        const alreadyCompleted = completed.includes(selected.id);
        markChallengeCompleted(selected.id);
        verifySkill(selected.primarySkillToVerify);

        const scoreDelta = alreadyCompleted ? 0 : 10;
        if (!alreadyCompleted) {
          incrementReadinessScore(10);
        }

        setCompleted(loadCompletedChallenges());
        setVerified(loadSkillLabVerifiedSkills());
        setSuccessDetails({ verifiedSkill: selected.primarySkillToVerify, scoreDelta });

        toast({
          title: "Challenge passed",
          description:
            scoreDelta > 0
              ? `Skill verified: ${selected.primarySkillToVerify}. Readiness +10.`
              : `Skill verified: ${selected.primarySkillToVerify}.`,
        });
      } else {
        toast({ title: "Try again", description: "Update your code and re-run the evaluation." });
      }
    }, 900);
  };

  return (
    <DashboardLayout>
      <div className="space-y-4">
        <TopProgressBar completedCount={completed.length} totalCount={challenges.length} verifiedSkills={verified} />

        <div className="grid grid-cols-1 lg:grid-cols-[360px_1fr_360px] gap-4">
          {/* LEFT: instructions */}
          <div className="space-y-3 min-w-0">
            <div className="rounded-xl border border-border bg-card p-4">
              <div className="text-xs uppercase tracking-wider text-muted-foreground">Challenge</div>
              <div className="text-lg font-semibold mt-1">{selected?.title}</div>
              <div className="text-sm text-muted-foreground mt-2">{selected?.description}</div>

              <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                <div>
                  <div className="text-xs text-muted-foreground uppercase tracking-wider">Difficulty</div>
                  <div className="font-medium">{selected?.difficulty}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground uppercase tracking-wider">Reward</div>
                  <div className="font-medium">+10 readiness</div>
                </div>
              </div>

              <div className="mt-4">
                <div className="text-xs text-muted-foreground uppercase tracking-wider">Requirements</div>
                <div className="text-sm text-muted-foreground mt-2 space-y-1">
                  {selected?.requiredSkills.slice(0, 5).map((s) => (
                    <div key={s}>• {s}</div>
                  ))}
                </div>
              </div>

              <div className="mt-4">
                <div className="text-xs text-muted-foreground uppercase tracking-wider">Hints</div>
                <div className="text-sm text-muted-foreground mt-2 space-y-1">
                  {selected?.passContainsAll.slice(0, 3).map((h) => (
                    <div key={h}>• Include <span className="text-foreground font-medium">{h}</span></div>
                  ))}
                </div>
              </div>

              <div className="mt-4 text-xs text-muted-foreground">
                Passing verifies: <span className="text-foreground font-medium">{selected?.primarySkillToVerify}</span>
              </div>
            </div>

            <div className="rounded-xl border border-border bg-card p-3">
              <div className="text-xs uppercase tracking-wider text-muted-foreground mb-2">All challenges</div>
              <div className="space-y-2">
                {challenges.map((c) => (
                  <ChallengeCard
                    key={c.id}
                    challenge={c}
                    selected={c.id === selectedId}
                    completed={completed.includes(c.id)}
                    suggested={suggestedIds.has(c.id)}
                    onSelect={() => setSelectedId(c.id)}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* CENTER: editor */}
          <div className="space-y-3 min-w-0">
            <div className="flex items-center justify-between gap-3 rounded-xl border border-border bg-card px-4 py-3">
              <div className="text-sm text-muted-foreground truncate">
                Language: <span className="text-foreground font-medium">{selected?.language}</span>
              </div>
              <Button
                className="bg-primary hover:bg-primary/90 text-primary-foreground glow-green"
                onClick={onRun}
                disabled={isEvaluating}
              >
                {isEvaluating ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Play className="w-4 h-4 mr-2" />}
                {isEvaluating ? "Evaluating..." : "Run"}
              </Button>
            </div>

            {selected ? <CodeEditor value={code} onChange={setCode} language={selected.language} height={640} /> : null}
          </div>

          {/* RIGHT: result */}
          <div className="space-y-3 min-w-0">
            <ResultPanel
              status={status}
              isEvaluating={isEvaluating}
              output={output}
              missingTokens={missingTokens}
              successDetails={successDetails}
            />
            <div className="rounded-xl border border-border bg-card p-4 text-sm text-muted-foreground">
              Tip: Keep outputs small and focused. Recruiters care about proof, not perfection.
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}

