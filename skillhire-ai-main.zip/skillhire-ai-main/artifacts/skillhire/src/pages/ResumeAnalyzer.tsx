import { useCallback, useRef, useState } from "react";
import { useLocation } from "wouter";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import {
  extractResumeTextFromFile,
  extractSkillsFromResumeText,
  formatSkillTag,
  persistSkillsForSkillGap,
} from "@/lib/resume-analyzer";
import { FileSearch, Check, Upload, Loader2, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";

export default function ResumeAnalyzer() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const inputRef = useRef<HTMLInputElement>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [extracted, setExtracted] = useState<string[]>([]);
  const [analyzing, setAnalyzing] = useState(false);
  const [success, setSuccess] = useState(false);
  const [usedPdfMock, setUsedPdfMock] = useState(false);
  const [dragActive, setDragActive] = useState(false);

  const processFile = useCallback(
    async (file: File | undefined) => {
      if (!file) return;
      setSuccess(false);
      setExtracted([]);
      setUsedPdfMock(false);
      setFileName(file.name);
      setAnalyzing(true);
      try {
        const { text, usedPdfMock: mock } = await extractResumeTextFromFile(file);
        setUsedPdfMock(mock);
        const skills = extractSkillsFromResumeText(text);
        setExtracted(skills);
        setSuccess(true);
        if (skills.length === 0) {
          toast({
            title: "No skills detected",
            description: mock
              ? "Demo PDF text did not match the keyword list. Try a .txt file with tech terms."
              : "Add keywords like React, JavaScript, or Python to your resume text.",
          });
        } else {
          toast({
            title: "Skills extracted successfully",
            description: mock
              ? "Demo mode: PDF content was simulated; these skills reflect the sample profile."
              : `Found ${skills.length} skills from your resume.`,
          });
        }
      } catch (e) {
        setFileName(null);
        toast({
          variant: "destructive",
          title: "Could not analyze file",
          description: e instanceof Error ? e.message : "Try a .pdf or .txt file.",
        });
      } finally {
        setAnalyzing(false);
      }
    },
    [toast]
  );

  const onDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragActive(false);
      const f = e.dataTransfer.files?.[0];
      void processFile(f);
    },
    [processFile]
  );

  const applyToSkillGap = () => {
    if (extracted.length === 0) return;
    persistSkillsForSkillGap(extracted);
    setLocation("/skill-gap");
  };

  return (
    <DashboardLayout>
      <div className="space-y-8 max-w-3xl mx-auto">
        <div>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
            <FileSearch className="w-8 h-8 text-primary" />
            Resume Analyzer
          </h1>
          <p className="text-muted-foreground mt-1">
            Upload a resume, detect skills instantly, and send them to Skill Gap Analysis in one click.
          </p>
        </div>

        <Card className="border-primary/20">
          <CardHeader>
            <CardTitle>Upload resume</CardTitle>
            <CardDescription>PDF or plain text (.txt). PDF uses a fast demo extraction for pitches.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <input
              ref={inputRef}
              type="file"
              accept=".pdf,.txt,application/pdf,text/plain"
              className="sr-only"
              onChange={(e) => {
                void processFile(e.target.files?.[0]);
                e.target.value = "";
              }}
            />

            <div
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  inputRef.current?.click();
                }
              }}
              onDragEnter={(e) => {
                e.preventDefault();
                setDragActive(true);
              }}
              onDragOver={(e) => {
                e.preventDefault();
                setDragActive(true);
              }}
              onDragLeave={() => setDragActive(false)}
              onDrop={onDrop}
              onClick={() => inputRef.current?.click()}
              className={cn(
                "rounded-xl border-2 border-dashed p-10 text-center cursor-pointer transition-colors",
                dragActive ? "border-primary bg-primary/5" : "border-border hover:border-primary/40 hover:bg-secondary/30"
              )}
            >
              {analyzing ? (
                <div className="flex flex-col items-center gap-3 text-muted-foreground">
                  <Loader2 className="w-10 h-10 animate-spin text-primary" />
                  <p className="font-medium text-foreground">Analyzing resume…</p>
                  <p className="text-sm">Scanning for known technologies</p>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-3">
                  <div className="rounded-full bg-primary/10 p-4">
                    <Upload className="w-8 h-8 text-primary" />
                  </div>
                  <p className="font-medium">Drop your file here or click to browse</p>
                  <p className="text-sm text-muted-foreground">.pdf and .txt supported</p>
                  <Button type="button" variant="secondary" className="mt-2 pointer-events-none">
                    Choose file
                  </Button>
                </div>
              )}
            </div>

            {fileName && !analyzing ? (
              <p className="text-sm text-muted-foreground">
                <span className="font-medium text-foreground">Selected: </span>
                {fileName}
                {usedPdfMock ? (
                  <span className="ml-2 text-xs rounded-md bg-primary/15 text-primary px-2 py-0.5">Demo PDF text</span>
                ) : null}
              </p>
            ) : null}
          </CardContent>
        </Card>

        {(success || extracted.length > 0) && !analyzing ? (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Detected skills</CardTitle>
              <CardDescription>
                We detected these skills based on your resume{usedPdfMock ? " (demo PDF sample)" : ""}.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {extracted.length === 0 ? (
                <p className="text-sm text-muted-foreground">
                  No matches from the predefined list. Try editing a .txt file to include terms like React or Python.
                </p>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {extracted.map((skill) => (
                    <Badge
                      key={skill}
                      variant="secondary"
                      className="gap-1.5 py-1.5 px-3 text-sm border-primary/20 bg-primary/10 text-primary"
                    >
                      <Check className="w-3.5 h-3.5" />
                      {formatSkillTag(skill)}
                    </Badge>
                  ))}
                </div>
              )}

              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <Button
                  className="glow-green gap-2"
                  disabled={extracted.length === 0}
                  onClick={applyToSkillGap}
                >
                  Use these skills
                  <ArrowRight className="w-4 h-4" />
                </Button>
                <Button variant="outline" asChild>
                  <Link href="/skill-gap">Open Skill Gap manually</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : null}
      </div>
    </DashboardLayout>
  );
}
