import { useEffect, useMemo, useState } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { useGetStudent, getGetStudentQueryKey } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { RadialBarChart, RadialBar, PolarAngleAxis, ResponsiveContainer } from "recharts";
import { Github, Linkedin, Award, Briefcase, BookOpen, UserCircle, CheckCircle2, AlertTriangle, Trophy, Target } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { demoStudentProfile } from "@/lib/demo-data";
import { fetchStudentProfileFromSupabase } from "@/lib/supabase/data";
import { supabase } from "@/lib/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { saveStudentProfileCache, unifyStudentData } from "@/lib/student-consistency";
import { fetchUserProfile, getAuthedUserId, upsertUserProfile } from "@/lib/supabase/user-profiles";
import { loadApplications } from "@/lib/hiring-workflow";
import {
  computeReadinessBreakdown,
  computeVerifiedSkills,
  ensureMockMentorFeedback,
  getMissingSkills,
  getProjectProofs,
  saveProjectLiveDemo,
} from "@/lib/profile-verification";
import { listMySubmissions } from "@/lib/supabase/hiring";
import { loadSubmissions } from "@/lib/submissions";
import { aggregateSubmissionScores } from "@/lib/project-scoring";
import { ensureCurrentStudentIdForSession, getCurrentStudentId } from "@/lib/current-student";

export default function Profile() {
  const { toast } = useToast();
  const [supabaseStudent, setSupabaseStudent] = useState<null | typeof demoStudentProfile>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [formState, setFormState] = useState({
    name: "",
    careerGoal: "",
    bio: "",
    githubUrl: "",
    linkedinUrl: "",
    skills: "",
    openToWork: "true",
    preferredRole: "",
  });
  const studentId = getCurrentStudentId();

  const { data, isLoading, isError } = useGetStudent(studentId, {
    query: {
      enabled: true,
      queryKey: getGetStudentQueryKey(studentId),
    },
  });

  useEffect(() => {
    ensureCurrentStudentIdForSession();
  }, []);

  useEffect(() => {
    const loadProfile = async () => {
      const userId = await getAuthedUserId();
      if (userId) {
        const profile = await fetchUserProfile(userId);
        if (profile && typeof profile.name === "string") {
          setSupabaseStudent((prev) => ({
            ...(prev ?? demoStudentProfile),
            name: profile.name ?? demoStudentProfile.name,
            careerGoal: profile.career_goal ?? demoStudentProfile.careerGoal,
            bio: profile.bio ?? demoStudentProfile.bio,
            githubUrl: profile.github_url ?? demoStudentProfile.githubUrl,
            linkedinUrl: profile.linkedin_url ?? demoStudentProfile.linkedinUrl,
            skills: Array.isArray(profile.skills) ? profile.skills : demoStudentProfile.skills,
          }));
          return;
        }
      }

      const row = await fetchStudentProfileFromSupabase(studentId);
      if (row) setSupabaseStudent(row);
    };
    void loadProfile();
  }, [studentId]);

  const sourceStudent = supabaseStudent ?? data;
  const student = unifyStudentData({
    ...demoStudentProfile,
    ...(sourceStudent && typeof sourceStudent === "object" ? sourceStudent : {}),
    skills: Array.isArray((sourceStudent as { skills?: unknown } | null)?.skills)
      ? (sourceStudent as { skills: string[] }).skills
      : demoStudentProfile.skills,
    certifications: Array.isArray((sourceStudent as { certifications?: unknown } | null)?.certifications)
      ? (sourceStudent as { certifications: string[] }).certifications
      : demoStudentProfile.certifications,
  }) as typeof demoStudentProfile;

  const chartData = [{ name: "Readiness", value: student.readinessScore, fill: "hsl(var(--primary))" }];
  const breakdown = useMemo(() => computeReadinessBreakdown(), []);
  const missingSkills = useMemo(() => getMissingSkills(), []);
  const verifiedSkills = useMemo(
    () => computeVerifiedSkills(Array.isArray(student.skills) ? student.skills : []),
    [student.skills]
  );
  const projectProofs = useMemo(() => getProjectProofs(), []);
  const applications = useMemo(
    () => loadApplications().filter((a) => a.studentId === getCurrentStudentId()),
    [studentId]
  );
  const mentorFeedback = useMemo(() => ensureMockMentorFeedback(), []);

  const [projectScoreStats, setProjectScoreStats] = useState({ top: 0, average: 0, count: 0 });

  useEffect(() => {
    const run = async () => {
      try {
        const rows = await listMySubmissions();
        if (rows.length > 0) {
          setProjectScoreStats(aggregateSubmissionScores(rows));
          return;
        }
      } catch {
        /* Supabase optional */
      }
      const local = loadSubmissions().filter((s) => s.studentId === getCurrentStudentId());
      if (local.length > 0) {
        setProjectScoreStats(
          aggregateSubmissionScores(
            local.map((s) => ({
              github_link: s.githubLink,
              project_title: s.projectTitle,
              score: s.score,
            }))
          )
        );
      } else {
        setProjectScoreStats({ top: 0, average: 0, count: 0 });
      }
    };
    void run();
  }, [studentId]);

  useEffect(() => {
    if (isEditing) return;
    setFormState({
      name: student.name ?? "",
      careerGoal: student.careerGoal ?? "",
      bio: student.bio ?? "",
      githubUrl: student.githubUrl ?? "",
      linkedinUrl: student.linkedinUrl ?? "",
      skills: Array.isArray(student.skills) ? student.skills.join(", ") : "",
      openToWork: (localStorage.getItem("skillhire_open_to_work") ?? "true") as string,
      preferredRole: localStorage.getItem("skillhire_preferred_role") ?? (student.careerGoal ?? ""),
    });
  }, [isEditing, student.name, student.careerGoal, student.bio, student.githubUrl, student.linkedinUrl, student.skills]);

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="space-y-6">
          <Skeleton className="h-64 w-full" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Skeleton className="h-96 md:col-span-2" />
            <Skeleton className="h-96" />
          </div>
        </div>
      </DashboardLayout>
    );
  }

  const handleSaveProfile = async () => {
    const skills = formState.skills
      .split(",")
      .map((skill) => skill.trim())
      .filter(Boolean);

    const userId = await getAuthedUserId();
    const { error } = userId
      ? await upsertUserProfile({
          user_id: userId,
          role: "student",
          name: formState.name,
          career_goal: formState.careerGoal,
          bio: formState.bio,
          github_url: formState.githubUrl,
          linkedin_url: formState.linkedinUrl,
          skills,
          readiness_score: student.readinessScore,
          profile_completion: 84,
        })
      : await supabase
          .from("students")
          .update({
            name: formState.name,
            career_goal: formState.careerGoal,
            bio: formState.bio,
            github_url: formState.githubUrl,
            linkedin_url: formState.linkedinUrl,
            skills,
          })
          .eq("id", 1);

    saveStudentProfileCache({
      name: formState.name,
      careerGoal: formState.careerGoal,
      bio: formState.bio,
      githubUrl: formState.githubUrl,
      linkedinUrl: formState.linkedinUrl,
      skills,
    });

    localStorage.setItem("skillhire_open_to_work", formState.openToWork === "true" ? "true" : "false");
    localStorage.setItem("skillhire_preferred_role", formState.preferredRole || formState.careerGoal);

    if (error) {
      toast({
        title: "Profile saved",
        description: "Saved locally. Cloud sync can be enabled after RLS setup.",
      });
      setSupabaseStudent((prev) =>
        prev
          ? { ...prev, ...formState, skills }
          : { ...demoStudentProfile, ...formState, skills }
      );
    } else {
      toast({
        title: "Profile updated",
        description: "Your profile has been saved successfully.",
      });
      if (userId) {
        const refreshed = await fetchUserProfile(userId);
        if (refreshed && typeof refreshed.name === "string") {
          setSupabaseStudent((prev) => ({
            ...(prev ?? demoStudentProfile),
            name: refreshed.name ?? demoStudentProfile.name,
            careerGoal: refreshed.career_goal ?? demoStudentProfile.careerGoal,
            bio: refreshed.bio ?? demoStudentProfile.bio,
            githubUrl: refreshed.github_url ?? demoStudentProfile.githubUrl,
            linkedinUrl: refreshed.linkedin_url ?? demoStudentProfile.linkedinUrl,
            skills: Array.isArray(refreshed.skills) ? refreshed.skills : demoStudentProfile.skills,
          }));
        }
      } else {
        const refreshed = await fetchStudentProfileFromSupabase(1);
        if (refreshed) setSupabaseStudent(refreshed);
      }
    }

    setIsEditing(false);
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <Card className="overflow-hidden border-border bg-card">
          <div className="h-32 bg-gradient-to-r from-primary/20 to-primary/5 w-full relative"></div>
          <CardContent className="px-6 sm:px-10 pb-10 pt-0 relative">
            <div className="flex flex-col sm:flex-row items-center sm:items-end gap-6 -mt-16 sm:-mt-12 mb-6">
              <div className="w-32 h-32 rounded-full border-4 border-card bg-secondary flex items-center justify-center overflow-hidden shrink-0">
                {student.avatarUrl ? (
                  <img src={student.avatarUrl} alt={student.name} className="w-full h-full object-cover" />
                ) : (
                  <UserCircle className="w-20 h-20 text-muted-foreground" />
                )}
              </div>
              <div className="flex-1 text-center sm:text-left pt-2">
                {isEditing ? (
                  <div className="space-y-2">
                    <Input value={formState.name} onChange={(e) => setFormState((prev) => ({ ...prev, name: e.target.value }))} />
                    <Input value={formState.careerGoal} onChange={(e) => setFormState((prev) => ({ ...prev, careerGoal: e.target.value }))} />
                  </div>
                ) : (
                  <>
                    <h1 className="text-3xl font-bold tracking-tight">{student.name}</h1>
                    <p className="text-muted-foreground text-lg">{student.careerGoal}</p>
                  </>
                )}
              </div>
              <div className="flex gap-3">
                {isEditing ? (
                  <>
                    <Button variant="outline" onClick={() => setIsEditing(false)}>Cancel</Button>
                    <Button onClick={handleSaveProfile}>Save</Button>
                  </>
                ) : (
                  <Button variant="outline" onClick={() => setIsEditing(true)}>Edit Profile</Button>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4">
              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-3">About</h3>
                  {isEditing ? (
                    <Textarea value={formState.bio} onChange={(e) => setFormState((prev) => ({ ...prev, bio: e.target.value }))} />
                  ) : (
                    <p className="text-foreground leading-relaxed">
                      {student.bio || "No bio provided."}
                    </p>
                  )}
                </div>
                
                <div>
                  <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-3">Links</h3>
                  {isEditing ? (
                    <div className="space-y-2">
                      <Input placeholder="GitHub URL" value={formState.githubUrl} onChange={(e) => setFormState((prev) => ({ ...prev, githubUrl: e.target.value }))} />
                      <Input placeholder="LinkedIn URL" value={formState.linkedinUrl} onChange={(e) => setFormState((prev) => ({ ...prev, linkedinUrl: e.target.value }))} />
                    </div>
                  ) : (
                    <div className="flex gap-4">
                      {student.githubUrl && (
                        <a href={student.githubUrl} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
                          <Github className="w-5 h-5" /> GitHub
                        </a>
                      )}
                      {student.linkedinUrl && (
                        <a href={student.linkedinUrl} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
                          <Linkedin className="w-5 h-5" /> LinkedIn
                        </a>
                      )}
                    </div>
                  )}
                </div>
              </div>

              <div className="space-y-6 md:border-l border-border md:pl-8">
                <div>
                  <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-3">Hiring Status</h3>
                  {isEditing ? (
                    <div className="space-y-2">
                      <Input
                        placeholder="Preferred role (e.g. Backend Developer)"
                        value={formState.preferredRole}
                        onChange={(e) => setFormState((prev) => ({ ...prev, preferredRole: e.target.value }))}
                      />
                      <Input
                        placeholder='Open to work? ("true" / "false")'
                        value={formState.openToWork}
                        onChange={(e) => setFormState((prev) => ({ ...prev, openToWork: e.target.value }))}
                      />
                    </div>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="outline" className="text-primary border-primary bg-primary/5">
                        {localStorage.getItem("skillhire_open_to_work") === "false" ? "Not open to work" : "Open to work"}
                      </Badge>
                      <Badge variant="secondary">
                        Preferred: {localStorage.getItem("skillhire_preferred_role") ?? student.careerGoal}
                      </Badge>
                      <Badge variant="outline">
                        {verifiedSkills.verified.length >= 3 ? "Verified candidate" : "Verification in progress"}
                      </Badge>
                      <Badge variant="outline">
                        {missingSkills.length <= 2 ? "Job-ready trajectory" : "Active learner"}
                      </Badge>
                    </div>
                  )}
                </div>

                <div>
                  <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-3">Stats</h3>
                  <div className="flex flex-wrap gap-6">
                    <div className="flex items-center gap-3">
                      <div className="bg-primary/10 p-2 rounded-md text-primary">
                        <Briefcase className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="text-2xl font-bold">{student.completedProjects}</div>
                        <div className="text-xs text-muted-foreground uppercase tracking-wider">Projects</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="bg-primary/10 p-2 rounded-md text-primary">
                        <BookOpen className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="text-2xl font-bold">{student.certifications?.length || 0}</div>
                        <div className="text-xs text-muted-foreground uppercase tracking-wider">Certifications</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="bg-primary/10 p-2 rounded-md text-primary">
                        <Trophy className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="text-2xl font-bold">
                          {projectScoreStats.count ? `${projectScoreStats.top}/100` : "—"}
                        </div>
                        <div className="text-xs text-muted-foreground uppercase tracking-wider">Top project score</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="bg-primary/10 p-2 rounded-md text-primary">
                        <Target className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="text-2xl font-bold">
                          {projectScoreStats.count ? `${projectScoreStats.average}/100` : "—"}
                        </div>
                        <div className="text-xs text-muted-foreground uppercase tracking-wider">Avg project score</div>
                      </div>
                    </div>
                  </div>
                  {projectScoreStats.count === 0 ? (
                    <p className="text-xs text-muted-foreground mt-3">
                      Submit a GitHub project from Projects to generate scores.
                    </p>
                  ) : null}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle>Skills & Technologies</CardTitle>
            </CardHeader>
            <CardContent>
              {isEditing ? (
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">Edit skills as comma-separated values.</p>
                  <Input value={formState.skills} onChange={(e) => setFormState((prev) => ({ ...prev, skills: e.target.value }))} />
                </div>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {verifiedSkills.all.map((s) => (
                    <Badge
                      key={s.skill}
                      variant="secondary"
                      className={[
                        "px-3 py-1.5 text-sm flex items-center gap-2",
                        s.state === "Verified" ? "border border-primary/30 bg-primary/10 text-primary" : "bg-secondary/20",
                      ].join(" ")}
                    >
                      {s.state === "Verified" ? <CheckCircle2 className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4 text-muted-foreground" />}
                      {s.skill}
                      <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
                        {s.state}
                      </span>
                    </Badge>
                  ))}
                </div>
              )}
              
              {student.certifications && student.certifications.length > 0 && (
                <div className="mt-8">
                  <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-4">Certifications</h3>
                  <div className="space-y-3">
                    {student.certifications.map((cert, idx) => (
                      <div key={idx} className="flex items-center gap-3 p-3 border border-border rounded-lg bg-secondary/10">
                        <Award className="w-5 h-5 text-primary" />
                        <span className="font-medium">{cert}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="flex flex-col">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Career Readiness</CardTitle>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col items-center justify-center relative py-8">
              <div className="h-48 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <RadialBarChart 
                    cx="50%" cy="50%" 
                    innerRadius="70%" outerRadius="100%" 
                    barSize={20} 
                    data={chartData} 
                    startAngle={180} endAngle={0}
                  >
                    <PolarAngleAxis type="number" domain={[0, 100]} angleAxisId={0} tick={false} />
                    <RadialBar background={{ fill: 'hsl(var(--secondary))' }} dataKey="value" cornerRadius={10} />
                  </RadialBarChart>
                </ResponsiveContainer>
              </div>
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/4 text-center pt-2">
                <span className="text-5xl font-bold block text-primary">{student.readinessScore}</span>
                <span className="text-xs text-muted-foreground font-medium uppercase tracking-wider">/ 100</span>
              </div>
            </CardContent>
            <CardContent className="pt-0 pb-6">
              <div className="space-y-2 text-sm">
                <div className="flex justify-between text-muted-foreground">
                  <span>Skills</span>
                  <span className="text-foreground font-medium">{breakdown.skillsPercent}%</span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <span>Projects</span>
                  <span className="text-foreground font-medium">{breakdown.projectsPercent}%</span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <span>Experience</span>
                  <span className="text-foreground font-medium">{breakdown.experiencePercent}%</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Projects (Proof)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {projectProofs.length === 0 ? (
                <div className="text-sm text-muted-foreground">No projects submitted yet. Complete a project to verify skills.</div>
              ) : (
                projectProofs.map((p) => (
                  <div key={p.projectId} className="p-4 rounded-lg border border-border bg-secondary/10 space-y-2">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="font-semibold">{p.name}</div>
                      <Badge variant="outline" className={p.status === "Verified" ? "border-primary/30 text-primary bg-primary/5" : ""}>
                        {p.status}
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground flex flex-col gap-1">
                      {p.githubLink ? (
                        <a className="text-primary underline underline-offset-2" href={p.githubLink} target="_blank" rel="noreferrer">
                          GitHub Repo
                        </a>
                      ) : (
                        <span>No GitHub link submitted yet.</span>
                      )}
                      {p.liveDemo ? (
                        <a className="text-primary underline underline-offset-2" href={p.liveDemo} target="_blank" rel="noreferrer">
                          Live Demo
                        </a>
                      ) : (
                        <button
                          className="text-left text-primary underline underline-offset-2"
                          onClick={() => {
                            const url = window.prompt("Paste Live Demo URL");
                            if (!url) return;
                            saveProjectLiveDemo(p.projectId, url);
                            toast({ title: "Live demo saved", description: "Saved demo link for recruiter review." });
                          }}
                        >
                          + Add Live Demo
                        </button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Missing Skills</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="text-sm text-muted-foreground">What you need to reach the next level</div>
              <div className="flex flex-wrap gap-2 pt-2">
                {(missingSkills.length ? missingSkills.slice(0, 6) : ["No major gaps detected"]).map((s) => (
                  <Badge key={s} variant="secondary" className="text-xs">
                    {s}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Application Activity</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {applications.length === 0 ? (
                <div className="text-sm text-muted-foreground">No job applications yet.</div>
              ) : (
                applications.slice(0, 6).map((a) => (
                  <div key={a.applicationId} className="p-3 rounded-lg border border-border bg-secondary/10 flex items-center justify-between">
                    <div className="text-sm">
                      <div className="font-medium">Job #{a.jobId}</div>
                      <div className="text-xs text-muted-foreground">{new Date(a.timestamp).toLocaleString()}</div>
                    </div>
                    <Badge variant="outline" className={a.status === "Approved" ? "border-primary/30 text-primary bg-primary/5" : ""}>
                      {a.status}
                    </Badge>
                  </div>
                ))
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Mentor Feedback</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {mentorFeedback.slice(0, 3).map((f) => (
                <div key={f.id} className="p-4 rounded-lg border border-border bg-secondary/10 space-y-1">
                  <div className="flex items-center justify-between">
                    <div className="font-medium">{f.mentorName}</div>
                    <div className="text-xs text-muted-foreground">{new Date(f.createdAt).toLocaleDateString()}</div>
                  </div>
                  <div className="text-sm text-muted-foreground">{f.summary}</div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Progress Timeline</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="text-sm text-muted-foreground">Hiring signals built from proof-based milestones.</div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
              <div className="p-3 rounded-lg border border-border bg-secondary/10">
                <div className="text-xs text-muted-foreground uppercase tracking-wider">Projects completed</div>
                <div className="text-2xl font-bold">{projectProofs.filter((p) => p.status === "Verified").length}</div>
              </div>
              <div className="p-3 rounded-lg border border-border bg-secondary/10">
                <div className="text-xs text-muted-foreground uppercase tracking-wider">Certifications</div>
                <div className="text-2xl font-bold">{student.certifications?.length ?? 0}</div>
              </div>
              <div className="p-3 rounded-lg border border-border bg-secondary/10">
                <div className="text-xs text-muted-foreground uppercase tracking-wider">Verified skills</div>
                <div className="text-2xl font-bold">{verifiedSkills.verified.length}</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
