import { FormEvent, useState } from "react";
import { useLocation } from "wouter";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/lib/supabase/client";

export default function CompanyPostJob() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [skills, setSkills] = useState("");
  const [location, setJobLocation] = useState("");
  const [type, setType] = useState("Internship");
  const [stipend, setStipend] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    setIsSubmitting(true);

    const requiredSkills = skills
      .split(",")
      .map((skill) => skill.trim())
      .filter(Boolean);

    const { error } = await supabase.from("jobs").insert({
      title,
      description,
      company_id: 1,
      company_name: "SkillHire Labs",
      required_skills: requiredSkills,
      location,
      remote: location.toLowerCase() === "remote",
      stipend,
      type,
      applicants: 0,
      status: "Open",
    });

    if (error) {
      toast({
        title: "Saved locally",
        description: "Job draft captured. You can continue managing openings.",
      });
    } else {
      toast({
        title: "Job posted",
        description: "Your opening is now available to students.",
      });
    }
    setLocation("/company-dashboard");
    setIsSubmitting(false);
  };

  return (
    <DashboardLayout mode="company">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Post Job</h1>
          <p className="text-muted-foreground">Create a new internship or full-time opening.</p>
        </div>
        <Card>
          <CardHeader>
            <CardTitle>Job Details</CardTitle>
          </CardHeader>
          <CardContent>
            <form className="space-y-4" onSubmit={handleSubmit}>
              <div className="space-y-2">
                <Label htmlFor="job-title">Job Title</Label>
                <Input id="job-title" placeholder="Frontend Intern" value={title} onChange={(e) => setTitle(e.target.value)} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="job-description">Description</Label>
                <Textarea id="job-description" placeholder="Share role expectations and required skills" value={description} onChange={(e) => setDescription(e.target.value)} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="job-skills">Required Skills</Label>
                <Input id="job-skills" placeholder="React, TypeScript, Communication" value={skills} onChange={(e) => setSkills(e.target.value)} required />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="job-location">Location</Label>
                  <Input id="job-location" placeholder="Remote / Bengaluru" value={location} onChange={(e) => setJobLocation(e.target.value)} required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="job-type">Type</Label>
                  <Input id="job-type" placeholder="Internship" value={type} onChange={(e) => setType(e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="job-stipend">Stipend / Salary</Label>
                  <Input id="job-stipend" placeholder="Rs 20,000 / month" value={stipend} onChange={(e) => setStipend(e.target.value)} />
                </div>
              </div>
              <Button type="submit" disabled={isSubmitting} data-testid="company-post-job-submit">Post Job</Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
