import { FormEvent, useState } from "react";
import { useLocation } from "wouter";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/lib/supabase/client";

export default function CompanyPostProject() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [skills, setSkills] = useState("");
  const [duration, setDuration] = useState("");
  const [difficulty, setDifficulty] = useState("Intermediate");
  const [reward, setReward] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    setIsSubmitting(true);

    const requiredSkills = skills
      .split(",")
      .map((skill) => skill.trim())
      .filter(Boolean);

    const { error } = await supabase.from("projects").insert({
      title,
      description,
      company_id: 1,
      company_name: "SkillHire Labs",
      required_skills: requiredSkills,
      difficulty,
      duration: duration || "2 weeks",
      reward: reward || null,
      certificate: true,
      applicants: 0,
      status: "Open",
    });

    if (error) {
      toast({
        title: "Saved locally",
        description: "Project draft captured. You can continue managing postings.",
      });
    } else {
      toast({
        title: "Project posted",
        description: "Your project is now visible in the marketplace.",
      });
    }
    setLocation("/company-dashboard");
    setIsSubmitting(false);
  };

  return (
    <DashboardLayout mode="company">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Post Project</h1>
          <p className="text-muted-foreground">Publish an industry project for students to apply.</p>
        </div>
        <Card>
          <CardHeader>
            <CardTitle>Project Details</CardTitle>
          </CardHeader>
          <CardContent>
            <form className="space-y-4" onSubmit={handleSubmit}>
              <div className="space-y-2">
                <Label htmlFor="project-title">Project Title</Label>
                <Input id="project-title" placeholder="Build analytics dashboard" value={title} onChange={(e) => setTitle(e.target.value)} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="project-description">Description</Label>
                <Textarea id="project-description" placeholder="Describe scope, goals, and deliverables" value={description} onChange={(e) => setDescription(e.target.value)} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="project-skills">Required Skills</Label>
                <Input id="project-skills" placeholder="React, TypeScript, API Integration" value={skills} onChange={(e) => setSkills(e.target.value)} required />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="project-duration">Duration</Label>
                  <Input id="project-duration" placeholder="3 weeks" value={duration} onChange={(e) => setDuration(e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="project-difficulty">Difficulty</Label>
                  <Input id="project-difficulty" placeholder="Intermediate" value={difficulty} onChange={(e) => setDifficulty(e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="project-reward">Reward</Label>
                  <Input id="project-reward" placeholder="Certificate + Referral" value={reward} onChange={(e) => setReward(e.target.value)} />
                </div>
              </div>
              <Button type="submit" disabled={isSubmitting} data-testid="company-post-project-submit">Post Project</Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
