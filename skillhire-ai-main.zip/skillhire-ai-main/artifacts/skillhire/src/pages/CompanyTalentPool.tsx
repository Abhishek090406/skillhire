import { useEffect, useMemo, useState } from "react";
import { useLocation } from "wouter";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { demoStudents } from "@/lib/demo-data";
import { fetchStudentsFromSupabase } from "@/lib/supabase/data";

export default function CompanyTalentPool() {
  const [location] = useLocation();
  const [query, setQuery] = useState("");
  const [students, setStudents] = useState(demoStudents);
  const [selectedId, setSelectedId] = useState<number | null>(null);

  useEffect(() => {
    const load = async () => {
      const rows = await fetchStudentsFromSupabase();
      if (rows && rows.length > 0) {
        setStudents(rows);
      }
    };
    void load();
  }, []);

  useEffect(() => {
    if (!location.includes("company-talent-pool")) return;
    const params = new URLSearchParams(window.location.search);
    const q = params.get("q");
    if (q) setQuery(decodeURIComponent(q));
  }, [location]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return students;
    return students.filter((student) => {
      const inName = student.name.toLowerCase().includes(q);
      const inGoal = student.careerGoal.toLowerCase().includes(q);
      const inSkills = student.skills.some((skill) => skill.toLowerCase().includes(q));
      const inScore = String(student.readinessScore).includes(q);
      return inName || inGoal || inSkills || inScore;
    });
  }, [query, students]);

  const selectedStudent = filtered.find((student) => student.id === selectedId) ?? null;

  return (
    <DashboardLayout mode="company">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Talent Pool</h1>
          <p className="text-muted-foreground">Browse students ready for industry projects and jobs.</p>
        </div>
        <Card>
          <CardHeader>
            <CardTitle>Search Candidates</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <Input
              placeholder="Search by skill, role, or readiness score"
              data-testid="company-talent-search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />

            <div className="space-y-3">
              {filtered.map((student) => (
                <div key={student.id} className="flex items-start justify-between border border-border rounded-lg p-4">
                  <div className="space-y-2">
                    <h4 className="font-semibold">{student.name}</h4>
                    <p className="text-sm text-muted-foreground">{student.careerGoal}</p>
                    <div className="flex flex-wrap gap-1">
                      {student.skills.slice(0, 4).map((skill) => (
                        <Badge key={skill} variant="secondary" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <Badge variant="outline">Score: {student.readinessScore}</Badge>
                    <Button size="sm" variant="secondary" onClick={() => setSelectedId(student.id)}>
                      View Profile
                    </Button>
                  </div>
                </div>
              ))}

              {filtered.length === 0 && (
                <p className="text-sm text-muted-foreground">No candidates matched your search.</p>
              )}
            </div>

            {selectedStudent && (
              <div className="border border-primary/30 rounded-lg p-4 bg-primary/5">
                <h4 className="font-semibold mb-1">{selectedStudent.name}</h4>
                <p className="text-sm text-muted-foreground mb-2">{selectedStudent.careerGoal}</p>
                <p className="text-sm mb-2">Readiness Score: {selectedStudent.readinessScore}/100</p>
                <div className="flex flex-wrap gap-1">
                  {selectedStudent.skills.map((skill) => (
                    <Badge key={skill} variant="outline" className="text-xs">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
