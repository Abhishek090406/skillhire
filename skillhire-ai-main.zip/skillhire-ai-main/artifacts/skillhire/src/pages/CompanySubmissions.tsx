import DashboardLayout from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useEffect, useMemo, useState } from "react";
import {
  awardVerifiedSkill,
  listAllSubmissionsForCompany,
  reviewSubmission,
  subscribeToSubmissions,
  updateSubmissionScore,
  type SubmissionRow,
} from "@/lib/supabase/hiring";
import { incrementReadinessScore } from "@/lib/student-consistency";
import { calculateSubmissionScore } from "@/lib/project-scoring";
import { useToast } from "@/hooks/use-toast";
import { buildCompanyDashboardFallbackSubmissions } from "@/lib/company-pipeline-demo";
import {
  applySubmissionStatusOverrides,
  saveSubmissionStatusOverride,
} from "@/lib/company-demo-overrides";

function resolvedSubmissionScore(s: SubmissionRow): number {
  return typeof s.score === "number" && !Number.isNaN(s.score)
    ? s.score
    : calculateSubmissionScore(s.github_link, s.project_title);
}

function demoSubmissionsList(): SubmissionRow[] {
  return applySubmissionStatusOverrides(
    buildCompanyDashboardFallbackSubmissions() as SubmissionRow[]
  );
}

function SubmissionScoreControls({
  submission,
  isDemo,
  onSaved,
}: {
  submission: SubmissionRow;
  isDemo: boolean;
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const initial = resolvedSubmissionScore(submission);
  const [draft, setDraft] = useState(String(initial));

  useEffect(() => {
    setDraft(String(resolvedSubmissionScore(submission)));
  }, [submission.id, submission.score, submission.github_link, submission.project_title]);

  const save = async () => {
    const n = Number(draft);
    if (Number.isNaN(n)) {
      toast({ variant: "destructive", title: "Invalid score", description: "Enter a number between 0 and 100." });
      return;
    }
    if (isDemo) {
      toast({ title: "Demo row", description: "Connect Supabase to persist score changes." });
      return;
    }
    try {
      const updated = await updateSubmissionScore({ submissionId: submission.id, score: n });
      if (!updated) {
        toast({ title: "Could not save", description: "Check company permissions and submissions table." });
        return;
      }
      toast({ title: "Score saved", description: `Project score set to ${updated.score}/100.` });
      onSaved();
    } catch (e) {
      toast({
        variant: "destructive",
        title: "Save failed",
        description: e instanceof Error ? e.message : "Try again.",
      });
    }
  };

  return (
    <div className="flex flex-col sm:flex-row sm:items-end gap-3 pt-2 border-t border-border mt-2">
      <div className="space-y-1 flex-1 min-w-[140px]">
        <Label htmlFor={`score-${submission.id}`} className="text-xs text-muted-foreground">
          Adjust score
        </Label>
        <Input
          id={`score-${submission.id}`}
          type="number"
          min={0}
          max={100}
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          className="h-9"
        />
      </div>
      <Button type="button" variant="secondary" size="sm" className="shrink-0" onClick={() => void save()}>
        Save score
      </Button>
    </div>
  );
}

export default function CompanySubmissions() {
  const { toast } = useToast();
  const [items, setItems] = useState<SubmissionRow[]>([]);
  const [loadError, setLoadError] = useState<string | null>(null);

  const refresh = async () => {
    try {
      setLoadError(null);
      const data = await listAllSubmissionsForCompany();
      if (data.length > 0) {
        setItems(data);
      } else {
        setItems(demoSubmissionsList());
      }
    } catch (e: any) {
      setItems(demoSubmissionsList());
      setLoadError(e?.message ?? "Failed to load submissions.");
    }
  };

  useEffect(() => {
    void refresh();
    const unsubscribe = subscribeToSubmissions(() => void refresh(), { debounceMs: 450 });
    return unsubscribe;
  }, []);

  const counts = useMemo(() => {
    const list = items.length ? items : demoSubmissionsList();
    const submitted = list.filter((s) => s.status === "Pending").length;
    const approved = list.filter((s) => s.status === "Approved").length;
    const rejected = list.filter((s) => s.status === "Rejected").length;
    return { submitted, approved, rejected };
  }, [items]);

  const displayed = items.length ? items : demoSubmissionsList();

  return (
    <DashboardLayout mode="company">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Submissions</h1>
          <p className="text-muted-foreground">Verify proof of work, tune project scores, and award verified skills.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-muted-foreground">Submitted</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{counts.submitted}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-muted-foreground">Approved</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary">{counts.approved}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-muted-foreground">Rejected</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{counts.rejected}</div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>All submissions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {loadError ? (
              <div className="p-4 rounded-lg border border-border bg-secondary/10 text-sm text-muted-foreground">
                {loadError}
                <div className="mt-2 text-xs">
                  If you haven’t yet, run `scratch/supabase/skillhire_core_schema.sql` in Supabase SQL Editor (includes{" "}
                  <code className="text-foreground">score</code> column), then refresh.
                </div>
              </div>
            ) : null}
            {displayed.map((s) => {
              const isDemo = s.id.startsWith("demo-");
              const score = resolvedSubmissionScore(s);
              return (
                <div key={s.id} className="p-4 rounded-lg border border-border bg-secondary/10 space-y-2">
                  <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <div className="font-semibold">
                          {(() => {
                            const sid = String(s.student_user_id);
                            return sid.length > 12 && sid.includes("-") ? `${sid.slice(0, 8)}…` : sid;
                          })()}
                        </div>
                        <Badge variant="outline">{s.status}</Badge>
                        <Badge variant="secondary" className="text-xs">
                          Skill: {s.skill}
                        </Badge>
                        <Badge variant="secondary" className="text-xs border-primary/30 text-primary bg-primary/10">
                          Project score: {score}/100
                        </Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Project: <span className="text-foreground font-medium">{s.project_title}</span>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        GitHub:{" "}
                        <a className="text-primary underline underline-offset-2" href={s.github_link} target="_blank" rel="noreferrer">
                          {s.github_link}
                        </a>
                      </div>
                      <div className="text-xs text-muted-foreground">Submitted: {new Date(s.created_at).toLocaleString()}</div>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      <Button
                        className="bg-primary hover:bg-primary/90 text-primary-foreground glow-green"
                        disabled={s.status === "Approved"}
                        onClick={async () => {
                          if (isDemo) {
                            const ts = new Date().toISOString();
                            saveSubmissionStatusOverride(s.id, "Approved", ts);
                            setItems(demoSubmissionsList());
                            toast({ title: "Approved", description: "Submission approved (demo)." });
                            return;
                          }
                          const reviewed = await reviewSubmission({ submissionId: s.id, status: "Approved" });
                          if (reviewed) {
                            await awardVerifiedSkill({ studentUserId: reviewed.student_user_id, skill: reviewed.skill });
                          }
                          incrementReadinessScore(10);
                          await refresh();
                          toast({ title: "Approved", description: "Submission approved." });
                        }}
                      >
                        Approve
                      </Button>
                      <Button
                        variant="destructive"
                        disabled={s.status === "Rejected"}
                        onClick={async () => {
                          if (isDemo) {
                            const ts = new Date().toISOString();
                            saveSubmissionStatusOverride(s.id, "Rejected", ts);
                            setItems(demoSubmissionsList());
                            toast({ title: "Rejected", description: "Submission rejected (demo)." });
                            return;
                          }
                          await reviewSubmission({ submissionId: s.id, status: "Rejected" });
                          await refresh();
                          toast({ title: "Rejected", description: "Submission rejected." });
                        }}
                      >
                        Reject
                      </Button>
                    </div>
                  </div>

                  <SubmissionScoreControls submission={s} isDemo={isDemo} onSaved={refresh} />
                </div>
              );
            })}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
