import { FormEvent, useEffect, useState } from "react";
import { useLocation } from "wouter";
import Navbar from "@/components/layout/Navbar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { setStudentDomain, resetStudentWorkspace, getStudentDomain } from "@/lib/onboarding";
import { saveStudentProfileCache } from "@/lib/student-consistency";

export default function StudentOnboarding() {
  const [, setLocation] = useLocation();
  const [domain, setDomain] = useState("");
  const [name, setName] = useState("");

  useEffect(() => {
    const existing = getStudentDomain();
    if (existing) setLocation("/student-dashboard");
  }, [setLocation]);

  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();

    resetStudentWorkspace();
    setStudentDomain(domain.trim());

    saveStudentProfileCache({
      name: name.trim() || "New Student",
      careerGoal: "",
      readinessScore: 0,
      skills: [],
      bio: "",
      githubUrl: "",
      linkedinUrl: "",
    });

    setLocation("/student-dashboard");
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      <main className="flex-1 px-4 py-16">
        <div className="max-w-xl mx-auto space-y-6">
          <div className="text-center space-y-2">
            <h1 className="text-3xl font-bold tracking-tight">Set your domain</h1>
            <p className="text-muted-foreground">
              Choose what you want to become. We’ll personalize your dashboard from scratch.
            </p>
          </div>

          <Card className="border-primary/20 shadow-[0_0_30px_rgba(16,185,129,0.08)]">
            <CardHeader>
              <CardTitle>Student Onboarding</CardTitle>
            </CardHeader>
            <CardContent>
              <form className="space-y-4" onSubmit={handleSubmit}>
                <div className="space-y-2">
                  <Label htmlFor="onboarding-name">Your Name</Label>
                  <Input
                    id="onboarding-name"
                    placeholder="e.g. Ashva"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="onboarding-domain">Target Domain</Label>
                  <Input
                    id="onboarding-domain"
                    placeholder="e.g. Backend Developer, Data Scientist, Full Stack Developer"
                    value={domain}
                    onChange={(e) => setDomain(e.target.value)}
                    required
                  />
                </div>
                <Button className="w-full" type="submit" disabled={!domain.trim()} data-testid="student-onboarding-submit">
                  Start My Dashboard
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}

