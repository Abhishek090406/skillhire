import { FormEvent, useState } from "react";
import { Link, useLocation } from "wouter";
import Navbar from "@/components/layout/Navbar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/lib/supabase/client";
import { ensureSeedDemoDataToSupabase } from "@/lib/supabase/data";

export default function CompanyLogin() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    setIsSubmitting(true);
    localStorage.setItem("skillhire_role", "company");
    localStorage.setItem("skillhire_auth_email", email.toLowerCase());
    setLocation("/company-dashboard");
    setIsSubmitting(false);

    const result = await Promise.race([
      supabase.auth.signInWithPassword({ email, password }),
      new Promise<never>((_, reject) => setTimeout(() => reject(new Error("timeout")), 2000)),
    ]).catch(() => null);

    if (result && "error" in result && !result.error) {
      toast({ title: "Welcome back", description: "Signed in successfully." });
    }

    void ensureSeedDemoDataToSupabase();
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      <main className="flex-1 px-4 py-16">
        <div className="max-w-md mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>Company Login</CardTitle>
            </CardHeader>
            <CardContent>
              <form className="space-y-4" onSubmit={handleSubmit}>
              <div className="space-y-2">
                <Label htmlFor="company-email">Work Email</Label>
                <Input id="company-email" type="email" placeholder="hiring@company.com" value={email} onChange={(e) => setEmail(e.target.value)} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="company-password">Password</Label>
                <Input id="company-password" type="password" placeholder="********" value={password} onChange={(e) => setPassword(e.target.value)} required />
              </div>
              <Button className="w-full" type="submit" disabled={isSubmitting} data-testid="company-login-submit">
                Continue to Company Portal
              </Button>
              <p className="text-sm text-muted-foreground">
                Looking for opportunities? <Link href="/login/student" className="text-primary hover:underline">Go to Student Login</Link>
              </p>
              <p className="text-sm text-muted-foreground">
                New company? <Link href="/signup/company" className="text-primary hover:underline">Create Company Account</Link>
              </p>
              </form>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
