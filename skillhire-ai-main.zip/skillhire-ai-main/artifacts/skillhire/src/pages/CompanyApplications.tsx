import DashboardLayout from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useEffect, useMemo, useState } from "react";
import { useLocation } from "wouter";
import { demoJobs } from "@/lib/demo-data";
import { fetchJobsFromSupabase } from "@/lib/supabase/data";
import {
  loadApplications,
  saveApplications,
  updateApplicationStatus,
  type ApplicationStatus,
  type JobApplication,
} from "@/lib/hiring-workflow";
import { StatusBadge } from "@/components/jobs-workflow/StatusBadge";
import { buildCompanyApplicationsFallback } from "@/lib/company-pipeline-demo";
import {
  applyJobApplicationOverrides,
  clearApplicationStatusOverride,
} from "@/lib/company-demo-overrides";
import { getScopedStorageKey } from "@/lib/session-scope";

function loadMergedApplications(): JobApplication[] {
  let apps = loadApplications();
  if (apps.length === 0) {
    saveApplications(buildCompanyApplicationsFallback());
    apps = loadApplications();
  }
  return applyJobApplicationOverrides(apps);
}

export default function CompanyApplications() {
  const [location] = useLocation();
  const [apps, setApps] = useState<JobApplication[]>(() => loadMergedApplications());
  const [supabaseJobs, setSupabaseJobs] = useState<typeof demoJobs | null>(null);

  useEffect(() => {
    const loadJobs = async () => {
      const rows = await fetchJobsFromSupabase();
      if (rows && rows.length > 0) setSupabaseJobs(rows);
    };
    void loadJobs();
  }, []);

  useEffect(() => {
    setApps(loadMergedApplications());
  }, [location]);

  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (
        !e.key ||
        e.key.includes("skillhire_appliedJobs_v1") ||
        e.key === getScopedStorageKey("skillhire_company_demo_application_status_v1")
      ) {
        setApps(loadMergedApplications());
      }
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  const displayedApps = apps;

  const jobs =
    (Array.isArray(supabaseJobs) && supabaseJobs.length > 0 && supabaseJobs) ||
    demoJobs;

  const jobById = useMemo(() => new Map(jobs.map((j) => [j.id, j])), [jobs]);

  const setStatus = (applicationId: string, status: ApplicationStatus) => {
    clearApplicationStatusOverride(applicationId);
    updateApplicationStatus(applicationId, status);
    setApps(loadMergedApplications());
  };

  return (
    <DashboardLayout mode="company">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Applications</h1>
          <p className="text-muted-foreground">Review incoming applications for your jobs and projects.</p>
        </div>
        <Card>
          <CardHeader>
            <CardTitle>Recent Applications</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {displayedApps.map((a) => {
                  const job = jobById.get(a.jobId);
                  return (
                    <div
                      key={a.applicationId}
                      className="p-4 rounded-lg border border-border bg-secondary/10 flex flex-col gap-3"
                    >
                      <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-3">
                        <div className="space-y-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <div className="font-semibold text-lg">{a.studentName}</div>
                            <StatusBadge status={a.status} />
                            <Badge variant="outline" className="text-xs">
                              {new Date(a.timestamp).toLocaleString()}
                            </Badge>
                          </div>
                          <div className="text-sm text-muted-foreground">
                            Applied for: <span className="text-foreground font-medium">{job?.title ?? `Job #${a.jobId}`}</span>
                          </div>
                          <div className="text-sm text-muted-foreground">
                            GitHub:{" "}
                            <a className="text-primary underline underline-offset-2" href={a.githubLink} target="_blank" rel="noreferrer">
                              {a.githubLink}
                            </a>
                          </div>
                          {a.portfolioLink ? (
                            <div className="text-sm text-muted-foreground">
                              Portfolio:{" "}
                              <a className="text-primary underline underline-offset-2" href={a.portfolioLink} target="_blank" rel="noreferrer">
                                {a.portfolioLink}
                              </a>
                            </div>
                          ) : null}
                        </div>

                        <div className="flex flex-wrap gap-2">
                          <Button
                            variant="outline"
                            className="border-primary/30"
                            onClick={() => setStatus(a.applicationId, "Under Review")}
                            disabled={a.status === "Under Review" || a.status === "Approved" || a.status === "Rejected"}
                          >
                            Under Review
                          </Button>
                          <Button
                            className="bg-primary hover:bg-primary/90 text-primary-foreground glow-green"
                            onClick={() => setStatus(a.applicationId, "Approved")}
                            disabled={a.status === "Approved"}
                          >
                            Approve
                          </Button>
                          <Button
                            variant="destructive"
                            onClick={() => setStatus(a.applicationId, "Rejected")}
                            disabled={a.status === "Rejected"}
                          >
                            Reject
                          </Button>
                        </div>
                      </div>
                    </div>
                  );
                })}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
