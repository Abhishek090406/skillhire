import DashboardLayout from "@/components/layout/DashboardLayout";
import {
  useGetDashboardSummary,
  getGetDashboardSummaryQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Users, Briefcase, Building2, TrendingUp, ExternalLink, ShieldCheck } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { demoCompanySummary } from "@/lib/demo-data";
import type { ApplicationStatus } from "@/lib/hiring-workflow";
import { StatusBadge } from "@/components/jobs-workflow/StatusBadge";
import { listAllApplicationsForCompany, listAllSubmissionsForCompany, reviewApplication, subscribeToSubmissions } from "@/lib/supabase/hiring";
import { seedMockData } from "@/lib/supabase/seed";
import { calculateSubmissionScore } from "@/lib/project-scoring";
import { fetchRankedTopCandidates, type RankedCandidate } from "@/lib/top-candidates";
import { TopCandidatesSection } from "@/components/company-dashboard/TopCandidatesSection";
import { useToast } from "@/hooks/use-toast";
import {
  buildCompanyDashboardFallbackApplications,
  buildCompanyDashboardFallbackSubmissions,
} from "@/lib/company-pipeline-demo";
import {
  applyApplicationStatusOverrides,
  applySubmissionStatusOverrides,
  saveApplicationStatusOverride,
} from "@/lib/company-demo-overrides";
import { getScopedStorageKey } from "@/lib/session-scope";

function shortlistStorageKey() {
  return getScopedStorageKey("skillhire_company_shortlist");
}

function mergeDashboardApplications(apps: any[]) {
  if (apps.length > 0) return apps;
  return applyApplicationStatusOverrides(buildCompanyDashboardFallbackApplications());
}

function mergeDashboardSubmissions(subs: any[]) {
  if (subs.length > 0) return subs;
  return applySubmissionStatusOverrides(buildCompanyDashboardFallbackSubmissions());
}

export default function CompanyDashboard() {
  const { toast } = useToast();
  const { data: summaryData, isLoading: isSummaryLoading, isError: isSummaryError } = useGetDashboardSummary({
    query: { queryKey: getGetDashboardSummaryQueryKey() }
  });
  const summary = {
    ...(summaryData ?? demoCompanySummary),
  };
  const [applications, setApplications] = useState<any[]>([]);
  const [submissions, setSubmissions] = useState<any[]>([]);
  const [seedInfo, setSeedInfo] = useState<string | null>(null);
  const [topCandidates, setTopCandidates] = useState<RankedCandidate[]>([]);
  const [topCandidatesLoading, setTopCandidatesLoading] = useState(true);
  const lastTopCandidatesRef = useRef<RankedCandidate[]>([]);

  useEffect(() => {
    const refresh = async () => {
      try {
        const [apps, subs] = await Promise.all([listAllApplicationsForCompany(), listAllSubmissionsForCompany()]);
        setApplications(mergeDashboardApplications(apps));
        setSubmissions(mergeDashboardSubmissions(subs));

        if (apps.length === 0 && subs.length === 0) {
          const seeded = await seedMockData();
          if (seeded.seeded) {
            setSeedInfo("Demo data seeded (Supabase was empty).");
            const [apps2, subs2] = await Promise.all([listAllApplicationsForCompany(), listAllSubmissionsForCompany()]);
            setApplications(mergeDashboardApplications(apps2));
            setSubmissions(mergeDashboardSubmissions(subs2));
          } else {
            // If Supabase is empty but seeding is blocked (RLS/role/tables),
            // fall back so the dashboard is never blank.
            setSeedInfo("Live data unavailable. Showing demo data.");
            setApplications(applyApplicationStatusOverrides(buildCompanyDashboardFallbackApplications()));
            setSubmissions(applySubmissionStatusOverrides(buildCompanyDashboardFallbackSubmissions()));
          }
        }
      } catch (e: any) {
        setSeedInfo("Supabase unavailable. Showing demo fallback for presentation.");
        setApplications(applyApplicationStatusOverrides(buildCompanyDashboardFallbackApplications()));
        setSubmissions(applySubmissionStatusOverrides(buildCompanyDashboardFallbackSubmissions()));
      }
    };

    void refresh();
    const unsubscribe = subscribeToSubmissions(() => void refresh(), { debounceMs: 450 });
    return unsubscribe;
  }, []);

  useEffect(() => {
    let cancelled = false;
    const run = async () => {
      setTopCandidatesLoading(true);
      try {
        const ranked = await fetchRankedTopCandidates({
          applications,
          submissions,
          limit: 5,
        });
        if (!cancelled) {
          lastTopCandidatesRef.current = ranked;
          setTopCandidates(ranked);
        }
      } catch {
        if (!cancelled) setTopCandidates(lastTopCandidatesRef.current);
      } finally {
        if (!cancelled) setTopCandidatesLoading(false);
      }
    };
    void run();
    return () => {
      cancelled = true;
    };
  }, [applications, submissions]);

  const handleShortlist = (c: RankedCandidate) => {
    try {
      const raw = localStorage.getItem(shortlistStorageKey());
      const list = (raw ? JSON.parse(raw) : []) as { key: string; name: string; at: number }[];
      if (!Array.isArray(list)) {
        localStorage.setItem(shortlistStorageKey(), JSON.stringify([{ key: c.studentKey, name: c.name, at: Date.now() }]));
        toast({ title: "Shortlisted", description: `${c.name} saved for follow-up.` });
        return;
      }
      if (list.some((x) => x.key === c.studentKey)) {
        toast({ title: "Already shortlisted", description: `${c.name} is already on your list.` });
        return;
      }
      list.push({ key: c.studentKey, name: c.name, at: Date.now() });
      localStorage.setItem(shortlistStorageKey(), JSON.stringify(list));
      toast({ title: "Shortlisted", description: `${c.name} saved for follow-up.` });
    } catch {
      toast({ variant: "destructive", title: "Could not save", description: "Shortlist uses local storage in this demo." });
    }
  };

  const funnel = useMemo(() => {
    const applied = applications.length;
    const reviewed = applications.filter((a) => a.status !== "Applied").length;
    const approved = applications.filter((a) => a.status === "Approved").length;
    const rejected = applications.filter((a) => a.status === "Rejected").length;
    return { applied, reviewed, approved, rejected };
  }, [applications]);

  const submissionsStats = useMemo(() => {
    const submitted = submissions.filter((s) => s.status === "Pending").length;
    const approved = submissions.filter((s) => s.status === "Approved").length;
    return { submitted, approved };
  }, [submissions]);

  if (isSummaryLoading) {
    return (
      <DashboardLayout mode="company">
        <div className="space-y-6">
          <Skeleton className="h-10 w-64" />
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-32" />)}
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Skeleton className="h-96" />
            <Skeleton className="h-96" />
          </div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout mode="company">
      <div className="space-y-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Company Dashboard</h1>
            <p className="text-muted-foreground">Overview of your hiring pipeline and platform talent.</p>
            {seedInfo ? <div className="text-xs text-muted-foreground mt-1">{seedInfo}</div> : null}
          </div>
          <div className="flex gap-3">
             <Link href="/company-post-project">
               <Button variant="outline" data-testid="btn-post-project">Post Project</Button>
             </Link>
             <Link href="/company-post-job">
               <Button data-testid="btn-post-job">Post Job</Button>
             </Link>
          </div>
        </div>

        <TopCandidatesSection
          candidates={topCandidates}
          loading={topCandidatesLoading}
          onShortlist={handleShortlist}
        />

        {summary && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Applied</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{funnel.applied}</div>
                <p className="text-xs text-muted-foreground mt-1">Job applications received</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Reviewed</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-primary">{funnel.reviewed}</div>
                <p className="text-xs text-muted-foreground mt-1">Under review / final</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Approved</CardTitle>
                <Briefcase className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{funnel.approved}</div>
                <p className="text-xs text-muted-foreground mt-1">Candidates approved</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Submissions</CardTitle>
                <Building2 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{submissionsStats.submitted}</div>
                <p className="text-xs text-muted-foreground mt-1">Awaiting verification</p>
              </CardContent>
            </Card>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Recent applications</CardTitle>
              <CardDescription>Review GitHub proof and move candidates forward.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {applications.length === 0 ? (
                <div className="text-sm text-muted-foreground">No applications yet.</div>
              ) : (
                applications.map((a) => (
                  <div key={a.id} className="p-4 rounded-lg border border-border bg-secondary/10 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <div className="font-semibold">
                          {(() => {
                            const sid = String(a.student_user_id);
                            return sid.length > 12 && sid.includes("-") ? `${sid.slice(0, 8)}…` : sid;
                          })()}
                        </div>
                        <StatusBadge status={a.status as ApplicationStatus} />
                        <Badge variant="secondary" className="text-xs">{a.job_title}</Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {a.github_link ? (
                          <a className="text-primary underline underline-offset-2" href={a.github_link} target="_blank" rel="noreferrer">
                          View GitHub submission <ExternalLink className="w-4 h-4 inline ml-1" />
                          </a>
                        ) : (
                          <span>No GitHub link provided.</span>
                        )}
                      </div>
                      <div className="text-xs text-muted-foreground">{new Date(a.created_at).toLocaleString()}</div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-primary/30"
                        disabled={a.status !== "Applied"}
                        onClick={async () => {
                          if (String(a.id).startsWith("demo-")) {
                            saveApplicationStatusOverride(a.id, "Under Review");
                            setApplications(applyApplicationStatusOverrides(buildCompanyDashboardFallbackApplications()));
                            toast({ title: "Status updated", description: "Marked under review (demo)." });
                            return;
                          }
                          await reviewApplication({ applicationId: a.id, status: "Under Review" });
                          const apps2 = await listAllApplicationsForCompany();
                          setApplications(mergeDashboardApplications(apps2));
                          toast({ title: "Status updated", description: "Marked under review." });
                        }}
                      >
                        Review
                      </Button>
                      <Button
                        size="sm"
                        className="bg-primary hover:bg-primary/90 text-primary-foreground glow-green"
                        disabled={a.status === "Approved"}
                        onClick={async () => {
                          if (String(a.id).startsWith("demo-")) {
                            saveApplicationStatusOverride(a.id, "Approved");
                            setApplications(applyApplicationStatusOverrides(buildCompanyDashboardFallbackApplications()));
                            toast({ title: "Approved", description: "Candidate approved (demo)." });
                            return;
                          }
                          await reviewApplication({ applicationId: a.id, status: "Approved" });
                          const apps2 = await listAllApplicationsForCompany();
                          setApplications(mergeDashboardApplications(apps2));
                          toast({ title: "Approved", description: "Application approved." });
                        }}
                      >
                        Approve
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        disabled={a.status === "Rejected"}
                        onClick={async () => {
                          if (String(a.id).startsWith("demo-")) {
                            saveApplicationStatusOverride(a.id, "Rejected");
                            setApplications(applyApplicationStatusOverrides(buildCompanyDashboardFallbackApplications()));
                            toast({ title: "Rejected", description: "Application rejected (demo)." });
                            return;
                          }
                          await reviewApplication({ applicationId: a.id, status: "Rejected" });
                          const apps2 = await listAllApplicationsForCompany();
                          setApplications(mergeDashboardApplications(apps2));
                          toast({ title: "Rejected", description: "Application rejected." });
                        }}
                      >
                        Reject
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Quick actions</CardTitle>
                <CardDescription>Core admin workflows</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                <Link href="/company-applications">
                  <Button variant="secondary" className="w-full">Open Applications</Button>
                </Link>
                <Link href="/company-submissions">
                  <Button variant="secondary" className="w-full">
                    <ShieldCheck className="w-4 h-4 mr-2" />
                    Verify Submissions ({submissionsStats.submitted})
                  </Button>
                </Link>
                <Link href="/company-post-job">
                  <Button className="w-full">Post Job</Button>
                </Link>
                <Link href="/company-post-project">
                  <Button variant="outline" className="w-full border-primary/30">Post Project</Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Recent submissions</CardTitle>
              <CardDescription>GitHub proof waiting for verification.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {submissions.length === 0 ? (
                <div className="text-sm text-muted-foreground">No submissions yet.</div>
              ) : (
                submissions.map((s) => (
                  <div key={s.id} className="p-4 rounded-lg border border-border bg-secondary/10 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <Badge variant="secondary" className="text-xs">{s.project_title}</Badge>
                        <Badge variant="outline" className={s.status === "Approved" ? "border-primary/30 text-primary bg-primary/5" : ""}>
                          {s.status}
                        </Badge>
                        <Badge variant="secondary" className="text-xs">Skill: {s.skill}</Badge>
                        <Badge variant="outline" className="text-xs border-primary/30 text-primary">
                          Score: {(typeof s.score === "number" ? s.score : calculateSubmissionScore(s.github_link, s.project_title))}/100
                        </Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        <a className="text-primary underline underline-offset-2" href={s.github_link} target="_blank" rel="noreferrer">
                          {s.github_link} <ExternalLink className="w-4 h-4 inline ml-1" />
                        </a>
                      </div>
                      <div className="text-xs text-muted-foreground">{new Date(s.created_at).toLocaleString()}</div>
                    </div>
                    <Link href="/company-submissions">
                      <Button variant="secondary">Open Review</Button>
                    </Link>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
