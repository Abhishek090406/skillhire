import { Link } from "wouter";
import Navbar from "@/components/layout/Navbar";
import { Button } from "@/components/ui/button";
import { ArrowRight, Target, Route, Briefcase, Building2, CheckCircle2, ShieldCheck, Sparkles } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-20 md:py-32 px-4 relative overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/20 via-background to-background pointer-events-none" />
          <div className="absolute -top-24 -left-24 w-72 h-72 rounded-full bg-primary/20 blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -right-24 w-80 h-80 rounded-full bg-primary/10 blur-3xl pointer-events-none" />
          <div className="container mx-auto text-center relative z-10 max-w-4xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-secondary/50 border border-border text-sm font-medium mb-8">
              <span className="flex h-2 w-2 rounded-full bg-primary animate-pulse"></span>
              The Industry Readiness Platform
            </div>
            <h1 className="text-5xl md:text-7xl font-bold tracking-tighter mb-6">
              Bridge the Gap Between <br className="hidden md:block" />
              <span className="text-primary">Learning and Industry</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-10 max-w-2xl mx-auto">
              Discover what skills the industry actually wants, get a personalized roadmap to acquire them, and connect with real-world projects and companies hiring now.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href="/login/student">
                <Button size="lg" className="w-full sm:w-auto h-12 px-8 text-lg gap-2" data-testid="hero-get-started">
                  Get Started as Student <ArrowRight className="w-5 h-5" />
                </Button>
              </Link>
              <Link href="/login/company">
                <Button size="lg" variant="outline" className="w-full sm:w-auto h-12 px-8 text-lg" data-testid="hero-hire-talent">
                  Hire Talent
                </Button>
              </Link>
            </div>
            <div className="mt-10 grid grid-cols-1 sm:grid-cols-3 gap-4 text-left">
              <div className="rounded-xl border border-border bg-card/60 backdrop-blur p-4">
                <div className="text-2xl font-bold text-primary">3x</div>
                <p className="text-sm text-muted-foreground">Faster role readiness with guided next actions</p>
              </div>
              <div className="rounded-xl border border-border bg-card/60 backdrop-blur p-4">
                <div className="text-2xl font-bold text-primary">100%</div>
                <p className="text-sm text-muted-foreground">Proof-based candidate workflows for recruiters</p>
              </div>
              <div className="rounded-xl border border-border bg-card/60 backdrop-blur p-4">
                <div className="text-2xl font-bold text-primary">Real-time</div>
                <p className="text-sm text-muted-foreground">Status updates across applications and submissions</p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 px-4">
          <div className="container mx-auto max-w-5xl">
            <div className="text-center mb-10">
              <h2 className="text-3xl font-bold tracking-tight">Choose Your Role</h2>
              <p className="text-muted-foreground mt-2">Sign in to the portal built for your goals.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Link href="/login/student">
                <div className="rounded-xl border border-border bg-card p-6 hover:border-primary/40 transition-colors cursor-pointer">
                  <h3 className="text-xl font-semibold mb-2">Student Login</h3>
                  <p className="text-muted-foreground">Find projects, improve skills, and get hired.</p>
                </div>
              </Link>
              <Link href="/login/company">
                <div className="rounded-xl border border-border bg-card p-6 hover:border-primary/40 transition-colors cursor-pointer">
                  <h3 className="text-xl font-semibold mb-2">Company Login</h3>
                  <p className="text-muted-foreground">Discover and hire industry-ready talent.</p>
                </div>
              </Link>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 bg-secondary/30 border-y border-border">
          <div className="container mx-auto px-4">
            <div className="max-w-2xl mx-auto text-center mb-10">
              <h2 className="text-3xl font-bold tracking-tight">Why teams choose SkillHire AI</h2>
              <p className="text-muted-foreground mt-2">Built to make student progress measurable and hiring decisions evidence-driven.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="bg-card p-6 rounded-xl border border-border shadow-sm">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center text-primary mb-4">
                  <Target className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold mb-2">Skill Gap Analysis</h3>
                <p className="text-muted-foreground">Compare your current skills against real-time industry demands and pinpoint exactly what you need to learn.</p>
              </div>
              <div className="bg-card p-6 rounded-xl border border-border shadow-sm">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center text-primary mb-4">
                  <Route className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold mb-2">Personalized Learning</h3>
                <p className="text-muted-foreground">Get a dynamic, step-by-step roadmap tailored to your career goals and current proficiency level.</p>
              </div>
              <div className="bg-card p-6 rounded-xl border border-border shadow-sm">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center text-primary mb-4">
                  <Briefcase className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold mb-2">Real-World Projects</h3>
                <p className="text-muted-foreground">Build your portfolio by working on actual projects posted by tech companies looking for talent.</p>
              </div>
              <div className="bg-card p-6 rounded-xl border border-border shadow-sm">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center text-primary mb-4">
                  <Building2 className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold mb-2">Job Matching</h3>
                <p className="text-muted-foreground">Get matched with internships and jobs based on your readiness score and verified project experience.</p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 px-4">
          <div className="container mx-auto max-w-6xl grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="rounded-xl border border-border bg-card p-6">
              <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center mb-4">
                <Sparkles className="w-5 h-5" />
              </div>
              <h3 className="text-xl font-semibold">Step 1: Diagnose</h3>
              <p className="text-muted-foreground mt-2">Run skill-gap analysis to see exactly what is missing for your target role.</p>
            </div>
            <div className="rounded-xl border border-border bg-card p-6">
              <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center mb-4">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <h3 className="text-xl font-semibold">Step 2: Prove</h3>
              <p className="text-muted-foreground mt-2">Complete challenges and submit GitHub proof so skills are verifiable, not self-claimed.</p>
            </div>
            <div className="rounded-xl border border-border bg-card p-6">
              <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center mb-4">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h3 className="text-xl font-semibold">Step 3: Get Hired</h3>
              <p className="text-muted-foreground mt-2">Recruiters review real evidence and move top candidates through the hiring pipeline.</p>
            </div>
          </div>
        </section>

        <section className="pb-20 px-4">
          <div className="container mx-auto max-w-5xl rounded-2xl border border-primary/30 bg-primary/10 p-8 md:p-10 text-center">
            <h3 className="text-2xl md:text-3xl font-bold tracking-tight">Ready to prove your skills with real outcomes?</h3>
            <p className="text-muted-foreground mt-3 max-w-2xl mx-auto">
              Join as a student to build a proof-backed profile, or sign in as a company to discover verified, industry-ready talent.
            </p>
            <div className="mt-6 flex flex-col sm:flex-row justify-center gap-3">
              <Link href="/login/student">
                <Button size="lg" className="gap-2">
                  Start as Student <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
              <Link href="/login/company">
                <Button size="lg" variant="outline">
                  Explore Company Portal
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </main>
      
      <footer className="border-t border-border py-8 text-center text-muted-foreground">
        <p>© 2024 SkillHire AI. All rights reserved.</p>
      </footer>
    </div>
  );
}
