import { useEffect, useMemo, useState } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { useListMentors, useRequestMentor, getListMentorsQueryKey } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { demoMentors } from "@/lib/demo-data";
import { fetchMentorsFromSupabase } from "@/lib/supabase/data";
import { BookingModal } from "@/components/mentors/BookingModal";
import { MentorCard, type Mentor } from "@/components/mentors/MentorCard";
import { RecommendedMentor } from "@/components/mentors/RecommendedMentor";
import {
  createMentorBooking,
  getImpactMetric,
  getMentorMatch,
  getSessionBenefits,
  getSkillGapContext,
  isMentorBooked,
  loadMentorBookings,
  mentorStatus,
} from "@/lib/mentorship";
import { ensureCurrentStudentIdForSession, getCurrentStudentId } from "@/lib/current-student";

export default function Mentors() {
  const { data, isLoading, isError } = useListMentors({
    query: { queryKey: getListMentorsQueryKey() }
  });

  const requestMutation = useRequestMentor();
  const { toast } = useToast();
  
  const [bookingOpen, setBookingOpen] = useState(false);
  const [activeMentor, setActiveMentor] = useState<Mentor | null>(null);
  const [supabaseMentors, setSupabaseMentors] = useState<typeof demoMentors | null>(null);
  const [bookingsCount, setBookingsCount] = useState(() => loadMentorBookings().length);
  const mentors =
    (Array.isArray(supabaseMentors) && supabaseMentors.length > 0 && supabaseMentors) ||
    (Array.isArray(data) && data.length > 0 ? data : demoMentors);

  useEffect(() => {
    ensureCurrentStudentIdForSession();
  }, []);

  useEffect(() => {
    const loadMentors = async () => {
      const rows = await fetchMentorsFromSupabase();
      if (rows && rows.length > 0) setSupabaseMentors(rows);
    };
    void loadMentors();
  }, []);

  const gap = useMemo(() => getSkillGapContext(), [bookingsCount]);

  const rankedMentors = useMemo(() => {
    return (mentors as Mentor[]).map((m) => {
      const match = getMentorMatch({
        mentorExpertise: m.expertise ?? [],
        missingSkills: gap.missingSkills,
        targetRole: gap.targetRole,
      });
      const booked = isMentorBooked(m.id);
      const statusLabel = mentorStatus(Boolean(m.available));
      const benefits = getSessionBenefits();
      const impactMetric = getImpactMetric(m.id);
      const whyThisMentor =
        match.relevantSkills.length > 0
          ? `Best for closing your gaps in ${match.relevantSkills.slice(0, 2).join(" & ")}.`
          : `Great for portfolio, interviews, and overall ${gap.targetRole} growth.`;
      return { mentor: m, match, booked, statusLabel, benefits, impactMetric, whyThisMentor };
    }).sort((a, b) => b.match.matchPercent - a.match.matchPercent);
  }, [mentors, gap.missingSkills, gap.targetRole, bookingsCount]);

  const top = rankedMentors[0] ?? null;

  const openBook = (mentor: Mentor) => {
    setActiveMentor(mentor);
    setBookingOpen(true);
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Industry Mentors</h1>
          <p className="text-muted-foreground">Connect with experts to guide your career journey.</p>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map(i => <Skeleton key={i} className="h-72 w-full" />)}
          </div>
        ) : (
          <div className="space-y-6">
            {top ? (
              <RecommendedMentor
                name={top.mentor.name}
                title={top.mentor.title}
                company={top.mentor.company}
                matchPercent={top.match.matchPercent}
                reason={top.match.reason}
                relevantSkills={top.match.relevantSkills}
                onBook={() => openBook(top.mentor)}
                booked={top.booked}
                available={Boolean(top.mentor.available)}
              />
            ) : null}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {mentors.length === 0 ? (
                <div className="col-span-full py-12 text-center text-muted-foreground bg-secondary/20 rounded-xl border border-dashed border-border">
                  No mentors available at the moment.
                </div>
              ) : (
                rankedMentors.map(({ mentor, match, booked, statusLabel, benefits, impactMetric, whyThisMentor }) => (
                  <MentorCard
                    key={mentor.id}
                    mentor={mentor}
                    matchPercent={match.matchPercent}
                    relevantSkills={match.relevantSkills}
                    whyThisMentor={whyThisMentor}
                    benefits={benefits}
                    impactMetric={impactMetric}
                    statusLabel={statusLabel}
                    booked={booked}
                    onBook={() => openBook(mentor)}
                  />
                ))
              )}
            </div>
          </div>
        )}
      </div>

      <BookingModal
        open={bookingOpen}
        onOpenChange={setBookingOpen}
        mentorName={activeMentor?.name ?? "this mentor"}
        onSubmit={({ sessionType, dateTime, goal }) => {
          if (!activeMentor) return;
          createMentorBooking({
            mentorId: activeMentor.id,
            sessionType,
            dateTime,
            goal,
          });

          // Keep existing API request in the background (demo), but localStorage is the source of truth for booking state.
          requestMutation.mutate({
            id: activeMentor.id,
            data: {
              studentId: getCurrentStudentId(),
              topic: sessionType,
              message: `${goal}\n\nPreferred time: ${dateTime}`,
            },
          });

          toast({
            title: "Session Booked",
            description: `Booked ${sessionType} with ${activeMentor.name}.`,
          });
          setBookingsCount(loadMentorBookings().length);
          setBookingOpen(false);
        }}
      />
    </DashboardLayout>
  );
}
