import DashboardLayout from "@/components/layout/DashboardLayout";
import { useGetStudentDashboard, getGetStudentDashboardQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { RadialBarChart, RadialBar, PolarAngleAxis, ResponsiveContainer } from "recharts";
import { Link, useLocation } from "wouter";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ArrowRight, BookOpen, Briefcase, Building2, CheckCircle2, FileText, ListChecks, Zap } from "lucide-react";
import { demoStudentDashboard } from "@/lib/demo-data";
import { loadSkillGapResult } from "@/lib/skill-gap";
import { unifyStudentData } from "@/lib/student-consistency";
import { NextActionCard } from "@/components/student-dashboard/NextActionCard";
import { ReadinessCard } from "@/components/student-dashboard/ReadinessCard";
import { SkillGapFeedback } from "@/components/student-dashboard/SkillGapFeedback";
import { SkillCard } from "@/components/student-dashboard/SkillCard";
import { ProjectCard } from "@/components/student-dashboard/ProjectCard";
import { JobMatchCard } from "@/components/student-dashboard/JobMatchCard";
import { ActivityTimeline, ActivityItem } from "@/components/student-dashboard/ActivityTimeline";
import { getStudentDomain } from "@/lib/onboarding";
import { ensureCurrentStudentIdForSession, getCurrentStudentId } from "@/lib/current-student";

export default function StudentDashboard() {
  const [, setLocation] = useLocation();
  useEffect(() => {
    ensureCurrentStudentIdForSession();
  }, []);

  const studentId = getCurrentStudentId();

  const { data, isLoading, isError } = useGetStudentDashboard(studentId, {
    query: {
      enabled: true,
      queryKey: getGetStudentDashboardQueryKey(studentId),
    },
  });

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="space-y-6">
          <Skeleton className="h-10 w-64" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Skeleton className="h-64" />
            <Skeleton className="h-64 md:col-span-2" />
          </div>
          <Skeleton className="h-96" />
        </div>
      </DashboardLayout>
    );
  }

  const dashboard = !isError && data?.student ? data : demoStudentDashboard;
  const savedGap = loadSkillGapResult();

  const { student, recommendedSkills, suggestedProjects, recommendedJobs } = dashboard;
  const displayedStudent = unifyStudentData({
    ...student,
    skills: Array.isArray((student as { skills?: unknown }).skills)
      ? ((student as { skills: string[] }).skills)
      : [],
  }) as typeof student & { skills: string[] };
  const displayedRecommendedSkills = savedGap?.missingSkills ?? recommendedSkills;
  const domain = getStudentDomain();
  
  const chartData = [{ name: "Readiness", value: displayedStudent.readinessScore, fill: "hsl(var(--primary))" }];
  const learningVelocityScore = Math.min(
    100,
    Math.max(45, Math.round(displayedStudent.readinessScore * 0.55 + displayedStudent.profileCompletion * 0.45))
  );
  const behavioralFitScore = Math.min(
    100,
    Math.max(40, Math.round(displayedStudent.readinessScore * 0.65 + Math.min(displayedRecommendedSkills.length, 6) * 5))
  );
  const learningVelocityStatus =
    learningVelocityScore >= 80
      ? "Fast progress momentum. You are on track for interviews."
      : learningVelocityScore >= 65
      ? "Steady progress. Complete one more project to accelerate outcomes."
      : "Early momentum. Follow your learning path consistently this week.";
  const behavioralFitStatus =
    behavioralFitScore >= 80
      ? "Strong workplace fit signals for team-based roles."
      : behavioralFitScore >= 65
      ? "Good fit baseline. Improve communication and collaboration evidence."
      : "Fit signals are developing. Add mentorship and project collaboration.";

  const missingSkillsRanked = displayedRecommendedSkills.slice(0, 3).map((name, idx) => ({
    name,
    priority: idx === 0 ? "Critical" : idx === 1 ? "High" : "Medium",
  })) as { name: string; priority: "Critical" | "High" | "Medium" }[];

  const readinessSuggestions = [
    missingSkillsRanked[0]?.name ? `Learn ${missingSkillsRanked[0].name} fundamentals.` : "Complete a targeted learning module.",
    "Complete 1 portfolio-grade project for evidence.",
    "Run a short assessment and update your profile skills.",
  ];

  const nextBestSkill = missingSkillsRanked[0]?.name ?? null;
  const nextBestMessage = nextBestSkill
    ? `Complete ${nextBestSkill} Basics to increase readiness from ${displayedStudent.readinessScore}% → ${Math.min(100, displayedStudent.readinessScore + 15)}%.`
    : `Run a Skill Gap Analysis to generate your fastest path to getting hired.`;

  const intelligentSkills = displayedRecommendedSkills.slice(0, 6).map((skill, idx) => ({
    skill,
    priority: idx < 2 ? "High" : idx < 4 ? "Medium" : "Low",
    reason:
      idx < 2
        ? `High-impact for ${displayedStudent.careerGoal || "your goal"} and frequently required across listings.`
        : idx < 4
        ? `Improves shortlisting and helps you ship projects faster.`
        : `Nice-to-have that strengthens your overall profile.`,
  })) as { skill: string; priority: "High" | "Medium" | "Low"; reason: string }[];

  const enhancedProjects = suggestedProjects.slice(0, 3).map((p, index) => ({
    id: p.id,
    title: p.title,
    company: p.companyName,
    context: index === 0 ? "Used by startups" : index === 1 ? "Common in product teams" : "Great for portfolios",
    skillsGained: displayedRecommendedSkills.slice(0, 3).length ? displayedRecommendedSkills.slice(0, 3) : ["Problem Solving", "Delivery", "Communication"],
    boostPercent: 8 + index * 4,
  }));

  const demoMatches = [
    { role: "Frontend Intern", company: "StartupX", matchPercent: 82, missingSkill: missingSkillsRanked[0]?.name },
    { role: "Backend Intern", company: "CloudNest", matchPercent: 74, missingSkill: missingSkillsRanked[1]?.name },
    { role: "Full Stack Trainee", company: "ProductForge", matchPercent: 68, missingSkill: missingSkillsRanked[2]?.name },
  ];

  const activity: ActivityItem[] = [
    savedGap?.updatedAt
      ? {
          id: "analysis",
          label: `Skill Gap updated for ${savedGap.targetRole}`,
          timestampLabel: new Date(savedGap.updatedAt).toLocaleString(),
          tone: "info",
          kind: "analysis",
        }
      : null,
    {
      id: "profile",
      label: "Profile signals refreshed",
      timestampLabel: "Just now",
      tone: "warning",
      kind: "profile",
    },
  ].filter(Boolean) as ActivityItem[];

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {isError ? (
          <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-sm text-muted-foreground">
            Live student API is unavailable. Showing Skill Gap data and demo dashboard content.
          </div>
        ) : null}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Welcome back, {displayedStudent.name}</h1>
            <p className="text-muted-foreground">
              {domain ? `Domain: ${domain}` : "Personalized to your target domain."} • Your dashboard is optimized for next actions.
            </p>
          </div>
          <Link href="/skill-gap">
            <Button data-testid="dashboard-analyze-gap">Run Skill Gap Analysis</Button>
          </Link>
        </div>

        <NextActionCard
          title="Next Best Action"
          message={nextBestMessage}
          ctaLabel={nextBestSkill ? "Start Now" : "Run Analysis"}
          ctaHref={nextBestSkill ? "/learning-path" : "/skill-gap"}
        />

        <SkillGapFeedback
          role={savedGap?.targetRole ?? null}
          missingSkills={savedGap?.missingSkills ?? []}
          updatedAt={savedGap?.updatedAt}
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <ReadinessCard
            score={displayedStudent.readinessScore}
            missingSkills={missingSkillsRanked}
            suggestions={readinessSuggestions}
          />

          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle>Profile Completion</CardTitle>
              <CardDescription>A complete profile unlocks more opportunities</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-6">
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium">{displayedStudent.profileCompletion}% Complete</span>
                  <span className="text-xs text-muted-foreground">Add 1 project to unlock more opportunities</span>
                </div>
                <Progress value={displayedStudent.profileCompletion} className="h-2" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-6">
                <div className="flex items-center gap-2 p-3 rounded-lg border border-border bg-secondary/10">
                  <CheckCircle2 className="w-4 h-4 text-primary" />
                  <div className="text-sm">Skills added</div>
                </div>
                <div className="flex items-center gap-2 p-3 rounded-lg border border-border bg-secondary/10">
                  <ListChecks className="w-4 h-4 text-yellow-300" />
                  <div className="text-sm">Resume uploaded</div>
                </div>
                <div className="flex items-center gap-2 p-3 rounded-lg border border-border bg-secondary/10">
                  <Zap className="w-4 h-4 text-destructive" />
                  <div className="text-sm">Projects missing</div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h4 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Recommended Next Steps</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Link href="/profile">
                    <div className="p-3 border border-border rounded-lg flex items-start gap-3 hover:border-primary transition-colors cursor-pointer bg-secondary/20">
                      <div className="bg-primary/10 p-2 rounded-md text-primary">
                        <BookOpen className="w-4 h-4" />
                      </div>
                      <div>
                        <h5 className="font-medium text-sm">Add Certifications</h5>
                        <p className="text-xs text-muted-foreground">Boost your readiness score</p>
                      </div>
                    </div>
                  </Link>
                  <Link href="/projects">
                    <div className="p-3 border border-border rounded-lg flex items-start gap-3 hover:border-primary transition-colors cursor-pointer bg-secondary/20">
                      <div className="bg-primary/10 p-2 rounded-md text-primary">
                        <Briefcase className="w-4 h-4" />
                      </div>
                      <div>
                        <h5 className="font-medium text-sm">Complete a Project</h5>
                        <p className="text-xs text-muted-foreground">Showcase your practical skills</p>
                      </div>
                    </div>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div>
                <CardTitle>Recommended Skills to Learn</CardTitle>
                <CardDescription>Intelligent priorities for {displayedStudent.careerGoal || "your goal"}</CardDescription>
              </div>
              <Link href="/learning-path">
                <Button variant="ghost" size="sm" className="gap-1">View Path <ArrowRight className="w-4 h-4" /></Button>
              </Link>
            </CardHeader>
            <CardContent className="pt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {intelligentSkills.slice(0, 4).map((s) => (
                  <SkillCard
                    key={s.skill}
                    skill={s.skill}
                    priority={s.priority}
                    reason={s.reason}
                    onStart={() => setLocation("/learning-path")}
                  />
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div>
                <CardTitle>Suggested Projects</CardTitle>
                <CardDescription>Industry context + readiness boosts</CardDescription>
              </div>
              <Link href="/projects">
                <Button variant="ghost" size="sm" className="gap-1">Browse All <ArrowRight className="w-4 h-4" /></Button>
              </Link>
            </CardHeader>
            <CardContent className="pt-4 space-y-4">
              {enhancedProjects.map((p) => (
                <ProjectCard
                  key={p.id}
                  title={p.title}
                  company={p.company}
                  context={p.context}
                  skillsGained={p.skillsGained}
                  boostPercent={p.boostPercent}
                  onStart={() => setLocation("/projects")}
                />
              ))}
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Matches for You</CardTitle>
              <CardDescription>Opportunities ranked by fit and fastest fixes</CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4">
              {demoMatches.map((m) => (
                <JobMatchCard
                  key={`${m.company}-${m.role}`}
                  role={m.role}
                  company={m.company}
                  matchPercent={m.matchPercent}
                  missingSkill={m.missingSkill}
                  onApply={() => setLocation("/jobs")}
                />
              ))}
            </CardContent>
          </Card>

          <ActivityTimeline items={activity} />
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Learning Path Signals</CardTitle>
            <CardDescription>
              Job-readiness indicators based on your progress consistency and collaboration fit.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3 rounded-lg border border-border p-4 bg-secondary/20">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Learning Velocity</p>
                  <Badge variant="outline" className="border-primary/30 text-primary">
                    {learningVelocityScore}/100
                  </Badge>
                </div>
                <Progress value={learningVelocityScore} className="h-2" />
                <p className="text-sm text-muted-foreground">{learningVelocityStatus}</p>
              </div>

              <div className="space-y-3 rounded-lg border border-border p-4 bg-secondary/20">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Behavioral Fit</p>
                  <Badge variant="outline" className="border-primary/30 text-primary">
                    {behavioralFitScore}/100
                  </Badge>
                </div>
                <Progress value={behavioralFitScore} className="h-2" />
                <p className="text-sm text-muted-foreground">{behavioralFitStatus}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
