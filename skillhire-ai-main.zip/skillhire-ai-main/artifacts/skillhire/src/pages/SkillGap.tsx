import { useEffect, useMemo, useRef, useState } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { useAnalyzeSkillGap } from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BrainCircuit } from "lucide-react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { loadSkillGapResult, saveSkillGapResult } from "@/lib/skill-gap";
import { consumePendingResumeSkills, formatSkillTag } from "@/lib/resume-analyzer";
import { analyzeSkills, SkillGapAiResult } from "@/lib/skill-gap-ai";
import { getScopedStorageKey } from "@/lib/session-scope";
import { SkillInputForm } from "@/components/skill-gap/SkillInputForm";
import { AnalysisLoader } from "@/components/skill-gap/AnalysisLoader";
import { MissingSkillCard } from "@/components/skill-gap/MissingSkillCard";
import { ActionPlan } from "@/components/skill-gap/ActionPlan";
import { SimulationCard } from "@/components/skill-gap/SimulationCard";

const ROLE_LABELS: Record<string, string> = {
  frontend: "Frontend Developer",
  backend: "Backend Developer",
  fullstack: "Full Stack Developer",
  data: "Data Analyst",
  ml: "ML Engineer",
};

function guessRoleKey(value: string | undefined) {
  const v = (value || "").toLowerCase();
  if (v.includes("back")) return "backend";
  if (v.includes("full")) return "fullstack";
  if (v.includes("data")) return "data";
  if (v.includes("ml") || v.includes("machine")) return "ml";
  return "frontend";
}

export default function SkillGap() {
  const { toast } = useToast();
  const initialGap = loadSkillGapResult();
  const initialRoleKey = guessRoleKey(initialGap?.targetRole);
  const [targetRoleKey, setTargetRoleKey] = useState<string>(initialRoleKey);
  const [currentSkillsText, setCurrentSkillsText] = useState(
    initialGap?.currentSkills?.length ? initialGap.currentSkills.join(", ") : "React, JavaScript, HTML, CSS"
  );

  const [localAnalysis, setLocalAnalysis] = useState<SkillGapAiResult>(() => {
    if (initialGap) {
      const roleKey = guessRoleKey(initialGap.targetRole);
      return analyzeSkills(initialGap.currentSkills, ROLE_LABELS[roleKey] ?? initialGap.targetRole);
    }
    return analyzeSkills(["React", "JavaScript", "HTML", "CSS"], ROLE_LABELS.frontend);
  });
  
  const analyzeMutation = useAnalyzeSkillGap();
  const analysis = localAnalysis;

  const [aiLoading, setAiLoading] = useState(false);
  const [loaderStepIndex, setLoaderStepIndex] = useState(0);
  const timeoutRef = useRef<number | null>(null);
  const intervalRef = useRef<number | null>(null);

  const progressSteps = useMemo(
    () => [
      "Analyzing your profile…",
      "Checking industry requirements…",
      "Comparing skill benchmarks…",
      "Generating recommendations…",
    ],
    []
  );

  useEffect(() => {
    return () => {
      if (timeoutRef.current) window.clearTimeout(timeoutRef.current);
      if (intervalRef.current) window.clearInterval(intervalRef.current);
    };
  }, []);

  useEffect(() => {
    const pending = consumePendingResumeSkills();
    if (!pending?.length) return;
    setCurrentSkillsText(pending.map((s) => formatSkillTag(s)).join(", "));
    toast({
      title: "Skills applied from Resume Analyzer",
      description: "Review your current skills, then run analysis.",
    });
  }, [toast]);

  const handleAnalyze = () => {
    const skillsArray = currentSkillsText.split(",").map((s) => s.trim()).filter(Boolean);
    const careerGoal = ROLE_LABELS[targetRoleKey] ?? "Frontend Developer";

    setAiLoading(true);
    setLoaderStepIndex(0);
    if (timeoutRef.current) window.clearTimeout(timeoutRef.current);
    if (intervalRef.current) window.clearInterval(intervalRef.current);

    intervalRef.current = window.setInterval(() => {
      setLoaderStepIndex((prev) => Math.min(progressSteps.length - 1, prev + 1));
    }, 650);

    timeoutRef.current = window.setTimeout(() => {
      if (intervalRef.current) window.clearInterval(intervalRef.current);

      const result = analyzeSkills(skillsArray, careerGoal);
      setLocalAnalysis(result);
      saveSkillGapResult(result);

      // Pass missing skills into Learning Path generator (session-scoped)
      localStorage.setItem(
        getScopedStorageKey("skillhire_learning_focus_skills"),
        JSON.stringify(result.missingSkills ?? [])
      );

      // Keep existing API mutation in the background (doesn't block UX)
      analyzeMutation.mutate({
        id: 1,
        data: {
          currentSkills: skillsArray,
          careerGoal,
        },
      });

      setAiLoading(false);
    }, 2600);
  };

  const topMissing = useMemo(() => (analysis?.missingSkillInsights ?? []).slice(0, 3), [analysis]);
  const whyLowBullets = useMemo(() => {
    const missingNames = (analysis?.missingSkills ?? []).slice(0, 3);
    const a = missingNames[0] ? `You’re missing ${missingNames[0]} — a core requirement for this role.` : "You’re missing a few key role requirements.";
    const b = missingNames[1] ? `You don’t yet show evidence of ${missingNames[1]} in your current stack.` : "Your current stack doesn’t fully match the role’s expectations.";
    const c = "Closing these gaps will improve shortlisting and interview confidence.";
    return [a, b, c];
  }, [analysis]);

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Skill Gap Analysis</h1>
          <p className="text-muted-foreground">
            Discover exactly what you need to learn for your dream role. Use the{" "}
            <Link href="/resume-analyzer" className="text-primary hover:underline">
              Resume Analyzer
            </Link>{" "}
            to import skills from your resume.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1 h-fit">
            <SkillInputForm
              currentSkillsText={currentSkillsText}
              onChangeCurrentSkillsText={setCurrentSkillsText}
              targetRole={targetRoleKey}
              onChangeTargetRole={setTargetRoleKey}
              onRun={handleAnalyze}
              disabled={aiLoading || !currentSkillsText}
            />
          </div>

          <div className="lg:col-span-2 space-y-6">
            {aiLoading ? (
              <AnalysisLoader stepLabel={progressSteps[loaderStepIndex] ?? progressSteps[0]} />
            ) : analysis ? (
              <div className="space-y-8 animate-in fade-in duration-500">
                {/* 1) Hero */}
                <Card className="border-border">
                  <CardContent className="p-6 md:p-8 flex flex-col md:flex-row md:items-center md:justify-between gap-6">
                    <div className="space-y-2">
                      <div className="text-sm text-muted-foreground">Readiness Score</div>
                      <div className="text-5xl md:text-6xl font-bold text-primary leading-none">
                        {Math.round(analysis.readinessScore)}%
                      </div>
                      <div className="text-sm text-muted-foreground max-w-xl">
                        {analysis.summary}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground pt-1">
                        <BrainCircuit className="w-4 h-4" />
                        Confidence: {analysis.confidencePercent}% (benchmarked)
                      </div>
                    </div>
                    <div className="flex flex-col gap-2 w-full md:w-auto">
                      <Link href="/learning-path">
                        <Button className="w-full md:w-auto bg-primary hover:bg-primary/90 text-primary-foreground glow-green">
                          Start Learning Path
                        </Button>
                      </Link>
                      <Button
                        variant="outline"
                        className="w-full md:w-auto"
                        onClick={handleAnalyze}
                        disabled={!currentSkillsText}
                      >
                        Re-run analysis
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* 2) Why score is low */}
                <Card className="border-border">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">Why your score is low</CardTitle>
                    <CardDescription>Three clear reasons (no fluff)</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 text-sm text-muted-foreground">
                      {whyLowBullets.map((b, idx) => (
                        <li key={`why-low-${idx}`} className="flex items-start gap-2">
                          <span className="mt-2 h-1.5 w-1.5 rounded-full bg-muted-foreground/60" />
                          <span>{b}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>

                {/* 3) Top 3 missing skills */}
                <Card className="border-border">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">Top missing skills</CardTitle>
                    <CardDescription>Focus on these 3 first</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {topMissing.length ? (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {topMissing.map((s) => (
                          <MissingSkillCard
                            key={s.name}
                            name={s.name}
                            priority={s.priority}
                            explanation={s.explanation}
                          />
                        ))}
                      </div>
                    ) : (
                      <div className="text-sm text-muted-foreground">No major gaps detected.</div>
                    )}
                  </CardContent>
                </Card>

                {/* 4) Next actions (main CTA inside) */}
                <ActionPlan actions={analysis.nextBestActions ?? []} />

                {/* 5) Future outcome (optional) */}
                <div className="max-w-3xl">
                  <SimulationCard
                    currentScore={analysis.readinessScore}
                    futureScore={analysis.simulatedFutureScore}
                    outcome={analysis.simulatedOutcome}
                  />
                </div>
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
