/**
 * Demo-ready GitHub submission scoring (no external API calls).
 */
export function calculateSubmissionScore(githubLink: string, projectTitle: string): number {
  let score = 50;
  if (githubLink.toLowerCase().includes("github")) score += 10;
  if (projectTitle.length > 5) score += 10;
  // Extra demo signal so strong submissions can exceed 70 (enables readiness boost > 70).
  if (projectTitle.length > 18) score += 5;
  if (githubLink.length > 26) score += 5;
  return Math.min(score, 100);
}

export function clampSubmissionScore(raw: number): number {
  if (Number.isNaN(raw)) return 0;
  return Math.max(0, Math.min(100, Math.round(raw)));
}

export function aggregateSubmissionScores(
  rows: { score?: number | null; github_link: string; project_title: string }[]
): { top: number; average: number; count: number } {
  if (rows.length === 0) return { top: 0, average: 0, count: 0 };
  const values = rows.map((r) =>
    typeof r.score === "number" && !Number.isNaN(r.score)
      ? clampSubmissionScore(r.score)
      : calculateSubmissionScore(r.github_link, r.project_title)
  );
  const top = Math.max(...values);
  const average = Math.round(values.reduce((a, b) => a + b, 0) / values.length);
  return { top, average, count: values.length };
}
