import { getScopedStorageKey } from "@/lib/session-scope";
import { loadSkillGapResult } from "@/lib/skill-gap";
import { loadAppliedProjects } from "@/lib/project-marketplace";
import { loadApplications } from "@/lib/hiring-workflow";
import { demoProjects } from "@/lib/demo-data";
import { getVerifiedSkillsForStudent } from "@/lib/submissions";
import { getCurrentStudentId } from "@/lib/current-student";

export type SkillVerificationState = "Verified" | "Not Verified";

export type VerifiedSkill = {
  skill: string;
  state: SkillVerificationState;
  proof: "Project" | "Assessment" | null;
};

export type ProfileProjectProof = {
  projectId: number;
  name: string;
  githubLink?: string;
  liveDemo?: string;
  status: "Verified" | "Under Review";
};

export type MentorFeedbackItem = {
  id: string;
  mentorName: string;
  summary: string;
  createdAt: number;
};

const ASSESSMENTS_PASSED_KEY = "skillhire_assessments_passed"; // string[]
const PROJECT_LIVE_DEMOS_KEY = "skillhire_project_live_demos"; // Record<projectId, url>
const MENTOR_FEEDBACK_KEY = "skillhire_mentor_feedback"; // MentorFeedbackItem[]

function safeParse<T>(raw: string | null, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function normalizeSkill(s: string) {
  return s.trim().toLowerCase();
}

export function loadPassedAssessments(): string[] {
  const raw = localStorage.getItem(getScopedStorageKey(ASSESSMENTS_PASSED_KEY));
  const parsed = safeParse<unknown>(raw, []);
  if (!Array.isArray(parsed)) return [];
  return parsed.filter((x) => typeof x === "string").map((s) => s.trim()).filter(Boolean);
}

export function computeVerifiedSkills(userSkills: string[]) {
  const passed = new Set(loadPassedAssessments().map(normalizeSkill));
  const adminVerified = new Set(getVerifiedSkillsForStudent(getCurrentStudentId()).map(normalizeSkill));

  const applied = loadAppliedProjects();
  const completedProjectIds = new Set(applied.filter((p) => p.status === "Completed").map((p) => p.projectId));
  const projects = demoProjects;
  const completedProjectSkills = new Set(
    projects
      .filter((p) => completedProjectIds.has(p.id))
      .flatMap((p) => (p.requiredSkills ?? []).map(normalizeSkill))
  );

  const skills = userSkills.map((s) => s.trim()).filter(Boolean);
  const result: VerifiedSkill[] = skills.map((s) => {
    const key = normalizeSkill(s);
    if (completedProjectSkills.has(key)) return { skill: s, state: "Verified", proof: "Project" };
    if (passed.has(key)) return { skill: s, state: "Verified", proof: "Assessment" };
    if (adminVerified.has(key)) return { skill: s, state: "Verified", proof: "Assessment" };
    return { skill: s, state: "Not Verified", proof: null };
  });

  return {
    verified: result.filter((r) => r.state === "Verified"),
    all: result,
  };
}

export function getMissingSkills() {
  const gap = loadSkillGapResult();
  return Array.isArray(gap?.missingSkills) ? gap!.missingSkills : [];
}

export function computeReadinessBreakdown() {
  const gap = loadSkillGapResult();
  const skillsPercent = typeof gap?.readinessScore === "number" ? gap.readinessScore : 0;

  const applied = loadAppliedProjects();
  const completed = applied.filter((p) => p.status === "Completed").length;
  const inProgress = applied.filter((p) => p.status === "In Progress").length;
  const projectsPercent = Math.min(100, completed * 20 + inProgress * 10);

  const apps = loadApplications().filter((a) => a.studentId === getCurrentStudentId());
  const approved = apps.filter((a) => a.status === "Approved").length;
  const underReview = apps.filter((a) => a.status === "Under Review").length;
  const experiencePercent = Math.min(100, approved * 35 + underReview * 15);

  return { skillsPercent, projectsPercent, experiencePercent };
}

export function getProjectProofs(): ProfileProjectProof[] {
  const applied = loadAppliedProjects();
  const liveMapRaw = localStorage.getItem(getScopedStorageKey(PROJECT_LIVE_DEMOS_KEY));
  const liveMap = safeParse<Record<string, string>>(liveMapRaw, {});

  const projects = demoProjects;
  const projectById = new Map(projects.map((p) => [p.id, p]));

  return applied.map((a) => {
    const p = projectById.get(a.projectId);
    const name = p?.title ?? `Project #${a.projectId}`;
    const githubLink = a.githubRepoUrl;
    const liveDemo = liveMap[String(a.projectId)] || undefined;
    const status = a.status === "Completed" && githubLink ? "Verified" : "Under Review";
    return { projectId: a.projectId, name, githubLink, liveDemo, status };
  });
}

export function saveProjectLiveDemo(projectId: number, url: string) {
  const raw = localStorage.getItem(getScopedStorageKey(PROJECT_LIVE_DEMOS_KEY));
  const map = safeParse<Record<string, string>>(raw, {});
  map[String(projectId)] = url;
  localStorage.setItem(getScopedStorageKey(PROJECT_LIVE_DEMOS_KEY), JSON.stringify(map));
}

export function loadMentorFeedback(): MentorFeedbackItem[] {
  const raw = localStorage.getItem(getScopedStorageKey(MENTOR_FEEDBACK_KEY));
  const parsed = safeParse<unknown>(raw, []);
  if (!Array.isArray(parsed)) return [];
  return parsed as MentorFeedbackItem[];
}

export function ensureMockMentorFeedback() {
  const existing = loadMentorFeedback();
  if (existing.length > 0) return existing;
  const seed: MentorFeedbackItem[] = [
    {
      id: "fb-1",
      mentorName: "Priya Nair",
      summary: "Your portfolio is strong. Add one project README with metrics + write a crisp story for interviews.",
      createdAt: Date.now() - 1000 * 60 * 60 * 24 * 2,
    },
    {
      id: "fb-2",
      mentorName: "Rahul Mehta",
      summary: "Focus on TypeScript + testing evidence. Recruiters will trust your skills faster with proof links.",
      createdAt: Date.now() - 1000 * 60 * 60 * 24 * 5,
    },
  ];
  localStorage.setItem(getScopedStorageKey(MENTOR_FEEDBACK_KEY), JSON.stringify(seed));
  return seed;
}

