import { getScopedStorageKey } from "@/lib/session-scope";
import { demoStudentProfile } from "@/lib/demo-data";

const REST_STUDENT_ID_KEY = "skillhire_rest_student_id";

function djb2(s: string) {
  let h = 5381;
  for (let i = 0; i < s.length; i++) {
    h = (h * 33) ^ s.charCodeAt(i);
  }
  return Math.abs(h);
}

function storageKey() {
  return getScopedStorageKey(REST_STUDENT_ID_KEY);
}

/**
 * Numeric id for REST `/students/:id` and local demo data (seeded rows are 1–5).
 */
export function getCurrentStudentId(): number {
  if (typeof window === "undefined") return demoStudentProfile.id;
  const raw = localStorage.getItem(storageKey());
  if (!raw) return demoStudentProfile.id;
  const n = Number(raw);
  if (!Number.isFinite(n) || n < 1) return demoStudentProfile.id;
  return Math.min(99, Math.floor(n));
}

export function setCurrentStudentId(id: number) {
  const n = Math.max(1, Math.floor(id));
  localStorage.setItem(storageKey(), String(n));
}

/**
 * After login, assign a stable numeric id per session (1–5) so seeded Postgres/API rows map sensibly.
 */
export function ensureCurrentStudentIdForSession() {
  if (typeof window === "undefined") return;
  if (localStorage.getItem(storageKey())) return;
  const email = (localStorage.getItem("skillhire_auth_email") || "guest").toLowerCase();
  const id = (djb2(email) % 5) + 1;
  localStorage.setItem(storageKey(), String(id));
}
