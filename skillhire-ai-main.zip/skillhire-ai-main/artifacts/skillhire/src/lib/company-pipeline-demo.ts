/**
 * Single source of truth for company-admin demo/fallback data:
 * applications, submissions, top candidates, talent pool, and summary counts stay aligned.
 */
import { calculateSubmissionScore } from "@/lib/project-scoring";
import type { JobApplication } from "@/lib/hiring-workflow";

export type PipelineDemoPerson = {
  /** Same value used as `student_user_id` in Supabase-style dashboard rows */
  studentKey: string;
  studentId: number;
  name: string;
  role: string;
  readinessScore: number;
  verifiedSkillsCount: number;
  skills: string[];
  githubLink: string;
  portfolioLink: string;
};

export const PIPELINE_DEMO_PEOPLE: PipelineDemoPerson[] = [
  {
    studentKey: "Ashvanth M",
    studentId: 1,
    name: "Ashvanth M",
    role: "Frontend Developer",
    readinessScore: 82,
    verifiedSkillsCount: 3,
    skills: ["React", "TypeScript", "JavaScript", "CSS", "Git"],
    githubLink: "https://github.com/demo/fullstack",
    portfolioLink: "https://portfolio.demo/ashvanth",
  },
  {
    studentKey: "Rahul Verma",
    studentId: 2,
    name: "Rahul Verma",
    role: "Backend Developer",
    readinessScore: 75,
    verifiedSkillsCount: 2,
    skills: ["Node.js", "REST APIs", "PostgreSQL", "Docker"],
    githubLink: "https://github.com/demo/api",
    portfolioLink: "",
  },
  {
    studentKey: "Sneha Iyer",
    studentId: 3,
    name: "Sneha Iyer",
    role: "Full Stack Developer",
    readinessScore: 79,
    verifiedSkillsCount: 4,
    skills: ["React", "Node.js", "MongoDB", "Express", "Auth"],
    githubLink: "https://github.com/demo/auth",
    portfolioLink: "https://portfolio.demo/sneha",
  },
  {
    studentKey: "Diya Nair",
    studentId: 4,
    name: "Diya Nair",
    role: "Mobile Developer",
    readinessScore: 71,
    verifiedSkillsCount: 2,
    skills: ["React Native", "TypeScript", "REST APIs", "iOS Basics"],
    githubLink: "https://github.com/demo/mobile-kit",
    portfolioLink: "https://portfolio.demo/diya",
  },
  {
    studentKey: "Karan Mehta",
    studentId: 5,
    name: "Karan Mehta",
    role: "DevOps Engineer",
    readinessScore: 68,
    verifiedSkillsCount: 1,
    skills: ["Docker", "CI/CD", "Linux", "AWS Basics"],
    githubLink: "https://github.com/demo/infra-starter",
    portfolioLink: "",
  },
];

const BY_STUDENT_KEY = new Map(PIPELINE_DEMO_PEOPLE.map((p) => [p.studentKey, p]));

export function getPipelineDemoPerson(studentKey: string): PipelineDemoPerson | undefined {
  return BY_STUDENT_KEY.get(String(studentKey).trim());
}

export const PIPELINE_DEMO_COUNT = PIPELINE_DEMO_PEOPLE.length;

export const DEMO_COMPANY_SUMMARY = {
  totalStudents: PIPELINE_DEMO_COUNT,
  avgReadinessScore: Math.round(
    PIPELINE_DEMO_PEOPLE.reduce((a, p) => a + p.readinessScore, 0) / PIPELINE_DEMO_COUNT
  ),
};

const JOB_TITLES = [
  "Frontend Intern",
  "Backend Intern",
  "Full Stack Developer",
  "React Native Intern",
  "Platform / DevOps Intern",
] as const;

const APP_STATUSES = ["Applied", "Under Review", "Approved", "Applied", "Under Review"] as const;

/** Supabase-shaped rows for Company Dashboard + top-candidate aggregation */
export function buildCompanyDashboardFallbackApplications() {
  return PIPELINE_DEMO_PEOPLE.map((p, i) => ({
    id: `demo-app-${i + 1}`,
    student_user_id: p.studentKey,
    job_title: JOB_TITLES[i],
    status: APP_STATUSES[i],
    github_link: p.githubLink,
    created_at: new Date(Date.now() - 1000 * 60 * (30 + i * 90)).toISOString(),
  }));
}

const SUB_META = [
  { title: "REST API Backend", path: "api", skill: "node.js", status: "Pending" as const },
  { title: "Auth Microservice", path: "auth-svc", skill: "authentication", status: "Pending" as const },
  { title: "Full Stack App", path: "fullstack", skill: "react", status: "Approved" as const },
  { title: "Mobile Kit UI", path: "mobile-kit", skill: "react native", status: "Pending" as const },
  { title: "Infra Starter", path: "infra-starter", skill: "docker", status: "Rejected" as const },
];

export function buildCompanyDashboardFallbackSubmissions() {
  return PIPELINE_DEMO_PEOPLE.map((p, i) => {
    const m = SUB_META[i];
    const github_link = `https://github.com/demo/${m.path}`;
    const score = calculateSubmissionScore(github_link, m.title);
    const reviewed = m.status === "Approved" || m.status === "Rejected";
    return {
      id: `demo-sub-${i + 1}`,
      student_user_id: p.studentKey,
      project_title: m.title,
      github_link,
      skill: m.skill,
      status: m.status,
      score,
      created_at: new Date(Date.now() - 1000 * 60 * (40 + i * 120)).toISOString(),
      reviewed_at: reviewed ? new Date(Date.now() - 1000 * 60 * (30 + i * 100)).toISOString() : null,
    };
  });
}

/** hiring-workflow shaped rows for Company Applications page */
export function buildCompanyApplicationsFallback(): JobApplication[] {
  return PIPELINE_DEMO_PEOPLE.map((p, i) => ({
    applicationId: `demo-app-${i + 1}`,
    jobId: (i % 3) + 1,
    studentId: p.studentId,
    studentName: p.name,
    githubLink: p.githubLink,
    portfolioLink: p.portfolioLink,
    status: APP_STATUSES[i],
    timestamp: Date.now() - 1000 * 60 * (25 + i * 110),
  }));
}

/** demo-data `demoStudents` shape */
export function pipelineDemoAsStudentRows() {
  return PIPELINE_DEMO_PEOPLE.map((p) => ({
    id: p.studentId,
    name: p.name,
    readinessScore: p.readinessScore,
    careerGoal: p.role,
    skills: p.skills,
  }));
}

/** talent-pool TalentStudent[] when seeding localStorage */
export function pipelineDemoAsTalentStudents() {
  return PIPELINE_DEMO_PEOPLE.map((p) => ({
    id: p.studentId,
    name: p.name,
    careerGoal: p.role,
    readinessScore: p.readinessScore,
    skills: p.skills,
    verifiedSkills: p.skills.slice(0, p.verifiedSkillsCount),
  }));
}
