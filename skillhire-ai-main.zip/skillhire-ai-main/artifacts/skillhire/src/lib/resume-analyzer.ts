import { getScopedStorageKey } from "@/lib/session-scope";

/** Canonical list for dictionary extraction (demo — no ML). */
export const RESUME_ANALYZER_SKILLS = [
  "react",
  "node.js",
  "javascript",
  "html",
  "css",
  "typescript",
  "mongodb",
  "express",
  "api",
  "sql",
  "python",
  "java",
] as const;

export type ResumeAnalyzerSkill = (typeof RESUME_ANALYZER_SKILLS)[number];

/** Plain `userSkills` key as requested for demos / external tooling. */
export const USER_SKILLS_STORAGE_KEY = "userSkills";

const RESUME_APPLY_PENDING_KEY = "skillhire_resume_apply_pending";

const SKILL_DISPLAY_LABELS: Record<string, string> = {
  react: "React",
  "node.js": "Node.js",
  javascript: "JavaScript",
  html: "HTML",
  css: "CSS",
  typescript: "TypeScript",
  mongodb: "MongoDB",
  express: "Express",
  api: "API",
  sql: "SQL",
  python: "Python",
  java: "Java",
};

/** Demo PDF path: FileReader still runs briefly, then we substitute realistic resume text. */
const SIMULATED_PDF_RESUME_TEXT = `
Jane Developer — Software Engineer
Built customer dashboards with React, TypeScript, HTML and CSS. Backend services in Node.js and Express
with REST API design, MongoDB, and SQL. Also shipped Python automation scripts and Java microservices coursework.
`;

export function formatSkillTag(skill: string): string {
  const key = skill.toLowerCase();
  return SKILL_DISPLAY_LABELS[key] ?? skill;
}

export function extractSkillsFromResumeText(resumeText: string): string[] {
  const lower = resumeText.toLowerCase();
  const found: string[] = [];
  for (const skill of RESUME_ANALYZER_SKILLS) {
    if (lower.includes(skill)) found.push(skill);
  }
  return found;
}

function readFileAsText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result ?? ""));
    reader.onerror = () => reject(reader.error ?? new Error("Failed to read file"));
    reader.readAsText(file);
  });
}

export type ResumeReadResult = {
  text: string;
  usedPdfMock: boolean;
};

/**
 * .txt → FileReader text. .pdf → demo simulation (no pdf.js).
 */
export async function extractResumeTextFromFile(file: File): Promise<ResumeReadResult> {
  const name = file.name.toLowerCase();
  const isTxt = file.type === "text/plain" || name.endsWith(".txt");
  const isPdf = file.type === "application/pdf" || name.endsWith(".pdf");

  if (isTxt) {
    const text = await readFileAsText(file);
    return { text, usedPdfMock: false };
  }

  if (isPdf) {
    await new Promise((r) => setTimeout(r, 700));
    return {
      text: SIMULATED_PDF_RESUME_TEXT,
      usedPdfMock: true,
    };
  }

  throw new Error("Please upload a .pdf or .txt resume.");
}

/** Call before navigating to Skill Gap so the form can pick up skills once. */
export function persistSkillsForSkillGap(skills: string[]) {
  localStorage.setItem(USER_SKILLS_STORAGE_KEY, JSON.stringify(skills));
  localStorage.setItem(getScopedStorageKey(RESUME_APPLY_PENDING_KEY), "1");
}

export function consumePendingResumeSkills(): string[] | null {
  const flagKey = getScopedStorageKey(RESUME_APPLY_PENDING_KEY);
  if (localStorage.getItem(flagKey) !== "1") return null;

  localStorage.removeItem(flagKey);

  try {
    const raw = localStorage.getItem(USER_SKILLS_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed) || !parsed.every((x) => typeof x === "string")) return null;
    const skills = parsed.map((s) => s.trim()).filter(Boolean);
    localStorage.removeItem(USER_SKILLS_STORAGE_KEY);
    return skills.length ? skills : null;
  } catch {
    localStorage.removeItem(USER_SKILLS_STORAGE_KEY);
    return null;
  }
}
