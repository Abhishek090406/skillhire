import { getScopedStorageKey } from "@/lib/session-scope";
import { loadSkillGapResult } from "@/lib/skill-gap";

export type ProjectStatus = "Not Started" | "In Progress" | "Completed";

export type AppliedProjectRecord = {
  projectId: number;
  appliedAt: number;
  status: ProjectStatus;
  githubRepoUrl?: string;
};

const APPLIED_PROJECTS_KEY = "skillhire_applied_projects";

function readJson<T>(key: string, fallback: T): T {
  const raw = localStorage.getItem(getScopedStorageKey(key));
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function writeJson<T>(key: string, value: T) {
  localStorage.setItem(getScopedStorageKey(key), JSON.stringify(value));
}

export function loadAppliedProjects(): AppliedProjectRecord[] {
  return readJson<AppliedProjectRecord[]>(APPLIED_PROJECTS_KEY, []);
}

export function saveAppliedProjects(records: AppliedProjectRecord[]) {
  writeJson(APPLIED_PROJECTS_KEY, records);
}

export function getAppliedRecord(projectId: number) {
  return loadAppliedProjects().find((r) => r.projectId === projectId) ?? null;
}

export function applyToProjectLocal(projectId: number): { ok: true; created: boolean } {
  const existing = loadAppliedProjects();
  const found = existing.find((r) => r.projectId === projectId);
  if (found) return { ok: true, created: false };
  const next: AppliedProjectRecord[] = [
    ...existing,
    { projectId, appliedAt: Date.now(), status: "Not Started" },
  ];
  saveAppliedProjects(next);
  return { ok: true, created: true };
}

export function updateProjectStatusLocal(projectId: number, status: ProjectStatus) {
  const existing = loadAppliedProjects();
  const next = existing.map((r) => (r.projectId === projectId ? { ...r, status } : r));
  saveAppliedProjects(next);
}

export function upsertProjectGithubRepoLocal(projectId: number, githubRepoUrl: string) {
  const existing = loadAppliedProjects();
  const next = existing.map((r) => (r.projectId === projectId ? { ...r, githubRepoUrl } : r));
  saveAppliedProjects(next);
}

export function loadUserSkillsFromStorage(): string[] {
  // Skill Gap page stores "currentSkills" in its persisted result
  const gap = loadSkillGapResult();
  if (gap?.currentSkills?.length) return gap.currentSkills;

  // Student profile cache also stores "skills" but that lives elsewhere; we keep this simple
  return [];
}

export function loadMissingSkillsFromStorage(): string[] {
  const raw = localStorage.getItem(getScopedStorageKey("skillhire_learning_focus_skills"));
  if (raw) {
    try {
      const parsed = JSON.parse(raw) as unknown;
      if (Array.isArray(parsed)) return parsed.filter((s) => typeof s === "string") as string[];
    } catch {
      // ignore
    }
  }
  const gap = loadSkillGapResult();
  return Array.isArray(gap?.missingSkills) ? gap!.missingSkills : [];
}

export function normalizeSkill(s: string) {
  return s.trim().toLowerCase();
}

export function computeMatchScore(requiredSkills: string[], userSkills: string[]) {
  const required = requiredSkills.map(normalizeSkill).filter(Boolean);
  const user = new Set(userSkills.map(normalizeSkill).filter(Boolean));
  if (required.length === 0) return { matchPercent: 100, missingSkill: null as string | null, matchedCount: 0 };

  let matched = 0;
  const missing: string[] = [];
  for (const req of required) {
    if (user.has(req)) matched += 1;
    else missing.push(req);
  }

  const matchPercent = Math.round((matched / required.length) * 100);
  const missingSkill = missing.length ? missingSkillTitle(missing[0]!) : null;
  return { matchPercent, missingSkill, matchedCount: matched };
}

function missingSkillTitle(value: string) {
  // best-effort title casing
  return value
    .split(" ")
    .filter(Boolean)
    .map((w) => w[0]?.toUpperCase() + w.slice(1))
    .join(" ");
}

export function computeWhyThisProject({
  requiredSkills,
  missingSkills,
  industryUseCase,
}: {
  requiredSkills: string[];
  missingSkills: string[];
  industryUseCase: string;
}) {
  const reasons: string[] = [];
  const req = requiredSkills.map(normalizeSkill);
  const missing = new Set(missingSkills.map(normalizeSkill));

  const intersectsMissing = req.some((r) => missing.has(r));
  if (intersectsMissing) reasons.push("Matches your skill gap (high impact for readiness)");

  if (requiredSkills.length > 0) reasons.push(`Builds ${requiredSkills[0]} skills with real-world constraints`);

  reasons.push("Strengthens your portfolio with a verifiable project story");

  if (industryUseCase) reasons.push(industryUseCase);

  return reasons.slice(0, 4);
}

export function computeBoostPercent(difficulty: string) {
  if (difficulty === "Advanced") return 14;
  if (difficulty === "Intermediate") return 10;
  return 7;
}

