import { getScopedStorageKey } from "@/lib/session-scope";

export const STUDENT_DOMAIN_KEY = "skillhire_student_domain";

export function getStudentDomain() {
  return localStorage.getItem(getScopedStorageKey(STUDENT_DOMAIN_KEY));
}

export function setStudentDomain(domain: string) {
  localStorage.setItem(getScopedStorageKey(STUDENT_DOMAIN_KEY), domain);
}

export function resetStudentWorkspace() {
  const keys = [
    "skillhire_skill_gap_result",
    "skillhire_student_profile_cache",
    "skillhire_learning_completed",
  ];

  for (const baseKey of keys) {
    localStorage.removeItem(getScopedStorageKey(baseKey));
  }
}

