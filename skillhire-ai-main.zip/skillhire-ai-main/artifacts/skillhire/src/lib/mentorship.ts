import { getScopedStorageKey } from "@/lib/session-scope";
import { loadSkillGapResult } from "@/lib/skill-gap";

export type MentorBooking = {
  bookingId: string;
  mentorId: number;
  sessionType: "Resume Review" | "Mock Interview" | "Project Feedback";
  dateTime: string;
  goal: string;
  createdAt: number;
};

const BOOKINGS_KEY = "skillhire_mentor_bookings";

function readJson<T>(key: string, fallback: T): T {
  const raw = localStorage.getItem(getScopedStorageKey(key));
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function writeJson<T>(key: string, value: T) {
  localStorage.setItem(getScopedStorageKey(key), JSON.stringify(value));
}

export function loadMentorBookings(): MentorBooking[] {
  return readJson<MentorBooking[]>(BOOKINGS_KEY, []);
}

export function saveMentorBookings(bookings: MentorBooking[]) {
  writeJson(BOOKINGS_KEY, bookings);
}

export function isMentorBooked(mentorId: number) {
  return loadMentorBookings().some((b) => b.mentorId === mentorId);
}

export function createMentorBooking(input: Omit<MentorBooking, "bookingId" | "createdAt">) {
  const existing = loadMentorBookings();
  const booking: MentorBooking = {
    bookingId: randomId(),
    createdAt: Date.now(),
    ...input,
  };
  const next = [booking, ...existing];
  saveMentorBookings(next);
  return booking;
}

export function normalizeSkill(s: string) {
  return s.trim().toLowerCase();
}

export function getMentorMatch({
  mentorExpertise,
  missingSkills,
  targetRole,
}: {
  mentorExpertise: string[];
  missingSkills: string[];
  targetRole: string;
}) {
  const exp = mentorExpertise.map(normalizeSkill);
  const missing = new Set(missingSkills.map(normalizeSkill));

  const hits = exp.filter((e) => missing.has(e));
  const gapAlignment = hits.length;
  const base = Math.min(85, 50 + gapAlignment * 15);
  const roleBoost = targetRole.toLowerCase().includes("front")
    ? exp.some((e) => e.includes("react") || e.includes("frontend")) ? 8 : 0
    : targetRole.toLowerCase().includes("back")
    ? exp.some((e) => e.includes("node") || e.includes("system")) ? 8 : 0
    : 4;

  const matchPercent = Math.max(35, Math.min(98, base + roleBoost));

  const reason =
    hits.length > 0
      ? `Strong fit because they cover your gaps: ${hits.slice(0, 2).map(titleize).join(", ")}.`
      : `Good general fit for ${targetRole} growth (portfolio + interview guidance).`;

  return { matchPercent, relevantSkills: hits.map(titleize), reason };
}

export function getSkillGapContext() {
  const gap = loadSkillGapResult();
  return {
    targetRole: gap?.targetRole ?? "Frontend Developer",
    missingSkills: Array.isArray(gap?.missingSkills) ? gap!.missingSkills : [],
  };
}

export function getSessionBenefits() {
  return ["Resume review", "Mock interview", "Project feedback"];
}

export function getImpactMetric(mentorId: number) {
  const base = 14 + (mentorId % 3) * 4;
  return `Students improved readiness by +${base}%`;
}

export function mentorStatus(available: boolean) {
  if (available) return "Available";
  return "Unavailable";
}

function titleize(s: string) {
  return s
    .split(" ")
    .filter(Boolean)
    .map((w) => w[0]?.toUpperCase() + w.slice(1))
    .join(" ");
}

function randomId() {
  try {
    const bytes = new Uint8Array(12);
    crypto.getRandomValues(bytes);
    return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
  } catch {
    return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  }
}

