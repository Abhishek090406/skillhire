import { loadSkillGapResult } from "@/lib/skill-gap";
import { loadStudentProfileCache } from "@/lib/student-consistency";
import { computeVerifiedSkills } from "@/lib/profile-verification";
import { pipelineDemoAsTalentStudents } from "@/lib/company-pipeline-demo";
import { getScopedStorageKey } from "@/lib/session-scope";
import { getCurrentStudentId } from "@/lib/current-student";

export type TalentStudent = {
  id: number;
  name: string;
  careerGoal: string;
  readinessScore: number;
  skills: string[];
  verifiedSkills: string[];
};

function studentsKey() {
  return getScopedStorageKey("skillhire_talent_pool_students_v1");
}

function safeParse<T>(raw: string | null, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function loadStudentsFromLocalStorage(): TalentStudent[] {
  const raw = localStorage.getItem(studentsKey());
  const parsed = safeParse<unknown>(raw, []);
  if (!Array.isArray(parsed)) return [];
  return (parsed as any[])
    .map((s) => ({
      id: typeof s?.id === "number" ? s.id : 0,
      name: typeof s?.name === "string" ? s.name : "",
      careerGoal: typeof s?.careerGoal === "string" ? s.careerGoal : "",
      readinessScore: typeof s?.readinessScore === "number" ? s.readinessScore : 0,
      skills: Array.isArray(s?.skills) ? s.skills.filter((x: any) => typeof x === "string") : [],
      verifiedSkills: Array.isArray(s?.verifiedSkills) ? s.verifiedSkills.filter((x: any) => typeof x === "string") : [],
    }))
    .filter((s) => s.id && s.name);
}

export function saveStudentsToLocalStorage(students: TalentStudent[]) {
  localStorage.setItem(studentsKey(), JSON.stringify(students));
}

export function getDemoCandidates(): TalentStudent[] {
  return pipelineDemoAsTalentStudents();
}

export function ensureStudentsSeeded(): TalentStudent[] {
  const existing = loadStudentsFromLocalStorage();
  const expected = getDemoCandidates();
  const expectedIds = new Set(expected.map((s) => s.id));
  if (existing.length === expected.length && existing.every((s) => expectedIds.has(s.id))) {
    return existing;
  }
  saveStudentsToLocalStorage(expected);
  return expected;
}

export function ensureCurrentStudentIncluded(studentId = getCurrentStudentId()): TalentStudent[] {
  const students = ensureStudentsSeeded();
  const has = students.some((s) => s.id === studentId);

  const cached = loadStudentProfileCache();
  const gap = loadSkillGapResult();
  const name = (typeof cached?.name === "string" && cached.name.trim()) || "Student";
  const careerGoal =
    (typeof cached?.careerGoal === "string" && cached.careerGoal.trim()) ||
    (typeof gap?.targetRole === "string" && gap.targetRole.trim()) ||
    "Frontend Developer";
  const skills =
    Array.isArray(cached?.skills) && cached.skills.length
      ? cached.skills
      : Array.isArray(gap?.currentSkills) && gap.currentSkills.length
      ? gap.currentSkills
      : ["React", "JavaScript", "HTML", "CSS"];
  const readinessScore = typeof gap?.readinessScore === "number" ? gap.readinessScore : 0;
  const verifiedSkills = computeVerifiedSkills(skills).verified.map((v) => v.skill);

  const me: TalentStudent = {
    id: studentId,
    name,
    careerGoal,
    readinessScore,
    skills,
    verifiedSkills,
  };

  const next = has ? students.map((s) => (s.id === studentId ? { ...s, ...me } : s)) : [me, ...students];
  saveStudentsToLocalStorage(next);
  return next;
}

