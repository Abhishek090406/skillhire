export function getSessionScope() {
  if (typeof window === "undefined") return "server";
  const role = localStorage.getItem("skillhire_role") || "guest";
  const email = localStorage.getItem("skillhire_auth_email") || "guest";
  return `${role}:${email}`;
}

export function getScopedStorageKey(baseKey: string) {
  return `${baseKey}:${getSessionScope()}`;
}
