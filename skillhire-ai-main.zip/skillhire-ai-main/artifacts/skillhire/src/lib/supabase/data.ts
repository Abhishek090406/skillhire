import { demoJobs, demoMentors, demoProjects, demoStudents, demoStudentProfile } from "@/lib/demo-data";
import { supabase } from "@/lib/supabase/client";
import { getScopedStorageKey } from "@/lib/session-scope";

type AnyRecord = Record<string, unknown>;

const read = (obj: AnyRecord, camel: string, snake: string) => obj[camel] ?? obj[snake];

export async function seedDemoDataToSupabase() {
  // These writes require insert/upsert RLS permissions for anon/authenticated users.
  // If policies block it, app will continue with fallback data.
  await supabase.from("projects").upsert(
    demoProjects.map((p) => ({
      id: p.id,
      title: p.title,
      description: p.description,
      company_id: p.companyId,
      company_name: p.companyName,
      required_skills: p.requiredSkills,
      difficulty: p.difficulty,
      duration: p.duration,
      reward: p.reward,
      certificate: p.certificate,
      applicants: p.applicants,
      status: p.status,
    })),
    { onConflict: "id" }
  );

  await supabase.from("jobs").upsert(
    demoJobs.map((j) => ({
      id: j.id,
      title: j.title,
      description: j.description,
      company_id: j.companyId,
      company_name: j.companyName,
      required_skills: j.requiredSkills,
      location: j.location,
      remote: j.remote,
      stipend: j.stipend,
      type: j.type,
      applicants: j.applicants,
      status: j.status,
    })),
    { onConflict: "id" }
  );

  await supabase.from("mentors").upsert(
    demoMentors.map((m) => ({
      id: m.id,
      name: m.name,
      title: m.title,
      company: m.company,
      avatar_url: m.avatarUrl,
      expertise: m.expertise,
      bio: m.bio,
      rating: m.rating,
      session_count: m.sessionCount,
      available: m.available,
    })),
    { onConflict: "id" }
  );

  await supabase.from("students").upsert(
    demoStudents.map((s, index) => ({
      id: s.id,
      name: s.name,
      email: `student${s.id}@skillhire.ai`,
      career_goal: s.careerGoal,
      readiness_score: s.readinessScore,
      profile_completion: 80,
      skills: s.skills,
      completed_projects: index + 2,
      certifications: [],
    })),
    { onConflict: "id" }
  );

  await supabase.from("students").upsert(
    {
      id: demoStudentProfile.id,
      name: demoStudentProfile.name,
      email: "student1@skillhire.ai",
      avatar_url: demoStudentProfile.avatarUrl,
      bio: demoStudentProfile.bio,
      skills: demoStudentProfile.skills,
      career_goal: demoStudentProfile.careerGoal,
      readiness_score: demoStudentProfile.readinessScore,
      profile_completion: 84,
      github_url: demoStudentProfile.githubUrl,
      linkedin_url: demoStudentProfile.linkedinUrl,
      certifications: demoStudentProfile.certifications,
      completed_projects: demoStudentProfile.completedProjects,
    },
    { onConflict: "id" }
  );
}

export async function ensureSeedDemoDataToSupabase() {
  const seedKey = getScopedStorageKey("skillhire_seeded");
  const alreadySeeded = localStorage.getItem(seedKey);
  if (alreadySeeded === "1") return;

  // Never overwrite existing DB content (especially `students`), otherwise user edits appear to "reset".
  // If tables already have rows, mark seeded and exit.
  try {
    const [projectsCheck, jobsCheck, mentorsCheck, studentsCheck] = await Promise.all([
      supabase.from("projects").select("id"),
      supabase.from("jobs").select("id"),
      supabase.from("mentors").select("id"),
      supabase.from("students").select("id"),
    ]);

    const hasAny =
      (Array.isArray(projectsCheck.data) && projectsCheck.data.length > 0) ||
      (Array.isArray(jobsCheck.data) && jobsCheck.data.length > 0) ||
      (Array.isArray(mentorsCheck.data) && mentorsCheck.data.length > 0) ||
      (Array.isArray(studentsCheck.data) && studentsCheck.data.length > 0);

    if (hasAny) {
      localStorage.setItem(seedKey, "1");
      return;
    }
  } catch {
    // If the check fails (offline/mock), don't block app; just avoid seeding.
    localStorage.setItem(seedKey, "1");
    return;
  }

  await seedDemoDataToSupabase();
  localStorage.setItem(seedKey, "1");
}

export async function fetchProjectsFromSupabase() {
  const { data, error } = await supabase.from("projects").select("*");
  if (error || !Array.isArray(data)) return null;
  return data.map((row: AnyRecord) => ({
    id: Number(read(row, "id", "id")),
    title: String(read(row, "title", "title") ?? ""),
    description: String(read(row, "description", "description") ?? ""),
    companyId: Number(read(row, "companyId", "company_id") ?? 0),
    companyName: String(read(row, "companyName", "company_name") ?? "Company"),
    requiredSkills: (read(row, "requiredSkills", "required_skills") as string[]) ?? [],
    difficulty: String(read(row, "difficulty", "difficulty") ?? "Intermediate"),
    duration: String(read(row, "duration", "duration") ?? ""),
    reward: String(read(row, "reward", "reward") ?? ""),
    certificate: Boolean(read(row, "certificate", "certificate")),
    applicants: Number(read(row, "applicants", "applicants") ?? 0),
    status: String(read(row, "status", "status") ?? "Open"),
  }));
}

export async function fetchJobsFromSupabase() {
  const { data, error } = await supabase.from("jobs").select("*");
  if (error || !Array.isArray(data)) return null;
  return data.map((row: AnyRecord) => ({
    id: Number(read(row, "id", "id")),
    title: String(read(row, "title", "title") ?? ""),
    description: String(read(row, "description", "description") ?? ""),
    companyId: Number(read(row, "companyId", "company_id") ?? 0),
    companyName: String(read(row, "companyName", "company_name") ?? "Company"),
    requiredSkills: (read(row, "requiredSkills", "required_skills") as string[]) ?? [],
    location: String(read(row, "location", "location") ?? ""),
    remote: Boolean(read(row, "remote", "remote")),
    stipend: String(read(row, "stipend", "stipend") ?? ""),
    type: String(read(row, "type", "type") ?? "Internship"),
    applicants: Number(read(row, "applicants", "applicants") ?? 0),
    status: String(read(row, "status", "status") ?? "Open"),
  }));
}

export async function fetchMentorsFromSupabase() {
  const { data, error } = await supabase.from("mentors").select("*");
  if (error || !Array.isArray(data)) return null;
  return data.map((row: AnyRecord) => ({
    id: Number(read(row, "id", "id")),
    name: String(read(row, "name", "name") ?? ""),
    title: String(read(row, "title", "title") ?? ""),
    company: String(read(row, "company", "company") ?? ""),
    avatarUrl: String(read(row, "avatarUrl", "avatar_url") ?? ""),
    expertise: (read(row, "expertise", "expertise") as string[]) ?? [],
    bio: String(read(row, "bio", "bio") ?? ""),
    rating: Number(read(row, "rating", "rating") ?? 0),
    sessionCount: Number(read(row, "sessionCount", "session_count") ?? 0),
    available: Boolean(read(row, "available", "available")),
  }));
}

export async function fetchStudentsFromSupabase() {
  const { data, error } = await supabase.from("students").select("*");
  if (error || !Array.isArray(data)) return null;
  return data.map((row: AnyRecord) => ({
    id: Number(read(row, "id", "id")),
    name: String(read(row, "name", "name") ?? ""),
    readinessScore: Number(read(row, "readinessScore", "readiness_score") ?? 0),
    careerGoal: String(read(row, "careerGoal", "career_goal") ?? ""),
    skills: (read(row, "skills", "skills") as string[]) ?? [],
  }));
}

export async function fetchStudentProfileFromSupabase(studentId = 1) {
  const { data, error } = await supabase.from("students").select("*");
  if (error || !Array.isArray(data)) return null;
  const matched = data.find((row) => Number((row as AnyRecord).id) === studentId);
  if (!matched) return null;
  const row = matched as AnyRecord;
  return {
    id: Number(read(row, "id", "id")),
    name: String(read(row, "name", "name") ?? ""),
    careerGoal: String(read(row, "careerGoal", "career_goal") ?? ""),
    bio: String(read(row, "bio", "bio") ?? ""),
    avatarUrl: String(read(row, "avatarUrl", "avatar_url") ?? ""),
    githubUrl: String(read(row, "githubUrl", "github_url") ?? ""),
    linkedinUrl: String(read(row, "linkedinUrl", "linkedin_url") ?? ""),
    readinessScore: Number(read(row, "readinessScore", "readiness_score") ?? 0),
    completedProjects: Number(read(row, "completedProjects", "completed_projects") ?? 0),
    certifications: (read(row, "certifications", "certifications") as string[]) ?? [],
    skills: (read(row, "skills", "skills") as string[]) ?? [],
  };
}
