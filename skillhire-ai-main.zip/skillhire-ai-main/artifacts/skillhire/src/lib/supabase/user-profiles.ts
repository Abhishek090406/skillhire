import { supabase } from "@/lib/supabase/client";

export type UserProfileRow = {
  user_id: string;
  role: string;
  name: string;
  career_goal: string;
  bio: string;
  github_url: string;
  linkedin_url: string;
  skills: string[];
  readiness_score: number;
  profile_completion: number;
};

export async function getAuthedUserId() {
  const { data } = await supabase.auth.getUser();
  return data.user?.id ?? null;
}

export async function fetchUserProfile(userId: string) {
  const { data, error } = await supabase.from("user_profiles").select("*");
  if (error || !Array.isArray(data)) return null;
  const row = data.find((r) => (r as { user_id?: string }).user_id === userId) as Partial<UserProfileRow> | undefined;
  return row ?? null;
}

export async function upsertUserProfile(row: UserProfileRow) {
  return await supabase.from("user_profiles").upsert(row, { onConflict: "user_id" });
}

/** Company hiring: student rows only (empty if table/RLS unavailable). */
export async function listStudentProfilesForCompany(): Promise<UserProfileRow[]> {
  const { data, error } = await supabase.from("user_profiles").select("*");
  if (error || !Array.isArray(data)) return [];
  return data
    .filter((r) => String((r as { role?: string }).role ?? "").toLowerCase() === "student")
    .map((r) => {
      const row = r as Record<string, unknown>;
      return {
        user_id: String(row.user_id ?? ""),
        role: String(row.role ?? "student"),
        name: String(row.name ?? ""),
        career_goal: String(row.career_goal ?? ""),
        bio: String(row.bio ?? ""),
        github_url: String(row.github_url ?? ""),
        linkedin_url: String(row.linkedin_url ?? ""),
        skills: Array.isArray(row.skills) ? (row.skills as string[]) : [],
        readiness_score: Number(row.readiness_score ?? 0),
        profile_completion: Number(row.profile_completion ?? 0),
      };
    })
    .filter((p) => p.user_id);
}

