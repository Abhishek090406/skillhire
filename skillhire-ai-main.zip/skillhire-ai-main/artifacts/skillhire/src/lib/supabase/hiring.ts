import { supabase } from "@/lib/supabase/client";
import { getAuthedUserId } from "@/lib/supabase/user-profiles";
import { calculateSubmissionScore, clampSubmissionScore } from "@/lib/project-scoring";

export type SubmissionStatus = "Pending" | "Approved" | "Rejected";

export type SubmissionRow = {
  id: string;
  student_user_id: string;
  project_title: string;
  github_link: string;
  skill: string;
  status: SubmissionStatus;
  score?: number | null;
  created_at: string;
  reviewed_at: string | null;
};

export type VerifiedSkillRow = {
  id: string;
  student_user_id: string;
  skill: string;
  created_at: string;
};

export type ApplicationRow = {
  id: string;
  student_user_id: string;
  job_title: string;
  status: string;
  github_link: string | null;
  portfolio_link: string | null;
  created_at: string;
};

function isMissingTableError(err: unknown) {
  const anyErr = err as { message?: string; code?: string } | null;
  const msg = anyErr?.message ?? "";
  const code = anyErr?.code ?? "";
  return (
    code === "PGRST205" ||
    msg.includes("schema cache") ||
    msg.includes("Could not find the table") ||
    msg.includes("does not exist")
  );
}

function isRlsOrForbiddenError(err: unknown) {
  const anyErr = err as { message?: string; code?: string; status?: number } | null;
  const msg = anyErr?.message ?? "";
  const code = anyErr?.code ?? "";
  const status = anyErr?.status ?? 0;
  return (
    status === 401 ||
    status === 403 ||
    code === "42501" ||
    msg.toLowerCase().includes("permission denied") ||
    msg.toLowerCase().includes("not allowed")
  );
}

export async function submitGithubProof(input: { projectTitle: string; githubLink: string; skillTag: string }) {
  const userId = await getAuthedUserId();
  if (!userId) throw new Error("Not authenticated");

  const score = calculateSubmissionScore(input.githubLink, input.projectTitle);

  const { error } = await supabase.from("submissions").insert([
    {
      student_user_id: userId,
      project_title: input.projectTitle,
      github_link: input.githubLink,
      skill: input.skillTag.trim().toLowerCase(),
      status: "Pending",
      score,
    },
  ]);
  if (error) {
    if (isMissingTableError(error)) {
      throw new Error(
        "Supabase tables are not set up yet. Run the SQL in `scratch/supabase/skillhire_core_schema.sql` in Supabase, then refresh."
      );
    }
    throw new Error(error.message);
  }
}

export async function listMySubmissions() {
  const userId = await getAuthedUserId();
  if (!userId) return [];
  const { data, error } = await supabase
    .from("submissions")
    .select("*")
    .eq("student_user_id", userId)
    .order("created_at", { ascending: false });
  if (error) {
    if (isMissingTableError(error)) return [];
    throw new Error(error.message);
  }
  return (data ?? []) as SubmissionRow[];
}

export async function listAllSubmissionsForCompany() {
  const { data, error } = await supabase.from("submissions").select("*").order("created_at", { ascending: false });
  if (error) {
    if (isMissingTableError(error)) return [];
    if (isRlsOrForbiddenError(error)) return [];
    throw new Error(error.message);
  }
  return (data ?? []) as SubmissionRow[];
}

export async function listAllApplicationsForCompany() {
  const { data, error } = await supabase.from("applications").select("*").order("created_at", { ascending: false });
  if (error) {
    if (isMissingTableError(error)) return [];
    if (isRlsOrForbiddenError(error)) return [];
    throw new Error(error.message);
  }
  return (data ?? []) as ApplicationRow[];
}

export async function reviewApplication(input: { applicationId: string; status: string }) {
  const { data, error } = await supabase
    .from("applications")
    .update({ status: input.status })
    .eq("id", input.applicationId)
    .select("*")
    .maybeSingle();
  if (error) {
    if (isMissingTableError(error)) return null;
    if (isRlsOrForbiddenError(error)) return null;
    throw new Error(error.message);
  }
  return data as ApplicationRow | null;
}

export async function reviewSubmission(input: { submissionId: string; status: SubmissionStatus }) {
  const { data, error } = await supabase
    .from("submissions")
    .update({ status: input.status, reviewed_at: new Date().toISOString() })
    .eq("id", input.submissionId)
    .select("*")
    .maybeSingle();
  if (error) {
    if (isMissingTableError(error)) return null;
    if (isRlsOrForbiddenError(error)) return null;
    throw new Error(error.message);
  }
  return data as SubmissionRow | null;
}

export async function updateSubmissionScore(input: { submissionId: string; score: number }) {
  const score = clampSubmissionScore(input.score);
  const { data, error } = await supabase
    .from("submissions")
    .update({ score })
    .eq("id", input.submissionId)
    .select("*")
    .maybeSingle();
  if (error) {
    if (isMissingTableError(error)) return null;
    if (isRlsOrForbiddenError(error)) return null;
    throw new Error(error.message);
  }
  return data as SubmissionRow | null;
}

export async function awardVerifiedSkill(input: { studentUserId: string; skill: string }) {
  const skill = input.skill.trim().toLowerCase();
  if (!skill) return;

  // Avoid duplicates (best-effort on client)
  const existing = await listVerifiedSkillsForStudent(input.studentUserId);
  if (existing.some((s) => s.skill.toLowerCase() === skill)) return;

  const { error } = await supabase.from("verified_skills").insert([
    { student_user_id: input.studentUserId, skill },
  ]);
  if (error) {
    if (isMissingTableError(error)) return;
    throw new Error(error.message);
  }
}

export async function listMyVerifiedSkills() {
  const userId = await getAuthedUserId();
  if (!userId) return [];
  return await listVerifiedSkillsForStudent(userId);
}

export async function listVerifiedSkillsForStudent(studentUserId: string) {
  const { data, error } = await supabase
    .from("verified_skills")
    .select("*")
    .eq("student_user_id", studentUserId)
    .order("created_at", { ascending: false });
  if (error) {
    if (isMissingTableError(error)) return [];
    throw new Error(error.message);
  }
  return (data ?? []) as VerifiedSkillRow[];
}

export async function listAllVerifiedSkillsForCompany() {
  const { data, error } = await supabase
    .from("verified_skills")
    .select("*")
    .order("created_at", { ascending: false });
  if (error) {
    if (isMissingTableError(error)) return [];
    if (isRlsOrForbiddenError(error)) return [];
    throw new Error(error.message);
  }
  return (data ?? []) as VerifiedSkillRow[];
}

export function subscribeToSubmissions(onChange: () => void, options?: { debounceMs?: number }) {
  const ms = options?.debounceMs ?? 0;
  let timer: ReturnType<typeof setTimeout> | undefined;
  const run = () => {
    if (ms <= 0) {
      onChange();
      return;
    }
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => {
      timer = undefined;
      onChange();
    }, ms);
  };

  const channel = supabase
    .channel(`hiring-feed-${Math.random().toString(36).slice(2)}`)
    .on("postgres_changes", { event: "*", schema: "public", table: "submissions" }, () => run())
    .on("postgres_changes", { event: "*", schema: "public", table: "verified_skills" }, () => run())
    .on("postgres_changes", { event: "*", schema: "public", table: "applications" }, () => run())
    .subscribe();

  return () => {
    if (timer) clearTimeout(timer);
    void supabase.removeChannel(channel);
  };
}

