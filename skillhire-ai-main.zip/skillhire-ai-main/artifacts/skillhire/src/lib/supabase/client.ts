import { createClient } from "@supabase/supabase-js";

const supabaseUrl =
  import.meta.env.VITE_SUPABASE_URL || import.meta.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseAnonKey =
  import.meta.env.VITE_SUPABASE_ANON_KEY ||
  import.meta.env.VITE_SUPABASE_PUBLISHABLE_DEFAULT_KEY ||
  import.meta.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
  import.meta.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_DEFAULT_KEY;

const mockSupabase = {
  auth: {
    signInWithPassword: async () => ({ data: null, error: { message: "Supabase is not configured." } }),
    signUp: async () => ({ data: null, error: { message: "Supabase is not configured." } }),
    getUser: async () => ({ data: { user: null }, error: null }),
    signOut: async () => ({ error: null }),
  },
  from: () => ({
    upsert: async () => ({ data: null, error: null }),
    insert: async () => ({ data: null, error: null }),
    update: (..._args: unknown[]) => ({
      eq: async (..._eqArgs: unknown[]) => ({ data: null, error: null }),
    }),
    select: (..._args: unknown[]) =>
      Promise.resolve({ data: [], error: null }),
  }),
} as const;

export const supabase =
  supabaseUrl && supabaseAnonKey
    ? createClient(supabaseUrl, supabaseAnonKey)
    : (mockSupabase as unknown as ReturnType<typeof createClient>);
