import { supabase } from "@/lib/supabase/client";
import { getAuthedUserId } from "@/lib/supabase/user-profiles";
import { calculateSubmissionScore } from "@/lib/project-scoring";

const DEMO_GITHUB_LINKS = [
  "https://github.com/demo/api",
  "https://github.com/demo/fullstack",
  "https://github.com/demo/auth",
];

const DEMO_JOB_TITLES = ["Frontend Intern", "Backend Intern", "Full Stack Developer"];

export async function seedMockData() {
  const userId = await getAuthedUserId();
  if (!userId) return { seeded: false as const, reason: "not_authenticated" as const };

  // Only seed if BOTH are empty (keeps real systems untouched)
  const [{ count: submissionsCount, error: subCountErr }, { count: appsCount, error: appCountErr }] =
    await Promise.all([
      supabase.from("submissions").select("*", { count: "exact", head: true }),
      supabase.from("applications").select("*", { count: "exact", head: true }),
    ]);

  if (subCountErr || appCountErr) {
    return { seeded: false as const, reason: "missing_tables_or_rls" as const };
  }

  if ((submissionsCount ?? 0) > 0 || (appsCount ?? 0) > 0) {
    return { seeded: false as const, reason: "already_has_data" as const };
  }

  // Seed Applications
  const { error: appsErr } = await supabase.from("applications").insert([
    { student_user_id: userId, job_title: "Frontend Intern", status: "Applied" },
    { student_user_id: userId, job_title: "Backend Intern", status: "Under Review" },
    { student_user_id: userId, job_title: "Full Stack Developer", status: "Approved" },
  ]);

  // Seed Submissions
  const { error: subsErr } = await supabase.from("submissions").insert([
    {
      student_user_id: userId,
      project_title: "REST API Backend",
      github_link: "https://github.com/demo/api",
      skill: "node.js",
      status: "Pending",
      score: calculateSubmissionScore("https://github.com/demo/api", "REST API Backend"),
    },
    {
      student_user_id: userId,
      project_title: "Full Stack App",
      github_link: "https://github.com/demo/fullstack",
      skill: "react",
      status: "Approved",
      score: calculateSubmissionScore("https://github.com/demo/fullstack", "Full Stack App"),
    },
    {
      student_user_id: userId,
      project_title: "Auth System",
      github_link: "https://github.com/demo/auth",
      skill: "authentication",
      status: "Pending",
      score: calculateSubmissionScore("https://github.com/demo/auth", "Auth System"),
    },
  ]);

  if (appsErr || subsErr) {
    return { seeded: false as const, reason: "insert_failed" as const };
  }

  return { seeded: true as const };
}

export async function resetDemoData() {
  const userId = await getAuthedUserId();
  if (!userId) return { reset: false as const, reason: "not_authenticated" as const };

  // Only delete the known demo rows (never touch real data).
  // IMPORTANT: do NOT scope by student_user_id so reset works even if demo rows
  // were seeded by a different authed user during testing.
  const { error: subsDelErr } = await supabase
    .from("submissions")
    .delete()
    .in("github_link", DEMO_GITHUB_LINKS);

  const { error: appsDelErr } = await supabase
    .from("applications")
    .delete()
    .in("job_title", DEMO_JOB_TITLES);

  if (subsDelErr || appsDelErr) {
    return {
      reset: false as const,
      reason: "delete_failed" as const,
      message: subsDelErr?.message || appsDelErr?.message || "Delete failed",
    };
  }

  return { reset: true as const };
}

