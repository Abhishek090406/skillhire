import { buildRoleAwareSkillGap, SkillGapResult } from "@/lib/skill-gap";

type Priority = "Critical" | "High" | "Medium";

function priorityForIndex(index: number): Priority {
  if (index === 0) return "Critical";
  if (index <= 2) return "High";
  return "Medium";
}

function demandForIndex(index: number) {
  return Math.max(62, 90 - index * 6);
}

function demandLabel(demand: number) {
  if (demand >= 85) return "VERY HIGH";
  if (demand >= 72) return "HIGH";
  return "MODERATE";
}

export type MissingSkillInsight = {
  name: string;
  priority: Priority;
  explanation: string;
  demandPercent: number;
  demandLabel: string;
};

export type SkillGapAiResult = SkillGapResult & {
  matchedSkills: string[];
  recommendations: string[];
  breakdown: {
    roleSkillsPercent: number;
    fundamentalsPercent: number;
    portfolioPercent: number;
  };
  whyThisMatters: string;
  missingSkillInsights: MissingSkillInsight[];
  nextBestActions: string[];
  confidencePercent: number;
  simulatedFutureScore: number;
  simulatedOutcome: string;
};

function toTitleCase(value: string) {
  return value
    .split(" ")
    .filter(Boolean)
    .map((s) => s[0]?.toUpperCase() + s.slice(1))
    .join(" ");
}

export function analyzeSkills(currentSkills: string[], targetRole: string): SkillGapAiResult {
  const base = buildRoleAwareSkillGap(currentSkills, targetRole);

  const currentLower = new Set(base.currentSkills.map((s) => s.toLowerCase()));
  const missingLower = new Set(base.missingSkills.map((s) => s.toLowerCase()));
  const matchedSkills = base.currentSkills
    .filter((s) => !missingLower.has(s.toLowerCase()))
    .slice(0, 10);

  const missingSkillInsights: MissingSkillInsight[] = base.missingSkills.map((name, index) => {
    const demandPercent = demandForIndex(index);
    const p = priorityForIndex(index);
    const label = demandLabel(demandPercent);
    const explanation =
      p === "Critical"
        ? `Core requirement for ${toTitleCase(targetRole)} shortlisting.`
        : p === "High"
        ? `Frequently requested in job descriptions and interview rounds.`
        : `Strengthens your ability to deliver projects end-to-end.`;
    return { name, priority: p, explanation, demandPercent, demandLabel: label };
  });

  const recommendations = [
    base.missingSkills[0] ? `Learn ${base.missingSkills[0]} fundamentals.` : "Run a fresh analysis with more skills.",
    base.missingSkills[1] ? `Build a small project using ${base.missingSkills[1]}.` : "Complete one portfolio project.",
    "Update your profile skills and re-run the report.",
  ].filter(Boolean) as string[];

  const nextBestActions = base.missingSkills.slice(0, 3).map((s, i) => {
    if (i === 0) return `Learn ${s} basics (W3Schools)`;
    if (i === 1) return `Build a mini project using ${s}`;
    return `Add ${s} to your portfolio evidence`;
  });

  const fundamentalsPercent = Math.min(100, Math.round((matchedSkills.length / Math.max(1, matchedSkills.length + base.missingSkills.length)) * 100));
  const roleSkillsPercent = Math.min(100, Math.round(base.readinessScore));
  const portfolioPercent = Math.max(20, Math.min(90, 30 + Math.round(currentLower.size * 2)));

  const whyThisMatters =
    base.missingSkills.length > 0
      ? `You already have some strong foundations, but ${toTitleCase(
          targetRole
        )} roles typically require ${base.missingSkills
          .slice(0, 3)
          .join(", ")}. Closing these gaps will increase your interview readiness and unlock more matches.`
      : `You’re well-aligned for ${toTitleCase(
          targetRole
        )}. Your fastest path now is shipping portfolio projects and preparing for interviews.`;

  const simulatedFutureScore = Math.min(100, Math.max(base.readinessScore, base.readinessScore + Math.min(45, base.missingSkills.length * 10)));
  const simulatedOutcome =
    simulatedFutureScore >= 75
      ? `You will qualify for internships and junior roles in ${toTitleCase(targetRole)}.`
      : `You will noticeably improve shortlisting chances and practical readiness for ${toTitleCase(targetRole)} roles.`;

  const confidencePercent = Math.max(76, Math.min(93, 84 + Math.round((fundamentalsPercent - 50) / 10)));

  return {
    ...base,
    matchedSkills,
    recommendations,
    breakdown: {
      roleSkillsPercent,
      fundamentalsPercent,
      portfolioPercent,
    },
    whyThisMatters,
    missingSkillInsights,
    nextBestActions,
    confidencePercent,
    simulatedFutureScore,
    simulatedOutcome,
  };
}

