import { loadStudentProfileCache, incrementReadinessScore } from "@/lib/student-consistency";
import { calculateSubmissionScore } from "@/lib/project-scoring";
import { getScopedStorageKey } from "@/lib/session-scope";

export type SubmissionStatus = "Submitted" | "Approved" | "Rejected";

export type ProjectSubmission = {
  submissionId: string;
  studentId: number;
  studentName: string;
  projectTitle: string;
  githubLink: string;
  skillTag: string; // e.g. "node.js"
  status: SubmissionStatus;
  score: number;
  createdAt: number;
  reviewedAt?: number;
};

function submissionsKey() {
  return getScopedStorageKey("skillhire_local_project_submissions_v1");
}

function verifiedSkillsKey() {
  return getScopedStorageKey("skillhire_local_verified_skills_map_v1");
}

function safeParse<T>(raw: string | null, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function titleize(s: string) {
  return s
    .split(" ")
    .filter(Boolean)
    .map((w) => w[0]?.toUpperCase() + w.slice(1))
    .join(" ");
}

export function normalizeSkill(s: string) {
  return s.trim().toLowerCase();
}

export function loadSubmissions(): ProjectSubmission[] {
  const raw = safeParse<ProjectSubmission[]>(localStorage.getItem(submissionsKey()), []);
  return raw.map((s) => ({
    ...s,
    score:
      typeof s.score === "number" && !Number.isNaN(s.score)
        ? s.score
        : calculateSubmissionScore(s.githubLink, s.projectTitle),
  }));
}

export function saveSubmissions(items: ProjectSubmission[]) {
  localStorage.setItem(submissionsKey(), JSON.stringify(items));
}

export function loadVerifiedSkillsMap(): Record<string, string[]> {
  return safeParse<Record<string, string[]>>(localStorage.getItem(verifiedSkillsKey()), {});
}

export function saveVerifiedSkillsMap(map: Record<string, string[]>) {
  localStorage.setItem(verifiedSkillsKey(), JSON.stringify(map));
}

export function getVerifiedSkillsForStudent(studentId: number): string[] {
  const map = loadVerifiedSkillsMap();
  const list = map[String(studentId)];
  return Array.isArray(list) ? list.filter((x) => typeof x === "string") : [];
}

export function addVerifiedSkillForStudent(studentId: number, skillTag: string) {
  const map = loadVerifiedSkillsMap();
  const key = String(studentId);
  const existing = new Set((map[key] ?? []).map(normalizeSkill));
  existing.add(normalizeSkill(skillTag));
  map[key] = Array.from(existing).map(titleize);
  saveVerifiedSkillsMap(map);
}

export function getCurrentStudentName() {
  const cached = loadStudentProfileCache();
  const name = typeof cached?.name === "string" ? cached.name : "";
  return name.trim() ? name.trim() : "Student";
}

export function createSubmission(input: { studentId: number; projectTitle: string; githubLink: string; skillTag: string }) {
  const existing = loadSubmissions();
  const score = calculateSubmissionScore(input.githubLink, input.projectTitle);
  const submission: ProjectSubmission = {
    submissionId: randomId(),
    studentId: input.studentId,
    studentName: getCurrentStudentName(),
    projectTitle: input.projectTitle,
    githubLink: input.githubLink,
    skillTag: normalizeSkill(input.skillTag),
    status: "Submitted",
    score,
    createdAt: Date.now(),
  };
  const next = [submission, ...existing];
  saveSubmissions(next);
  if (score > 70) incrementReadinessScore(10);
  return submission;
}

export function updateLocalSubmissionScore(submissionId: string, score: number) {
  const clamped = Math.max(0, Math.min(100, Math.round(score)));
  const items = loadSubmissions();
  const next = items.map((s) => (s.submissionId === submissionId ? { ...s, score: clamped } : s));
  saveSubmissions(next);
}

export function updateSubmissionStatus(submissionId: string, status: SubmissionStatus) {
  const items = loadSubmissions();
  const next = items.map((s) =>
    s.submissionId === submissionId ? { ...s, status, reviewedAt: Date.now() } : s
  );
  saveSubmissions(next);
}

export function approveSubmission(submissionId: string) {
  const items = loadSubmissions();
  const found = items.find((s) => s.submissionId === submissionId);
  if (!found) return;
  updateSubmissionStatus(submissionId, "Approved");
  addVerifiedSkillForStudent(found.studentId, found.skillTag);
}

function randomId() {
  try {
    const bytes = new Uint8Array(12);
    crypto.getRandomValues(bytes);
    return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
  } catch {
    return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  }
}

