import { calculateSubmissionScore } from "@/lib/project-scoring";
import { listAllVerifiedSkillsForCompany } from "@/lib/supabase/hiring";
import { listStudentProfilesForCompany } from "@/lib/supabase/user-profiles";
import { getPipelineDemoPerson } from "@/lib/company-pipeline-demo";

export type RankedCandidate = {
  studentKey: string;
  name: string;
  role: string;
  readiness_score: number;
  verifiedSkillsCount: number;
  avgProjectScore: number;
  rankScore: number;
  displayRank: number;
};

type AggRow = {
  studentKey: string;
  name: string;
  role: string;
  readiness_score: number;
  verifiedSkillsCount: number;
  submissionScores: number[];
};

export function calculateCandidateRank(student: {
  readiness_score: number;
  verifiedSkillsCount: number;
  avgProjectScore: number;
}) {
  const score = student.readiness_score || 0;
  const skills = student.verifiedSkillsCount || 0;
  const projectScore = student.avgProjectScore || 0;
  return score * 0.5 + skills * 10 + projectScore * 0.3;
}

function resolveSubmissionScore(s: { score?: number | null; github_link: string; project_title: string }): number {
  return typeof s.score === "number" && !Number.isNaN(s.score)
    ? s.score
    : calculateSubmissionScore(s.github_link, s.project_title);
}

function displayNameForKey(key: string, fallbackName: string) {
  if (fallbackName.trim()) return fallbackName.trim();
  if (key.startsWith("local:")) return `Student #${key.replace("local:", "")}`;
  if (key.includes("-") && key.length > 12) return `Student ${key.slice(0, 8)}…`;
  return key;
}

/**
 * Builds ranked candidates from the same applications/submissions you show on the dashboard,
 * plus Supabase verified_skills and profiles when available. No unrelated local talent list.
 */
export async function fetchRankedTopCandidates(input: {
  applications: { student_user_id: string }[];
  submissions: { student_user_id: string; score?: number | null; github_link: string; project_title: string }[];
  limit?: number;
}): Promise<RankedCandidate[]> {
  const limit = input.limit ?? 5;
  const map = new Map<string, AggRow>();

  const ensure = (key: string) => {
    const k = String(key);
    if (!map.has(k)) {
      map.set(k, {
        studentKey: k,
        name: "",
        role: "Student",
        readiness_score: 0,
        verifiedSkillsCount: 0,
        submissionScores: [],
      });
    }
    return map.get(k)!;
  };

  let verifiedRows: Awaited<ReturnType<typeof listAllVerifiedSkillsForCompany>> = [];
  let profiles: Awaited<ReturnType<typeof listStudentProfilesForCompany>> = [];
  try {
    [verifiedRows, profiles] = await Promise.all([
      listAllVerifiedSkillsForCompany(),
      listStudentProfilesForCompany(),
    ]);
  } catch {
    verifiedRows = [];
    profiles = [];
  }

  const verifiedCountByStudent = new Map<string, number>();
  for (const v of verifiedRows) {
    const uid = String(v.student_user_id);
    verifiedCountByStudent.set(uid, (verifiedCountByStudent.get(uid) ?? 0) + 1);
  }

  for (const [uid, count] of verifiedCountByStudent) {
    const row = ensure(uid);
    row.verifiedSkillsCount = Math.max(row.verifiedSkillsCount, count);
  }

  for (const s of input.submissions) {
    const row = ensure(String(s.student_user_id));
    row.submissionScores.push(resolveSubmissionScore(s));
  }

  for (const a of input.applications) {
    ensure(String(a.student_user_id));
  }

  const profileByUser = new Map(profiles.map((p) => [p.user_id, p]));
  for (const [key, row] of map) {
    const prof = profileByUser.get(key);
    if (prof) {
      row.name = prof.name || row.name;
      row.role = prof.career_goal || row.role;
      if (typeof prof.readiness_score === "number") {
        row.readiness_score = Math.max(row.readiness_score, prof.readiness_score);
      }
    }
    const pipeline = getPipelineDemoPerson(key);
    if (pipeline) {
      row.name = pipeline.name;
      row.role = pipeline.role;
      row.readiness_score = Math.max(row.readiness_score, pipeline.readinessScore);
      row.verifiedSkillsCount = Math.max(row.verifiedSkillsCount, pipeline.verifiedSkillsCount);
    }
    row.name = displayNameForKey(key, row.name);
  }

  const ranked: RankedCandidate[] = [...map.values()]
    .map((row) => {
      const avgProjectScore =
        row.submissionScores.length === 0
          ? 0
          : row.submissionScores.reduce((a, b) => a + b, 0) / row.submissionScores.length;
      const name = row.name.trim() ? row.name : displayNameForKey(row.studentKey, "");
      const rankScore = calculateCandidateRank({
        readiness_score: row.readiness_score,
        verifiedSkillsCount: row.verifiedSkillsCount,
        avgProjectScore,
      });
      return {
        studentKey: row.studentKey,
        name,
        role: row.role || "Student",
        readiness_score: row.readiness_score,
        verifiedSkillsCount: row.verifiedSkillsCount,
        avgProjectScore: Math.round(avgProjectScore * 10) / 10,
        rankScore,
        displayRank: 0,
      };
    })
    .sort((a, b) => b.rankScore - a.rankScore)
    .slice(0, limit)
    .map((c, i) => ({ ...c, displayRank: i + 1 }));

  return ranked;
}
