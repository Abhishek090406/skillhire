import { loadSkillGapResult } from "@/lib/skill-gap";
import { getScopedStorageKey } from "@/lib/session-scope";

export const STUDENT_PROFILE_CACHE_KEY = "skillhire_student_profile_cache";

export type StudentBase = {
  name?: string | null;
  careerGoal?: string | null;
  readinessScore?: number | null;
  skills?: string[];
  bio?: string | null;
  githubUrl?: string | null;
  linkedinUrl?: string | null;
  [key: string]: unknown;
};

export function loadStudentProfileCache(): Partial<StudentBase> | null {
  const raw = localStorage.getItem(getScopedStorageKey(STUDENT_PROFILE_CACHE_KEY));
  if (!raw) return null;
  try {
    return JSON.parse(raw) as Partial<StudentBase>;
  } catch {
    return null;
  }
}

export function saveStudentProfileCache(value: Partial<StudentBase>) {
  localStorage.setItem(getScopedStorageKey(STUDENT_PROFILE_CACHE_KEY), JSON.stringify(value));
}

export function unifyStudentData<T extends StudentBase>(baseStudent: T): T {
  const skillGap = loadSkillGapResult();
  const cachedProfile = loadStudentProfileCache();

  const computedFromSkillGap = typeof skillGap?.readinessScore === "number" ? skillGap.readinessScore : null;
  const computedFromCache =
    typeof cachedProfile?.readinessScore === "number" ? cachedProfile.readinessScore : null;

  const unified = {
    ...baseStudent,
    ...(cachedProfile ?? {}),
    name: cachedProfile?.name || baseStudent.name || "",
    careerGoal: skillGap?.targetRole || cachedProfile?.careerGoal || baseStudent.careerGoal || "",
    readinessScore:
      Math.max(
        computedFromSkillGap ?? 0,
        computedFromCache ?? 0,
        typeof baseStudent.readinessScore === "number" ? baseStudent.readinessScore : 0
      ) ??
      (typeof baseStudent.readinessScore === "number" ? baseStudent.readinessScore : 0),
    skills: skillGap?.currentSkills?.length
      ? skillGap.currentSkills
      : Array.isArray(cachedProfile?.skills)
      ? cachedProfile.skills
      : Array.isArray(baseStudent.skills)
      ? baseStudent.skills
      : [],
  };

  return unified as T;
}

export function incrementReadinessScore(points: number) {
  const cached = loadStudentProfileCache() ?? {};
  const current = typeof cached.readinessScore === "number" ? cached.readinessScore : 0;
  saveStudentProfileCache({ ...cached, readinessScore: Math.min(100, current + points) });
}
