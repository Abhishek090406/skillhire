import { getScopedStorageKey } from "@/lib/session-scope";
import { loadSkillGapResult } from "@/lib/skill-gap";

export type SkillLabChallenge = {
  id: string;
  title: string;
  description: string;
  requiredSkills: string[];
  difficulty: "Beginner" | "Intermediate" | "Advanced";
  primarySkillToVerify: string; // e.g. "node.js"
  starterCode: string;
  language: "javascript" | "typescript";
  passContainsAll: string[];
  outputOnPass: string;
  outputOnFail: string;
};

const COMPLETED_CHALLENGES_KEY = "skillhire_skilllab_completed_challenges"; // string[]
const SKILLLAB_VERIFIED_SKILLS_KEY = "skillhire_skilllab_verified_skills"; // string[]
const ASSESSMENTS_PASSED_KEY = "skillhire_assessments_passed"; // string[]

function safeParse<T>(raw: string | null, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function normalizeSkill(s: string) {
  return s.trim().toLowerCase();
}

function readStringArray(key: string) {
  const raw = localStorage.getItem(getScopedStorageKey(key));
  const parsed = safeParse<unknown>(raw, []);
  if (!Array.isArray(parsed)) return [] as string[];
  return parsed.filter((x) => typeof x === "string").map((s) => s.trim()).filter(Boolean);
}

function writeStringArray(key: string, value: string[]) {
  localStorage.setItem(getScopedStorageKey(key), JSON.stringify(value));
}

export function loadCompletedChallenges(): string[] {
  return readStringArray(COMPLETED_CHALLENGES_KEY);
}

export function loadSkillLabVerifiedSkills(): string[] {
  return readStringArray(SKILLLAB_VERIFIED_SKILLS_KEY);
}

export function loadAssessmentVerifiedSkills(): string[] {
  return readStringArray(ASSESSMENTS_PASSED_KEY);
}

export function markChallengeCompleted(challengeId: string) {
  const existing = new Set(loadCompletedChallenges());
  existing.add(challengeId);
  writeStringArray(COMPLETED_CHALLENGES_KEY, Array.from(existing));
}

export function verifySkill(skill: string) {
  const s = normalizeSkill(skill);

  const lab = new Set(loadSkillLabVerifiedSkills().map(normalizeSkill));
  lab.add(s);
  writeStringArray(SKILLLAB_VERIFIED_SKILLS_KEY, Array.from(lab));

  // Treat Skill Lab pass as an "assessment passed" proof so Profile verification works.
  const assessments = new Set(loadAssessmentVerifiedSkills().map(normalizeSkill));
  assessments.add(s);
  writeStringArray(ASSESSMENTS_PASSED_KEY, Array.from(assessments));
}

export function evaluateChallenge(code: string, challenge: SkillLabChallenge) {
  const normalized = code.toLowerCase();
  const missingTokens = challenge.passContainsAll.filter((t) => !normalized.includes(t.toLowerCase()));
  const pass = missingTokens.length === 0;
  return {
    pass,
    missingTokens,
    output: pass ? challenge.outputOnPass : challenge.outputOnFail,
  };
}

export function getSkillLabChallenges(): SkillLabChallenge[] {
  return [
    {
      id: "express-routing",
      title: "Express API Routing (GET + POST)",
      description: "Write minimal Express routes for GET /health and POST /login.",
      requiredSkills: ["node.js", "rest apis", "authentication"],
      difficulty: "Intermediate",
      primarySkillToVerify: "node.js",
      starterCode:
        `// Goal: create GET /health + POST /login\n` +
        `// You can write pseudo-code (no real server needed).\n\n` +
        `// Example tokens we look for: app.get, app.post\n\n` +
        `const app = {}\n\n`,
      language: "javascript",
      passContainsAll: ["app.get", "app.post"],
      outputOnPass: "PASS: Routes detected. Your Node.js API basics look solid.",
      outputOnFail: "FAIL: Missing route handlers. Add both app.get and app.post.",
    },
    {
      id: "react-state",
      title: "React State + Button Interaction",
      description: "Create a component that increments a counter using useState.",
      requiredSkills: ["react", "javascript", "state management"],
      difficulty: "Beginner",
      primarySkillToVerify: "react",
      starterCode:
        `import { useState } from "react";\n\n` +
        `export default function Counter() {\n` +
        `  // TODO: implement counter\n` +
        `  return (\n` +
        `    <div>\n` +
        `      <button>Increment</button>\n` +
        `    </div>\n` +
        `  );\n` +
        `}\n`,
      language: "typescript",
      passContainsAll: ["useState", "set", "onClick"],
      outputOnPass: "PASS: State + interaction detected. React fundamentals verified.",
      outputOnFail: "FAIL: Add useState and an onClick handler that updates state.",
    },
    {
      id: "sql-filter",
      title: "SQL: Filter + Sort Query",
      description: "Write a SQL query that selects from users where role='student' and orders by created_at desc.",
      requiredSkills: ["databases", "sql"],
      difficulty: "Beginner",
      primarySkillToVerify: "sql",
      starterCode: `-- Write your query here\nSELECT * FROM users;\n`,
      language: "javascript",
      passContainsAll: ["select", "from", "where", "order by"],
      outputOnPass: "PASS: Query structure detected. SQL basics verified.",
      outputOnFail: "FAIL: Include WHERE and ORDER BY clauses in your query.",
    },
  ];
}

export function getSuggestedChallengeIdsFromSkillGap() {
  const gap = loadSkillGapResult();
  const missing = (gap?.missingSkills ?? []).map(normalizeSkill);
  const challenges = getSkillLabChallenges();
  return challenges
    .filter((c) => c.requiredSkills.map(normalizeSkill).some((s) => missing.includes(s)))
    .map((c) => c.id);
}

