import { getScopedStorageKey } from "@/lib/session-scope";

export const SKILL_GAP_STORAGE_KEY = "skillhire_skill_gap_result";

export type LearningStep = {
  step: number;
  title: string;
  type: "course" | "project" | "video";
  estimatedDuration: string;
  description: string;
  completed: boolean;
};

export type SkillGapResult = {
  targetRole: string;
  currentSkills: string[];
  missingSkills: string[];
  matchedSkills?: string[];
  readinessScore: number;
  summary: string;
  industryDemandSkills: { skill: string; demandLevel: number }[];
  learningPath: LearningStep[];
  updatedAt?: number;
  confidencePercent?: number;
  recommendations?: string[];
  nextBestActions?: string[];
};

/**
 * Canonical role → required skills map used for dynamic scoring.
 * Skills are stored in lowercase to make matching deterministic.
 */
export const ROLE_SKILLS: Record<string, string[]> = {
  "Backend Developer": ["node.js", "databases", "rest apis", "authentication", "system design", "caching"],
  "Frontend Developer": ["react", "javascript", "css", "html", "state management", "testing"],
  "Full Stack Developer": ["react", "javascript", "css", "html", "node.js", "databases", "rest apis", "authentication"],
  "Data Analyst": ["python", "sql", "statistics", "data visualization"],
  "ML Engineer": ["python", "machine learning", "model evaluation", "feature engineering"],
};

const ROLE_SKILL_MAP_FALLBACK: Record<string, string[]> = {
  frontend: ["html", "css", "javascript", "typescript", "react", "state management", "testing", "accessibility"],
  backend: ["node.js", "databases", "rest apis", "authentication", "system design", "caching", "testing", "cloud basics"],
  fullstack: ["html", "css", "javascript", "typescript", "react", "node.js", "databases", "rest apis", "testing"],
  data: ["python", "sql", "statistics", "data visualization", "machine learning", "feature engineering", "model evaluation"],
  devops: ["linux", "docker", "ci/cd", "cloud basics", "monitoring", "infrastructure as code", "security basics"],
  mobile: ["javascript", "typescript", "react native", "state management", "api integration", "testing", "app performance"],
  uiux: ["user research", "wireframing", "figma", "design systems", "usability testing", "accessibility", "design handoff"],
};

export function normalize(skills: string[]) {
  return skills.map((s) => s.trim().toLowerCase()).filter(Boolean);
}

export function analyzeSkills(userSkills: string[], targetRole: string) {
  const required = getRoleSkills(targetRole);
  const normalizedUser = normalize(userSkills);

  const matched = required.filter((skill) => normalizedUser.includes(skill));
  const missing = required.filter((skill) => !normalizedUser.includes(skill));

  return { matched, missing, total: required.length };
}

export function calculateScore(matchedCount: number, total: number) {
  if (total === 0) return 0;
  const baseScore = (matchedCount / total) * 100;
  return Math.round(baseScore);
}

function getRoleSkills(goal: string) {
  // Case-insensitive lookup against ROLE_SKILLS keys first.
  const direct = Object.entries(ROLE_SKILLS).find(([k]) => k.toLowerCase() === goal.trim().toLowerCase());
  if (direct) return direct[1];

  const roleKey = inferRoleKey(goal);
  return ROLE_SKILL_MAP_FALLBACK[roleKey] ?? [];
}

function inferRoleKey(goal: string) {
  const value = goal.toLowerCase();
  if (value.includes("front")) return "frontend";
  if (value.includes("back")) return "backend";
  if (value.includes("full")) return "fullstack";
  if (value.includes("data") || value.includes("ml") || value.includes("ai")) return "data";
  if (value.includes("devops") || value.includes("sre") || value.includes("cloud")) return "devops";
  if (value.includes("mobile") || value.includes("android") || value.includes("ios")) return "mobile";
  if (value.includes("ux") || value.includes("ui") || value.includes("design")) return "uiux";
  return "fullstack";
}

export function buildLearningPathFromMissingSkills(missingSkills: string[], goal: string): LearningStep[] {
  return missingSkills.map((skill, index) => ({
    step: index + 1,
    title: `Master ${skill}`,
    type: index % 3 === 0 ? "course" : index % 3 === 1 ? "project" : "video",
    estimatedDuration: index % 3 === 1 ? "1 week" : "4-6 days",
    description: `Build practical ${skill} capability for your ${goal} role through guided learning and hands-on tasks.`,
    completed: false,
  }));
}

export function buildRoleAwareSkillGap(skills: string[], goal: string): SkillGapResult {
  const normalizedSkills = normalize(skills);
  const required = getRoleSkills(goal);

  const result = analyzeSkills(normalizedSkills, goal);
  const readinessScore = calculateScore(result.matched.length, result.total);

  const missingSkillsAll = result.missing.map((s) => titleize(s));
  const missingSkills = missingSkillsAll.slice(0, 6);

  const summary =
    result.missing.length > 4
      ? `You are far from ready for ${goal}. Start with ${missingSkills.slice(0, 2).join(" and ")} to build fundamentals.`
      : result.missing.length >= 2
      ? `You are close to ready for ${goal}. Fix ${missingSkills.slice(0, 2).join(" and ")} to improve shortlisting.`
      : `You are job ready for ${goal}. Focus on proof (projects) and interview preparation.`;

  return {
    targetRole: goal,
    currentSkills: normalizedSkills.map((s) => titleize(s)),
    missingSkills,
    matchedSkills: result.matched.map((s) => titleize(s)),
    readinessScore,
    summary,
    industryDemandSkills: missingSkills.map((skill, index) => ({
      skill,
      demandLevel: Math.max(60, 92 - index * 6),
    })),
    learningPath: buildLearningPathFromMissingSkills(missingSkills, goal),
  };
}

function titleize(s: string) {
  return s
    .split(" ")
    .filter(Boolean)
    .map((w) => w[0]?.toUpperCase() + w.slice(1))
    .join(" ");
}

export function saveSkillGapResult(result: SkillGapResult) {
  localStorage.setItem(
    getScopedStorageKey(SKILL_GAP_STORAGE_KEY),
    JSON.stringify({ ...result, updatedAt: Date.now() })
  );
}

export function loadSkillGapResult(): SkillGapResult | null {
  const raw = localStorage.getItem(getScopedStorageKey(SKILL_GAP_STORAGE_KEY));
  if (!raw) return null;
  try {
    return JSON.parse(raw) as SkillGapResult;
  } catch {
    return null;
  }
}
