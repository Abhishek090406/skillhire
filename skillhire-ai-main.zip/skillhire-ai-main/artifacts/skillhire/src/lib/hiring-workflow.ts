import { loadSkillGapResult } from "@/lib/skill-gap";
import { loadStudentProfileCache } from "@/lib/student-consistency";

export type ApplicationStatus = "Applied" | "Under Review" | "Approved" | "Rejected";

export type JobApplication = {
  applicationId: string;
  jobId: number;
  studentId: number;
  studentName: string;
  githubLink: string;
  portfolioLink?: string;
  status: ApplicationStatus;
  timestamp: number;
};

/** Shared across roles in one browser so student applies + company sees the same local demo pool. */
const STORAGE_KEY = "skillhire_appliedJobs_v1";

function safeParse<T>(raw: string | null, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function loadApplications(): JobApplication[] {
  return safeParse<JobApplication[]>(localStorage.getItem(STORAGE_KEY), []);
}

export function saveApplications(apps: JobApplication[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(apps));
}

export function getStudentNameForApplication() {
  const cached = loadStudentProfileCache();
  const name = typeof cached?.name === "string" ? cached.name : "";
  return name.trim() ? name.trim() : "Student";
}

export function submitJobApplication(input: {
  jobId: number;
  studentId: number;
  githubLink: string;
  portfolioLink?: string;
}) {
  const apps = loadApplications();
  const existing = apps.find((a) => a.jobId === input.jobId && a.studentId === input.studentId);
  if (existing) return { ok: true as const, created: false as const, application: existing };

  const application: JobApplication = {
    applicationId: cryptoRandomId(),
    jobId: input.jobId,
    studentId: input.studentId,
    studentName: getStudentNameForApplication(),
    githubLink: input.githubLink,
    portfolioLink: input.portfolioLink,
    status: "Applied",
    timestamp: Date.now(),
  };

  const next = [application, ...apps];
  saveApplications(next);
  return { ok: true as const, created: true as const, application };
}

export function updateApplicationStatus(applicationId: string, status: ApplicationStatus) {
  const apps = loadApplications();
  const next = apps.map((a) => (a.applicationId === applicationId ? { ...a, status } : a));
  saveApplications(next);
}

export function getApplicationForJob(jobId: number, studentId: number) {
  return loadApplications().find((a) => a.jobId === jobId && a.studentId === studentId) ?? null;
}

export function getUserSkillsForMatching(): string[] {
  const gap = loadSkillGapResult();
  if (Array.isArray(gap?.currentSkills) && gap!.currentSkills.length) return gap!.currentSkills;
  const cached = loadStudentProfileCache();
  if (Array.isArray(cached?.skills) && cached!.skills.length) return cached!.skills;
  return [];
}

export function normalizeSkill(s: string) {
  return s.trim().toLowerCase();
}

export function computeJobMatch(requiredSkills: string[], userSkills: string[]) {
  const req = (requiredSkills ?? []).map(normalizeSkill).filter(Boolean);
  const user = new Set((userSkills ?? []).map(normalizeSkill).filter(Boolean));

  const matched = req.filter((r) => user.has(r));
  const missing = req.filter((r) => !user.has(r));
  const matchPercent = req.length ? Math.round((matched.length / req.length) * 100) : 100;

  return {
    matchPercent,
    verifiedSkills: matched.map(titleize),
    missingSkills: missing.map(titleize),
  };
}

export function computeWhyMatch(verifiedSkills: string[], missingSkills: string[]) {
  const reasons: string[] = [];
  if (verifiedSkills[0]) reasons.push(`You already show ${verifiedSkills[0]} experience.`);
  if (verifiedSkills[1]) reasons.push(`You match ${verifiedSkills[1]} which appears frequently in this role.`);
  if (missingSkills[0]) reasons.push(`Your fastest improvement is learning ${missingSkills[0]}.`);
  return reasons.slice(0, 3);
}

export function statusTone(status: ApplicationStatus) {
  if (status === "Approved") return "success";
  if (status === "Rejected") return "danger";
  if (status === "Under Review") return "warning";
  return "neutral";
}

function titleize(s: string) {
  return s
    .split(" ")
    .filter(Boolean)
    .map((w) => w[0]?.toUpperCase() + w.slice(1))
    .join(" ");
}

function cryptoRandomId() {
  // Use crypto when available (most browsers), fallback to Math.random for older runtimes.
  try {
    const bytes = new Uint8Array(16);
    crypto.getRandomValues(bytes);
    return Array.from(bytes)
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
  } catch {
    return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  }
}

