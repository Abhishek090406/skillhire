/**
 * Persist approve/reject for demo rows (ids starting with demo-) when Supabase has no matching rows.
 */
import type { JobApplication } from "@/lib/hiring-workflow";
import { getScopedStorageKey } from "@/lib/session-scope";

function appOverrideKey() {
  return getScopedStorageKey("skillhire_company_demo_application_status_v1");
}

function subOverrideKey() {
  return getScopedStorageKey("skillhire_company_demo_submission_status_v1");
}

function safeParse<T>(raw: string | null, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function loadApplicationStatusOverrides(): Record<string, string> {
  return safeParse<Record<string, string>>(localStorage.getItem(appOverrideKey()), {});
}

export function saveApplicationStatusOverride(applicationId: string, status: string) {
  const next = { ...loadApplicationStatusOverrides(), [applicationId]: status };
  localStorage.setItem(appOverrideKey(), JSON.stringify(next));
}

export function applyApplicationStatusOverrides<T extends { id: string; status: string }>(rows: T[]): T[] {
  const o = loadApplicationStatusOverrides();
  return rows.map((r) => (o[r.id] ? { ...r, status: o[r.id] as T["status"] } : r));
}

/** Merge dashboard demo overrides onto `skillhire_appliedJobs_v1` rows (same `demo-app-*` ids). */
export function applyJobApplicationOverrides(apps: JobApplication[]): JobApplication[] {
  const o = loadApplicationStatusOverrides();
  return apps.map((a) => {
    const s = o[a.applicationId];
    return s ? { ...a, status: s as JobApplication["status"] } : a;
  });
}

export function clearApplicationStatusOverride(applicationId: string) {
  const o = loadApplicationStatusOverrides();
  if (!(applicationId in o)) return;
  const next = { ...o };
  delete next[applicationId];
  localStorage.setItem(appOverrideKey(), JSON.stringify(next));
}

export function loadSubmissionStatusOverrides(): Record<string, { status: string; reviewed_at: string | null }> {
  return safeParse(localStorage.getItem(subOverrideKey()), {});
}

export function saveSubmissionStatusOverride(
  submissionId: string,
  status: string,
  reviewedAt: string | null
) {
  const next = { ...loadSubmissionStatusOverrides(), [submissionId]: { status, reviewed_at: reviewedAt } };
  localStorage.setItem(subOverrideKey(), JSON.stringify(next));
}

export function applySubmissionStatusOverrides<
  T extends { id: string; status: string; reviewed_at: string | null }
>(rows: T[]): T[] {
  const o = loadSubmissionStatusOverrides();
  return rows.map((r) => {
    const patch = o[r.id];
    return patch ? { ...r, status: patch.status as T["status"], reviewed_at: patch.reviewed_at } : r;
  });
}
