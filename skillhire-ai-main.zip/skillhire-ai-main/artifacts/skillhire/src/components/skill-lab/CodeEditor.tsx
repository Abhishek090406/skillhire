import Editor from "@monaco-editor/react";

export function CodeEditor({
  value,
  onChange,
  language,
  height = 560,
}: {
  value: string;
  onChange: (next: string) => void;
  language: "javascript" | "typescript";
  height?: number;
}) {
  return (
    <div className="rounded-xl overflow-hidden border border-border bg-[#0b0f17]">
      <Editor
        height={`${height}px`}
        defaultLanguage={language}
        language={language}
        value={value}
        onChange={(v) => onChange(v ?? "")}
        theme="vs-dark"
        options={{
          fontSize: 15,
          minimap: { enabled: false },
          wordWrap: "on",
          scrollBeyondLastLine: false,
          automaticLayout: true,
          padding: { top: 14, bottom: 14 },
        }}
      />
    </div>
  );
}

