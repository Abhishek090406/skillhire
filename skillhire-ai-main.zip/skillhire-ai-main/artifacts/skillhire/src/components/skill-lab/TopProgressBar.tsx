import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { CheckCircle2 } from "lucide-react";

export function TopProgressBar({
  completedCount,
  totalCount,
  verifiedSkills,
}: {
  completedCount: number;
  totalCount: number;
  verifiedSkills: string[];
}) {
  const pct = totalCount === 0 ? 0 : Math.round((completedCount / totalCount) * 100);

  return (
    <div className="rounded-xl border border-border bg-card px-4 py-3">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="text-sm text-muted-foreground">
            Completed: <span className="text-foreground font-semibold">{completedCount}/{totalCount}</span>
          </div>
          <div className="w-40">
            <Progress value={pct} className="h-2" />
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {verifiedSkills.slice(0, 6).map((s) => (
            <Badge key={s} variant="outline" className="border-primary/30 text-primary bg-primary/5">
              <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
              {s}
            </Badge>
          ))}
          {verifiedSkills.length === 0 ? <Badge variant="secondary">No verified skills yet</Badge> : null}
        </div>
      </div>
    </div>
  );
}

