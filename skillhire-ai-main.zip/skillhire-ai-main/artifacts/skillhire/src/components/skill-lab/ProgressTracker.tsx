import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2 } from "lucide-react";

export function ProgressTracker({
  completedCount,
  totalCount,
  verifiedSkills,
}: {
  completedCount: number;
  totalCount: number;
  verifiedSkills: string[];
}) {
  return (
    <Card className="border-border">
      <CardHeader className="pb-3">
        <CardTitle className="text-base">Progress</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="text-sm text-muted-foreground">
          Completed challenges:{" "}
          <span className="text-foreground font-semibold">
            {completedCount}/{totalCount}
          </span>
        </div>
        <div className="space-y-2">
          <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Verified skills</div>
          <div className="flex flex-wrap gap-2">
            {verifiedSkills.length ? (
              verifiedSkills.map((s) => (
                <Badge key={s} variant="outline" className="border-primary/30 text-primary bg-primary/5">
                  <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                  {s}
                </Badge>
              ))
            ) : (
              <Badge variant="secondary">None yet</Badge>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

