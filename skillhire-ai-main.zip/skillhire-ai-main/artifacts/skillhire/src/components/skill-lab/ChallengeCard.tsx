import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Sparkles } from "lucide-react";
import type { SkillLabChallenge } from "@/lib/skill-lab";

export function ChallengeCard({
  challenge,
  selected,
  completed,
  suggested,
  onSelect,
}: {
  challenge: SkillLabChallenge;
  selected: boolean;
  completed: boolean;
  suggested: boolean;
  onSelect: () => void;
}) {
  return (
    <Card
      className={[
        "transition-colors",
        selected ? "border-primary/30 shadow-[0_0_40px_rgba(16,185,129,0.10)]" : "hover:border-primary/25",
      ].join(" ")}
    >
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-3">
          <CardTitle className="text-base">{challenge.title}</CardTitle>
          {suggested ? (
            <Badge variant="outline" className="border-primary/30 text-primary bg-primary/5">
              <Sparkles className="w-3.5 h-3.5 mr-1" />
              Suggested
            </Badge>
          ) : null}
        </div>
        <div className="text-xs text-muted-foreground">{challenge.description}</div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex flex-wrap gap-2">
          <Badge variant="secondary" className="text-[10px] uppercase tracking-wider">
            {challenge.difficulty}
          </Badge>
          {challenge.requiredSkills.slice(0, 4).map((s) => (
            <Badge key={s} variant="outline" className="text-xs bg-background">
              {s}
            </Badge>
          ))}
        </div>
        <div className="text-xs text-muted-foreground">
          Verifies: <span className="text-foreground font-medium">{challenge.primarySkillToVerify}</span>
        </div>
      </CardContent>
      <CardFooter className="pt-0">
        <Button className="w-full" variant={selected ? "default" : "secondary"} onClick={onSelect}>
          {completed ? "Review" : selected ? "Selected" : "Open"}
        </Button>
      </CardFooter>
    </Card>
  );
}

