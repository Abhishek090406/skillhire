import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, XCircle } from "lucide-react";

export function ResultPanel({
  status,
  isEvaluating,
  output,
  missingTokens,
  successDetails,
}: {
  status: "idle" | "pass" | "fail";
  isEvaluating?: boolean;
  output: string;
  missingTokens: string[];
  successDetails?: { verifiedSkill: string; scoreDelta: number } | null;
}) {
  return (
    <Card
      className={[
        "border-border transition-all",
        status === "pass" ? "shadow-[0_0_40px_rgba(16,185,129,0.10)]" : "",
      ].join(" ")}
    >
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center justify-between">
          Output
          {isEvaluating ? (
            <Badge variant="secondary">Evaluating…</Badge>
          ) : status === "pass" ? (
            <Badge variant="outline" className="border-primary/30 text-primary bg-primary/5">
              <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
              PASS
            </Badge>
          ) : status === "fail" ? (
            <Badge variant="outline" className="border-destructive/30 text-destructive bg-destructive/5">
              <XCircle className="w-3.5 h-3.5 mr-1" />
              FAIL
            </Badge>
          ) : (
            <Badge variant="secondary">Waiting</Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="text-sm text-muted-foreground whitespace-pre-wrap animate-in fade-in duration-300">
          {output}
        </div>
        {status === "pass" && successDetails ? (
          <div className="text-sm">
            <div className="text-primary font-semibold">Success</div>
            <div className="text-xs text-muted-foreground">
              Skill verified: <span className="text-foreground font-medium">{successDetails.verifiedSkill}</span> • Readiness +{successDetails.scoreDelta}
            </div>
          </div>
        ) : null}
        {status === "fail" && missingTokens.length ? (
          <div className="text-xs text-muted-foreground">
            Missing tokens:{" "}
            <span className="text-foreground font-medium">{missingTokens.join(", ")}</span>
          </div>
        ) : null}
      </CardContent>
    </Card>
  );
}

