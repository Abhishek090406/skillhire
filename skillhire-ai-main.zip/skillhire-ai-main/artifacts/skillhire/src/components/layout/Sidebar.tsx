import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  Target, 
  Route as RouteIcon, 
  Briefcase, 
  Building2, 
  Code2,
  UserCircle, 
  Users, 
  LogOut,
  UsersRound,
  FolderPlus,
  BriefcaseBusiness,
  FileText,
  ShieldCheck,
  FileSearch,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { supabase } from "@/lib/supabase/client";

const STUDENT_LINKS = [
  { href: "/student-dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/skill-gap", label: "Skill Gap", icon: Target },
  { href: "/resume-analyzer", label: "Resume Analyzer", icon: FileSearch },
  { href: "/learning-path", label: "Learning Path", icon: RouteIcon },
  { href: "/skill-lab", label: "Skill Lab", icon: Code2 },
  { href: "/projects", label: "Projects", icon: Briefcase },
  { href: "/jobs", label: "Jobs & Internships", icon: Building2 },
  { href: "/mentors", label: "Mentors", icon: Users },
  { href: "/profile", label: "Profile", icon: UserCircle },
];

const COMPANY_LINKS = [
  { href: "/company-dashboard", label: "Overview", icon: LayoutDashboard },
  { href: "/company-post-project", label: "Post Project", icon: FolderPlus },
  { href: "/company-post-job", label: "Post Job", icon: BriefcaseBusiness },
  { href: "/company-applications", label: "Applications", icon: FileText },
  { href: "/company-submissions", label: "Submissions", icon: ShieldCheck },
];

export default function Sidebar({ mode = "student" }: { mode?: "student" | "company" }) {
  const [location] = useLocation();
  const links = mode === "student" ? STUDENT_LINKS : COMPANY_LINKS;
  const logoutHref = mode === "company" ? "/login/company" : "/login/student";

  const handleLogout = async () => {
    await supabase.auth.signOut();
    localStorage.removeItem("skillhire_role");
  };

  return (
    <aside className="w-64 border-r border-border bg-card flex flex-col h-[calc(100vh-4rem)] md:h-screen sticky top-0 md:top-0">
      <div className="p-6 hidden md:block">
        <Link href="/" className="flex items-center gap-2 font-bold text-xl tracking-tight text-primary">
          <Briefcase className="w-6 h-6" />
          <span>SkillHire<span className="text-foreground">AI</span></span>
        </Link>
      </div>
      
      <div className="px-4 py-2">
        <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-4 px-2">
          {mode === "student" ? "Student Portal" : "Company Portal"}
        </div>
        <nav className="flex flex-col gap-1">
          {links.map((link) => {
            const Icon = link.icon;
            const isActive = location === link.href;
            return (
              <Link key={link.href} href={link.href}>
                <span
                  data-testid={`sidebar-link-${link.label.toLowerCase().replace(/\s+/g, "-")}`}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors cursor-pointer",
                    isActive 
                      ? "bg-primary/10 text-primary" 
                      : "text-muted-foreground hover:text-foreground hover:bg-secondary"
                  )}
                >
                  <Icon className="w-4 h-4" />
                  {link.label}
                </span>
              </Link>
            );
          })}
          
        </nav>
      </div>
      
      <div className="mt-auto p-4">
        <Link href={logoutHref}>
          <span onClick={handleLogout} className="flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium text-muted-foreground hover:text-destructive hover:bg-destructive/10 cursor-pointer">
            <LogOut className="w-4 h-4" />
            Logout
          </span>
        </Link>
      </div>
    </aside>
  );
}
