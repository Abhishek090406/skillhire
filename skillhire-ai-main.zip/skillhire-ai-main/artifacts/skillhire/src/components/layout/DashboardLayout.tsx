import { ReactNode } from "react";
import Sidebar from "./Sidebar";
import Navbar from "./Navbar";

interface DashboardLayoutProps {
  children: ReactNode;
  mode?: "student" | "company";
}

export default function DashboardLayout({ children, mode = "student" }: DashboardLayoutProps) {
  return (
    <div className="min-h-screen bg-background flex flex-col md:flex-row">
      <div className="hidden md:block">
        <Sidebar mode={mode} />
      </div>
      <div className="flex-1 flex flex-col min-w-0">
        <div className="md:hidden">
          <Navbar />
        </div>
        <main className="flex-1 p-4 md:p-8 overflow-y-auto">
          <div className="max-w-6xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
