import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ChevronRight } from "lucide-react";

export default function Navbar() {
  const [, setLocation] = useLocation();

  const openStudentArea = (path: string) => {
    const role = localStorage.getItem("skillhire_role");
    const email = localStorage.getItem("skillhire_auth_email");
    const isSignedInStudent = role === "student" && typeof email === "string" && email.trim().length > 0;
    setLocation(isSignedInStudent ? path : "/login/student");
  };

  return (
    <nav className="border-b border-border bg-background sticky top-0 z-50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 font-bold text-xl tracking-tight text-primary">
          <span>SkillHire<span className="text-foreground">AI</span></span>
        </Link>
        <div className="hidden md:flex items-center gap-6 text-sm font-medium text-muted-foreground">
          <button
            type="button"
            className="hover:text-foreground transition-colors"
            onClick={() => openStudentArea("/projects")}
          >
            Projects
          </button>
          <button
            type="button"
            className="hover:text-foreground transition-colors"
            onClick={() => openStudentArea("/jobs")}
          >
            Jobs
          </button>
          <button
            type="button"
            className="hover:text-foreground transition-colors"
            onClick={() => openStudentArea("/mentors")}
          >
            Mentors
          </button>
        </div>
        <div className="flex items-center gap-4">
          <Link href="/login/company">
            <Button variant="ghost" className="hidden sm:flex" data-testid="nav-hire-talent">
              Hire Talent
            </Button>
          </Link>
          <Link href="/login/student">
            <Button data-testid="nav-get-started" className="gap-2">
              Get Started <ChevronRight className="w-4 h-4" />
            </Button>
          </Link>
        </div>
      </div>
    </nav>
  );
}
