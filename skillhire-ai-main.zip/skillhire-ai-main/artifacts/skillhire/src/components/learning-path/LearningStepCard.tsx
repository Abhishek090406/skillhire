import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { BookOpen, Code2, Clock, ExternalLink, FileText, Lock, PlayCircle, Video } from "lucide-react";
import { CompletionButton } from "@/components/learning-path/CompletionButton";

const getTypeIcon = (type: string) => {
  switch (type.toLowerCase()) {
    case "course":
      return <BookOpen className="w-5 h-5" />;
    case "project":
      return <Code2 className="w-5 h-5" />;
    case "video":
      return <Video className="w-5 h-5" />;
    default:
      return <BookOpen className="w-5 h-5" />;
  }
};

export function LearningStepCard({
  stepNumber,
  title,
  type,
  estimatedDuration,
  description,
  link,
  status,
  isNext,
  onStartLearning,
  onMarkCompleted,
}: {
  stepNumber: number;
  title: string;
  type: string;
  estimatedDuration: string;
  description: string;
  link: string | null;
  status: "completed" | "in_progress" | "unlocked" | "locked";
  isNext: boolean;
  onStartLearning: () => void;
  onMarkCompleted: () => void;
}) {
  const isCompleted = status === "completed";
  const isLocked = status === "locked";
  const isInProgress = status === "in_progress";

  return (
    <Card
      className={cn(
        "transition-all duration-200 border relative overflow-hidden",
        isCompleted ? "border-primary/40 shadow-[0_0_20px_rgba(16,185,129,0.10)]" : "",
        isNext ? "border-primary/50 ring-1 ring-primary/20" : "border-border hover:border-border/80",
        isLocked ? "opacity-60" : ""
      )}
    >
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/8 via-transparent to-transparent pointer-events-none" />

      <CardContent className="p-5 relative">
        <div className="flex flex-col md:flex-row md:items-start gap-4">
          <div
            className={cn(
              "p-3 rounded-lg flex-shrink-0 self-start",
              isCompleted
                ? "bg-primary/15 text-primary"
                : isLocked
                ? "bg-secondary/40 text-muted-foreground"
                : "bg-secondary text-foreground"
            )}
          >
            {getTypeIcon(type)}
          </div>

          <div className="flex-1 space-y-2">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
              <h3 className="text-xl font-bold tracking-tight">
                {stepNumber}. {title}
              </h3>
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline" className="capitalize text-xs font-medium flex items-center gap-1">
                  <FileText className="w-3 h-3" /> {type}
                </Badge>
                <Badge variant="secondary" className="flex items-center gap-1 text-xs">
                  <Clock className="w-3 h-3" /> {estimatedDuration}
                </Badge>

                {isCompleted ? (
                  <Badge variant="outline" className="border-primary/30 bg-primary/10 text-primary">
                    Completed ✅
                  </Badge>
                ) : isInProgress ? (
                  <Badge variant="outline" className="border-yellow-500/30 bg-yellow-500/10 text-yellow-200">
                    Currently Learning…
                  </Badge>
                ) : isLocked ? (
                  <Badge variant="outline" className="border-border bg-secondary/30 text-muted-foreground flex items-center gap-1">
                    <Lock className="w-3 h-3" /> Locked
                  </Badge>
                ) : (
                  <Badge variant="outline" className="border-primary/20 bg-primary/5 text-foreground">
                    Unlocked
                  </Badge>
                )}
              </div>
            </div>

            <p className="text-muted-foreground">{description}</p>

            <div className="pt-3 flex flex-col sm:flex-row gap-2">
              <Button
                size="sm"
                variant="secondary"
                className="gap-2"
                onClick={onStartLearning}
                disabled={isLocked}
              >
                <PlayCircle className="w-4 h-4" />
                Start Learning
                <ExternalLink className="w-4 h-4" />
              </Button>

              <CompletionButton disabled={isCompleted || isLocked} onClick={onMarkCompleted} />
            </div>

            {!link && !isLocked && (
              <p className="text-xs text-muted-foreground mt-2">
                Resource link not found for this module. Add a keyword like “Node.js”, “SQL”, “API”, “JavaScript”.
              </p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

