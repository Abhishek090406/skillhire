import { Button } from "@/components/ui/button";
import { CheckCircle2 } from "lucide-react";

export function CompletionButton({
  disabled,
  onClick,
}: {
  disabled: boolean;
  onClick: () => void;
}) {
  return (
    <Button
      size="sm"
      className="gap-2"
      variant={disabled ? "secondary" : "default"}
      disabled={disabled}
      onClick={onClick}
    >
      <CheckCircle2 className="w-4 h-4" />
      {disabled ? "Completed" : "Mark as Completed"}
    </Button>
  );
}

