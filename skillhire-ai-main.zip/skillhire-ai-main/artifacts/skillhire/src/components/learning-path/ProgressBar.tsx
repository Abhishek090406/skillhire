import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

export function ProgressBar({
  progressPercent,
  completedSteps,
  totalSteps,
}: {
  progressPercent: number;
  completedSteps: number;
  totalSteps: number;
}) {
  return (
    <Card className="bg-secondary/20 border-border">
      <CardContent className="p-6 flex flex-col md:flex-row items-center gap-6 justify-between">
        <div className="flex-1 w-full">
          <div className="flex justify-between items-end mb-2">
            <span className="font-semibold">Path Progress</span>
            <span className="text-2xl font-bold text-primary">{progressPercent}%</span>
          </div>
          <Progress value={progressPercent} className="h-2" />
          <p className="text-sm text-muted-foreground mt-2">
            {completedSteps} of {totalSteps} steps completed
          </p>
        </div>
      </CardContent>
    </Card>
  );
}

