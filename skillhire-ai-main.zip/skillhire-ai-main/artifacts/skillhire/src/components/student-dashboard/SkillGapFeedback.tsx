import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, FileText } from "lucide-react";
import { Link } from "wouter";

export function SkillGapFeedback({
  role,
  missingSkills,
  updatedAt,
}: {
  role: string | null;
  missingSkills: string[];
  updatedAt?: number;
}) {
  if (!role) return null;
  const updatedLabel =
    typeof updatedAt === "number" ? new Date(updatedAt).toLocaleString() : "Just now";

  return (
    <Card className="border-border bg-card/60">
      <CardContent className="py-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <FileText className="w-4 h-4 text-primary" />
            <span>
              Role: <span className="text-foreground font-medium">{role}</span>
            </span>
          </div>
          <div className="flex flex-wrap gap-2">
            {missingSkills.slice(0, 4).map((s) => (
              <Badge key={s} variant="outline" className="border-primary/20 bg-primary/5">
                {s}
              </Badge>
            ))}
            {missingSkills.length === 0 && (
              <Badge variant="secondary">No missing skills</Badge>
            )}
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Clock className="w-3.5 h-3.5" />
            Updated: {updatedLabel}
          </div>
        </div>
        <Link href="/skill-gap">
          <Button variant="secondary" className="gap-2" data-testid="btn-view-skill-gap">
            View Full Report
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}

