import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, Briefcase, AlertTriangle } from "lucide-react";

export function JobMatchCard({
  role,
  company,
  matchPercent,
  missingSkill,
  onApply,
}: {
  role: string;
  company: string;
  matchPercent: number;
  missingSkill?: string;
  onApply?: () => void;
}) {
  const matchClass =
    matchPercent >= 80
      ? "border-primary/30 bg-primary/10 text-primary"
      : matchPercent >= 65
      ? "border-yellow-500/30 bg-yellow-500/10 text-yellow-200"
      : "border-border bg-secondary/30 text-muted-foreground";

  return (
    <Card className="hover:border-primary/40 transition-colors">
      <CardContent className="p-4 space-y-3">
        <div className="flex items-start justify-between gap-3">
          <div className="space-y-1">
            <div className="font-semibold flex items-center gap-2">
              <Briefcase className="w-4 h-4 text-primary" />
              {role}
            </div>
            <div className="text-xs text-muted-foreground">{company}</div>
          </div>
          <Badge variant="outline" className={matchClass}>
            Match: {matchPercent}%
          </Badge>
        </div>

        {missingSkill && (
          <div className="text-sm text-muted-foreground flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-yellow-300" />
            Missing: <span className="text-foreground">{missingSkill}</span>
          </div>
        )}

        <Button size="sm" className="w-full gap-2" onClick={onApply}>
          Apply Now <ArrowRight className="w-4 h-4" />
        </Button>
      </CardContent>
    </Card>
  );
}

