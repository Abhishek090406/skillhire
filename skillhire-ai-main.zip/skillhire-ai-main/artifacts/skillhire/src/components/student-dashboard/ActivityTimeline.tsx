import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, FileText, Briefcase, Zap } from "lucide-react";

export type ActivityItem = {
  id: string;
  label: string;
  timestampLabel: string;
  tone: "success" | "info" | "warning";
  kind: "learning" | "analysis" | "application" | "profile";
};

const iconFor = (kind: ActivityItem["kind"]) => {
  switch (kind) {
    case "learning":
      return <CheckCircle2 className="w-4 h-4 text-primary" />;
    case "analysis":
      return <FileText className="w-4 h-4 text-primary" />;
    case "application":
      return <Briefcase className="w-4 h-4 text-primary" />;
    case "profile":
      return <Zap className="w-4 h-4 text-primary" />;
  }
};

export function ActivityTimeline({ items }: { items: ActivityItem[] }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Activity</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {items.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            No activity yet. Start with a skill gap analysis to generate your plan.
          </p>
        ) : (
          items.map((item) => (
            <div key={item.id} className="flex items-start gap-3 rounded-lg border border-border p-3 bg-secondary/10">
              <div className="mt-0.5">{iconFor(item.kind)}</div>
              <div className="flex-1">
                <div className="text-sm font-medium">{item.label}</div>
                <div className="text-xs text-muted-foreground mt-1">{item.timestampLabel}</div>
              </div>
              <Badge
                variant="outline"
                className={
                  item.tone === "success"
                    ? "border-primary/30 bg-primary/10 text-primary"
                    : item.tone === "warning"
                    ? "border-yellow-500/30 bg-yellow-500/10 text-yellow-200"
                    : "border-border bg-secondary/30 text-muted-foreground"
                }
              >
                {item.tone === "success" ? "Completed" : item.tone === "warning" ? "In progress" : "Update"}
              </Badge>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}

