import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, Building2, Sparkle } from "lucide-react";

export function ProjectCard({
  title,
  company,
  context,
  skillsGained,
  boostPercent,
  onStart,
}: {
  title: string;
  company: string;
  context: string;
  skillsGained: string[];
  boostPercent: number;
  onStart?: () => void;
}) {
  return (
    <Card className="hover:border-primary/40 transition-colors">
      <CardContent className="p-4 space-y-3">
        <div className="flex items-start justify-between gap-3">
          <div className="space-y-1">
            <div className="font-semibold">{title}</div>
            <div className="text-xs text-muted-foreground flex items-center gap-1">
              <Building2 className="w-3.5 h-3.5" /> {company} • {context}
            </div>
          </div>
          <Badge variant="outline" className="border-primary/30 bg-primary/10 text-primary">
            <Sparkle className="w-3.5 h-3.5 mr-1" /> +{boostPercent}%
          </Badge>
        </div>

        <div className="flex flex-wrap gap-2">
          {skillsGained.slice(0, 4).map((s) => (
            <Badge key={s} variant="secondary" className="bg-secondary/40">
              {s}
            </Badge>
          ))}
        </div>

        <Button size="sm" variant="secondary" className="w-full gap-2" onClick={onStart}>
          Start Project <ArrowRight className="w-4 h-4" />
        </Button>
      </CardContent>
    </Card>
  );
}

