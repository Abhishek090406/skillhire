import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight } from "lucide-react";

export function SkillCard({
  skill,
  priority,
  reason,
  onStart,
}: {
  skill: string;
  priority: "High" | "Medium" | "Low";
  reason: string;
  onStart?: () => void;
}) {
  const badgeClass =
    priority === "High"
      ? "border-primary/30 text-primary bg-primary/10"
      : priority === "Medium"
      ? "border-yellow-500/30 text-yellow-200 bg-yellow-500/10"
      : "border-border text-muted-foreground bg-secondary/30";

  return (
    <Card className="group hover:border-primary/40 transition-colors">
      <CardContent className="p-4 space-y-3">
        <div className="flex items-start justify-between gap-3">
          <div className="font-semibold">{skill}</div>
          <Badge variant="outline" className={badgeClass}>
            {priority} demand
          </Badge>
        </div>
        <p className="text-sm text-muted-foreground leading-relaxed">{reason}</p>
        <Button
          size="sm"
          className="w-full gap-2 group-hover:shadow-[0_0_18px_rgba(16,185,129,0.20)]"
          onClick={onStart}
        >
          Start Learning <ArrowRight className="w-4 h-4" />
        </Button>
      </CardContent>
    </Card>
  );
}

