import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowRight, Sparkles } from "lucide-react";
import { Link } from "wouter";

export function NextActionCard({
  title,
  message,
  ctaLabel,
  ctaHref,
}: {
  title: string;
  message: string;
  ctaLabel: string;
  ctaHref: string;
}) {
  return (
    <Card className="border-primary/30 bg-gradient-to-br from-primary/15 via-card to-card shadow-[0_0_40px_rgba(16,185,129,0.12)]">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-primary" />
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <p className="text-sm text-muted-foreground leading-relaxed">{message}</p>
        <Link href={ctaHref}>
          <Button className="gap-2 shadow-[0_0_20px_rgba(16,185,129,0.25)]" data-testid="nba-cta">
            {ctaLabel} <ArrowRight className="w-4 h-4" />
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}

