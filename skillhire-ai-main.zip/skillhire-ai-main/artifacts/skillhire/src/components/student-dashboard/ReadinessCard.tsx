import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { AlertTriangle, CheckCircle2 } from "lucide-react";

export function ReadinessCard({
  score,
  missingSkills,
  suggestions,
}: {
  score: number;
  missingSkills: { name: string; priority: "Critical" | "High" | "Medium" }[];
  suggestions: string[];
}) {
  const clamped = Math.max(0, Math.min(100, score));
  return (
    <Card className="relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-transparent to-transparent pointer-events-none" />
      <CardHeader className="pb-2 relative">
        <CardTitle>Career Readiness</CardTitle>
        <CardDescription>What’s blocking your next interview</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4 relative">
        <div className="flex items-end justify-between">
          <div>
            <div className="text-4xl font-bold text-primary">{clamped}</div>
            <div className="text-xs text-muted-foreground uppercase tracking-wider">/ 100</div>
          </div>
          <div className="text-sm text-muted-foreground">Target: 80+</div>
        </div>
        <Progress value={clamped} className="h-2" />

        <div className="space-y-2">
          <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Missing Skills
          </div>
          <div className="flex flex-wrap gap-2">
            {missingSkills.length === 0 ? (
              <Badge variant="secondary" className="gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-primary" /> No major gaps detected
              </Badge>
            ) : (
              missingSkills.map((skill) => (
                <Badge
                  key={skill.name}
                  variant="outline"
                  className={
                    skill.priority === "Critical"
                      ? "border-destructive/40 text-destructive bg-destructive/10"
                      : skill.priority === "High"
                      ? "border-primary/30 text-primary bg-primary/10"
                      : "border-yellow-500/30 text-yellow-200 bg-yellow-500/10"
                  }
                >
                  {skill.name} • {skill.priority}
                </Badge>
              ))
            )}
          </div>
        </div>

        <div className="space-y-2">
          <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Suggestions
          </div>
          <div className="space-y-1 text-sm text-muted-foreground">
            {suggestions.slice(0, 3).map((text) => (
              <div key={text} className="flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-primary mt-0.5" />
                <span>{text}</span>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

