import { Badge } from "@/components/ui/badge";
import type { ApplicationStatus } from "@/lib/hiring-workflow";
import { statusTone } from "@/lib/hiring-workflow";

export function StatusBadge({ status }: { status: ApplicationStatus }) {
  const tone = statusTone(status);
  const cls =
    tone === "success"
      ? "bg-emerald-500/15 text-emerald-300 border-emerald-500/25"
      : tone === "danger"
      ? "bg-destructive/15 text-destructive border-destructive/25"
      : tone === "warning"
      ? "bg-yellow-500/15 text-yellow-200 border-yellow-500/25"
      : "bg-secondary/30 text-muted-foreground border-border";

  return (
    <Badge variant="outline" className={cls}>
      {status}
    </Badge>
  );
}

