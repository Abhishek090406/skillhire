import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Building2, MapPin, DollarSign, Users, Briefcase, CheckCircle2, AlertTriangle, ArrowRight } from "lucide-react";
import { Link } from "wouter";
import { StatusBadge } from "@/components/jobs-workflow/StatusBadge";
import type { ApplicationStatus } from "@/lib/hiring-workflow";

export type MarketplaceJob = {
  id: number;
  title: string;
  companyName: string;
  description: string;
  requiredSkills: string[];
  location: string;
  remote: boolean;
  stipend?: string;
  type: string;
  applicants: number;
  status?: string;
};

export function JobCard({
  job,
  matchPercent,
  whyMatch,
  missingSkills,
  verifiedSkills,
  applicationStatus,
  onApply,
}: {
  job: MarketplaceJob;
  matchPercent: number;
  whyMatch: string[];
  missingSkills: string[];
  verifiedSkills: string[];
  applicationStatus: ApplicationStatus | null;
  onApply: () => void;
}) {
  const showImprove = matchPercent < 70;

  return (
    <Card className="flex flex-col overflow-hidden hover:border-primary/50 transition-all duration-200">
      <CardHeader className="pb-4">
        <div className="flex justify-between items-start gap-3">
          <div className="space-y-1">
            <CardTitle className="text-xl">{job.title}</CardTitle>
            <div className="flex items-center text-sm text-muted-foreground gap-1">
              <Building2 className="w-4 h-4" /> {job.companyName}
            </div>
          </div>
          <div className="flex flex-col items-end gap-2">
            <Badge variant="secondary" className="uppercase text-[10px] tracking-wider font-bold">
              {job.type}
            </Badge>
            <Badge variant="outline" className="text-primary border-primary bg-primary/5">
              {matchPercent}% Match
            </Badge>
            {applicationStatus ? <StatusBadge status={applicationStatus} /> : null}
          </div>
        </div>
      </CardHeader>

      <CardContent className="flex-1 space-y-4">
        <p className="text-sm text-muted-foreground line-clamp-3">{job.description}</p>

        <div className="rounded-lg border border-border bg-secondary/10 p-3 space-y-2">
          <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Proof required</div>
          <div className="text-sm text-muted-foreground space-y-1">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-primary" />
              Submit GitHub project link
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-primary" />
              Complete at least one verified project
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-primary" />
              Keep your portfolio updated
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <div className="text-sm font-semibold">Why you match</div>
          <ul className="space-y-1 text-sm text-muted-foreground">
            {verifiedSkills.slice(0, 2).map((s) => (
              <li key={`verified-${job.id}-${s}`} className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-primary" />
                {s}
              </li>
            ))}
            {missingSkills[0] ? (
              <li className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-yellow-300" />
                Missing: <span className="text-foreground font-medium">{missingSkills[0]}</span>
              </li>
            ) : null}
          </ul>
          {whyMatch.length ? <div className="text-xs text-muted-foreground">{whyMatch.join(" ")}</div> : null}
        </div>

        <div className="flex flex-wrap gap-2">
          {job.requiredSkills.map((skill) => (
            <Badge key={skill} variant="outline" className="text-xs bg-background">
              {skill}
            </Badge>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-3 py-3 border-y border-border/50 text-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <MapPin className="w-4 h-4 text-foreground" /> {job.remote ? "Remote" : job.location}
          </div>
          {job.stipend ? (
            <div className="flex items-center gap-2 text-muted-foreground">
              <DollarSign className="w-4 h-4 text-foreground" /> {job.stipend}
            </div>
          ) : (
            <div />
          )}
          <div className="flex items-center gap-2 text-muted-foreground">
            <Briefcase className="w-4 h-4 text-foreground" /> {job.type}
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Users className="w-4 h-4 text-foreground" /> {job.applicants} Applied
          </div>
        </div>

        {showImprove ? (
          <div className="flex items-center justify-between gap-3 rounded-lg border border-border bg-secondary/10 p-3">
            <div className="text-sm">
              <div className="font-semibold">Improve your match</div>
              <div className="text-xs text-muted-foreground">
                Increase your score by learning: {missingSkills.slice(0, 2).join(", ") || "missing skills"}.
              </div>
            </div>
            <Link href="/learning-path">
              <Button variant="outline" className="border-primary/30">
                Learning Path <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        ) : null}
      </CardContent>

      <CardFooter className="pt-4 bg-secondary/10">
        <Button className="w-full" onClick={onApply} disabled={Boolean(applicationStatus)}>
          {applicationStatus ? "Applied" : "Apply Now"}
        </Button>
      </CardFooter>
    </Card>
  );
}

