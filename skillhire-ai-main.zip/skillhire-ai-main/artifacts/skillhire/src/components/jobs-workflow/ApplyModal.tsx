import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export function ApplyModal({
  open,
  onOpenChange,
  jobTitle,
  onSubmit,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  jobTitle: string;
  onSubmit: (value: { githubLink: string; portfolioLink?: string }) => void;
}) {
  const [githubLink, setGithubLink] = useState("");
  const [portfolioLink, setPortfolioLink] = useState("");

  useEffect(() => {
    if (!open) {
      setGithubLink("");
      setPortfolioLink("");
    }
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="border-primary/20">
        <DialogHeader>
          <DialogTitle>Apply to {jobTitle}</DialogTitle>
          <DialogDescription>
            Proof required. Submit a GitHub project link so companies can verify your work.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label>GitHub Repo Link</Label>
            <Input
              value={githubLink}
              onChange={(e) => setGithubLink(e.target.value)}
              placeholder="https://github.com/username/project"
              className="border-primary/20"
            />
          </div>
          <div className="space-y-2">
            <Label>Portfolio Link (optional)</Label>
            <Input
              value={portfolioLink}
              onChange={(e) => setPortfolioLink(e.target.value)}
              placeholder="https://your-portfolio.com"
              className="border-primary/20"
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" className="border-primary/30" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            className="bg-primary hover:bg-primary/90 text-primary-foreground glow-green"
            onClick={() => onSubmit({ githubLink: githubLink.trim(), portfolioLink: portfolioLink.trim() || undefined })}
            disabled={!githubLink.trim()}
          >
            Submit Application
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

