import { useMemo, useState } from "react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Building2, Clock, Award, Users, Target, ExternalLink, CheckCircle2 } from "lucide-react";
import { MatchIndicator } from "@/components/projects-marketplace/MatchIndicator";
import { StatusBadge } from "@/components/projects-marketplace/StatusBadge";
import type { AppliedProjectRecord, ProjectStatus } from "@/lib/project-marketplace";

export type MarketplaceProject = {
  id: number;
  title: string;
  companyName: string;
  description: string;
  difficulty: string;
  requiredSkills: string[];
  duration: string;
  certificate: boolean;
  applicants: number;
  reward?: string;
  status?: string;
};

export function ProjectCard({
  project,
  matchPercent,
  missingSkill,
  whyThisProject,
  boostPercent,
  industry,
  useCase,
  appliedRecord,
  onApply,
  onStatusChange,
  onSubmitRepo,
  onMarkCompleted,
  recommended,
}: {
  project: MarketplaceProject;
  matchPercent: number;
  missingSkill: string | null;
  whyThisProject: string[];
  boostPercent: number;
  industry: string;
  useCase: string;
  appliedRecord: AppliedProjectRecord | null;
  onApply: () => void;
  onStatusChange: (status: ProjectStatus) => void;
  onSubmitRepo: (url: string) => void;
  onMarkCompleted: () => void;
  recommended?: boolean;
}) {
  const [repoUrl, setRepoUrl] = useState(appliedRecord?.githubRepoUrl ?? "");

  const status = appliedRecord?.status ?? null;
  const isApplied = Boolean(appliedRecord);

  const footerPrimaryLabel = useMemo(() => {
    if (!isApplied) return "Apply Now";
    if (status === "Completed") return "✔ Applied";
    if (status === "In Progress") return "Continue Project";
    return "Start Project";
  }, [isApplied, status]);

  return (
    <Card
      className={[
        "flex flex-col overflow-hidden hover:border-primary/50 transition-all duration-200",
        recommended ? "border-primary/30 shadow-[0_0_40px_rgba(16,185,129,0.12)]" : "",
      ].join(" ")}
    >
      <CardHeader className="pb-4">
        <div className="flex justify-between items-start gap-3">
          <div className="space-y-1">
            <CardTitle className="text-xl">{project.title}</CardTitle>
            <div className="flex flex-wrap items-center text-sm text-muted-foreground gap-2">
              <span className="flex items-center gap-1">
                <Building2 className="w-4 h-4" /> {project.companyName}
              </span>
              <Badge variant="outline" className="bg-secondary/20 text-muted-foreground">
                {industry}
              </Badge>
            </div>
          </div>
          <div className="flex flex-col items-end gap-2">
            <Badge variant="secondary" className="uppercase text-[10px] tracking-wider font-bold">
              {project.difficulty}
            </Badge>
            {status ? <StatusBadge status={status} /> : null}
          </div>
        </div>
      </CardHeader>

      <CardContent className="flex-1 space-y-4">
        <MatchIndicator matchPercent={matchPercent} missingSkill={missingSkill} />

        <p className="text-sm text-muted-foreground line-clamp-3">{project.description}</p>

        <div className="text-xs text-muted-foreground">
          <span className="text-primary font-semibold">Real-world context:</span> {useCase}
        </div>

        <div className="flex flex-wrap gap-2">
          {project.requiredSkills.map((skill) => (
            <Badge key={skill} variant="outline" className="text-xs bg-background">
              {skill}
            </Badge>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-3 py-3 border-y border-border/50 text-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Clock className="w-4 h-4 text-foreground" /> {project.duration}
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Award className="w-4 h-4 text-foreground" />
            {project.certificate ? "Certificate" : "Experience"}
          </div>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Users className="w-4 h-4 text-foreground" /> {project.applicants} Applicants
          </div>
          <div className="flex items-center gap-2 font-medium text-primary">
            <Target className="w-4 h-4" />
            Boosts Readiness: +{boostPercent}%
          </div>
        </div>

        <div className="space-y-2">
          <div className="text-sm font-semibold">Why this project?</div>
          <ul className="space-y-1 text-sm text-muted-foreground">
            {whyThisProject.map((r, idx) => (
              <li key={`${project.id}-why-${idx}`} className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 mt-0.5 text-primary" />
                <span>{r}</span>
              </li>
            ))}
          </ul>
        </div>

        {isApplied ? (
          <div className="space-y-2">
            <div className="text-sm font-semibold">Progress</div>
            <div className="flex flex-wrap gap-2">
              <Button
                size="sm"
                variant={status === "Not Started" ? "secondary" : "outline"}
                className={status === "Not Started" ? "bg-secondary/40" : "border-primary/25"}
                onClick={() => onStatusChange("Not Started")}
              >
                Not Started
              </Button>
              <Button
                size="sm"
                variant={status === "In Progress" ? "secondary" : "outline"}
                className={status === "In Progress" ? "bg-yellow-500/15 text-yellow-200" : "border-primary/25"}
                onClick={() => onStatusChange("In Progress")}
              >
                In Progress
              </Button>
              <Button
                size="sm"
                variant={status === "Completed" ? "secondary" : "outline"}
                className={status === "Completed" ? "bg-emerald-500/15 text-emerald-300" : "border-primary/25"}
                onClick={() => onStatusChange("Completed")}
              >
                Completed
              </Button>
            </div>

            <div className="flex flex-col sm:flex-row gap-2">
              <Input
                value={repoUrl}
                onChange={(e) => setRepoUrl(e.target.value)}
                placeholder="GitHub repo URL (optional)"
                className="border-primary/20"
              />
              <Button
                variant="outline"
                className="border-primary/30"
                onClick={() => onSubmitRepo(repoUrl)}
                disabled={!repoUrl.trim()}
              >
                Submit Repo <ExternalLink className="w-4 h-4 ml-2" />
              </Button>
            </div>

            <Button
              variant="secondary"
              className="w-full bg-primary/10 text-primary hover:bg-primary/15 border border-primary/25"
              onClick={onMarkCompleted}
              disabled={status === "Completed"}
            >
              Mark Completed (+{boostPercent}% readiness)
            </Button>
          </div>
        ) : null}
      </CardContent>

      <CardFooter className="pt-4 bg-secondary/10">
        <Button className="w-full" onClick={onApply} disabled={isApplied}>
          {footerPrimaryLabel}
        </Button>
      </CardFooter>
    </Card>
  );
}

