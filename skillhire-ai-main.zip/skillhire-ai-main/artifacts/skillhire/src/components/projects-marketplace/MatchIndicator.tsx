import { Badge } from "@/components/ui/badge";
import { Zap } from "lucide-react";

export function MatchIndicator({ matchPercent, missingSkill }: { matchPercent: number; missingSkill: string | null }) {
  const tone =
    matchPercent >= 80
      ? "border-primary/30 text-primary bg-primary/10"
      : matchPercent >= 60
      ? "border-yellow-500/25 text-yellow-200 bg-yellow-500/10"
      : "border-destructive/25 text-destructive bg-destructive/10";

  return (
    <div className="flex flex-wrap items-center gap-2">
      <Badge variant="outline" className={tone}>
        <Zap className="w-3.5 h-3.5 mr-1" />
        Match: {matchPercent}%
      </Badge>
      {missingSkill ? (
        <Badge variant="outline" className="bg-secondary/30 text-muted-foreground">
          Missing: <span className="ml-1 text-foreground font-medium">{missingSkill}</span>
        </Badge>
      ) : (
        <Badge variant="outline" className="border-emerald-500/25 text-emerald-300 bg-emerald-500/10">
          No missing skills detected
        </Badge>
      )}
    </div>
  );
}

