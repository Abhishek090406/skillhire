import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export function ProjectSubmissionModal({
  open,
  onOpenChange,
  onSubmit,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (value: { projectTitle: string; githubLink: string; skillTag: string }) => void;
}) {
  const [projectTitle, setProjectTitle] = useState("");
  const [githubLink, setGithubLink] = useState("");
  const [skillTag, setSkillTag] = useState("");

  useEffect(() => {
    if (!open) {
      setProjectTitle("");
      setGithubLink("");
      setSkillTag("");
    }
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="border-primary/20">
        <DialogHeader>
          <DialogTitle>Submit Project for Verification</DialogTitle>
          <DialogDescription>
            Add proof so your skills can be verified by admin review.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Project title</Label>
            <Input value={projectTitle} onChange={(e) => setProjectTitle(e.target.value)} placeholder="e.g. Express Auth API" />
          </div>
          <div className="space-y-2">
            <Label>GitHub link</Label>
            <Input value={githubLink} onChange={(e) => setGithubLink(e.target.value)} placeholder="https://github.com/you/repo" />
          </div>
          <div className="space-y-2">
            <Label>Skill tag</Label>
            <Input value={skillTag} onChange={(e) => setSkillTag(e.target.value)} placeholder='e.g. "node.js" or "react"' />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" className="border-primary/30" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            className="bg-primary hover:bg-primary/90 text-primary-foreground glow-green"
            disabled={!projectTitle.trim() || !githubLink.trim() || !skillTag.trim()}
            onClick={() => onSubmit({ projectTitle: projectTitle.trim(), githubLink: githubLink.trim(), skillTag: skillTag.trim() })}
          >
            Submit
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

