import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { CheckCircle2 } from "lucide-react";

export function ApplySuccessModal({
  open,
  onOpenChange,
  onGoToMyProjects,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onGoToMyProjects: () => void;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="border-primary/20">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-primary" />
            Project Applied Successfully!
          </DialogTitle>
          <DialogDescription>Your next steps are clear — this is how you get verified.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3 text-sm">
          <div className="flex gap-2">
            <span className="text-primary font-semibold">1.</span>
            <span>Complete the project requirements</span>
          </div>
          <div className="flex gap-2">
            <span className="text-primary font-semibold">2.</span>
            <span>Submit your GitHub repo link</span>
          </div>
          <div className="flex gap-2">
            <span className="text-primary font-semibold">3.</span>
            <span>Get verified and boost your readiness score</span>
          </div>
        </div>
        <div className="flex gap-2 justify-end pt-2">
          <Button variant="outline" className="border-primary/30" onClick={() => onOpenChange(false)}>
            Close
          </Button>
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground glow-green" onClick={onGoToMyProjects}>
            Go to My Projects
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

