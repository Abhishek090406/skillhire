import { Badge } from "@/components/ui/badge";

export function StatusBadge({ status }: { status: "Not Started" | "In Progress" | "Completed" }) {
  const cls =
    status === "Completed"
      ? "bg-emerald-500/15 text-emerald-300 border-emerald-500/25"
      : status === "In Progress"
      ? "bg-yellow-500/15 text-yellow-200 border-yellow-500/25"
      : "bg-secondary/30 text-muted-foreground border-border";

  const label = status === "Completed" ? "🟢 Completed" : status === "In Progress" ? "🟡 In Progress" : "⚪ Not Started";

  return (
    <Badge variant="outline" className={cls}>
      {label}
    </Badge>
  );
}

