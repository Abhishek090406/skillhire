import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import type { RankedCandidate } from "@/lib/top-candidates";
import { UserPlus } from "lucide-react";
import { cn } from "@/lib/utils";

function rankBorderClass(rank: number) {
  if (rank === 1) return "border-amber-400/70 ring-1 ring-amber-400/25";
  if (rank === 2) return "border-slate-400/80 ring-1 ring-slate-400/20";
  if (rank === 3) return "border-amber-800/55 ring-1 ring-amber-900/25";
  return "border-border";
}

function medalForRank(rank: number) {
  if (rank === 1) return "🥇";
  if (rank === 2) return "🥈";
  if (rank === 3) return "🥉";
  return null;
}

export function TopCandidatesSection({
  candidates,
  loading,
  onShortlist,
}: {
  candidates: RankedCandidate[];
  loading: boolean;
  onShortlist: (c: RankedCandidate) => void;
}) {
  return (
    <Card className="border-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-xl">
          <span aria-hidden>🔥</span> Top candidates
        </CardTitle>
        <CardDescription>
          Ranked from live readiness, verified skills, and GitHub project scores (updates when applications and submissions change).
        </CardDescription>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-40 w-full rounded-lg" />
            ))}
          </div>
        ) : candidates.length === 0 ? (
          <p className="text-sm text-muted-foreground py-6 text-center">No candidates available yet</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {candidates.map((c) => {
              const medal = medalForRank(c.displayRank);
              return (
                <div
                  key={c.studentKey}
                  className={cn(
                    "rounded-xl border bg-secondary/10 p-4 flex flex-col gap-3 transition-shadow",
                    rankBorderClass(c.displayRank)
                  )}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="font-semibold text-lg flex items-center gap-2 flex-wrap">
                        {medal ? <span aria-hidden>{medal}</span> : null}
                        <span>{c.name}</span>
                      </div>
                      <p className="text-sm text-muted-foreground mt-0.5">{c.role}</p>
                    </div>
                    <Badge variant={c.displayRank <= 3 ? "default" : "secondary"} className="shrink-0">
                      Top {c.displayRank}
                    </Badge>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-center text-xs">
                    <div className="rounded-md bg-background/50 py-2 px-1 border border-border/60">
                      <div className="text-muted-foreground">Readiness</div>
                      <div className="font-semibold text-primary text-sm">{Math.round(c.readiness_score)}%</div>
                    </div>
                    <div className="rounded-md bg-background/50 py-2 px-1 border border-border/60">
                      <div className="text-muted-foreground">Verified</div>
                      <div className="font-semibold text-sm">{c.verifiedSkillsCount}</div>
                    </div>
                    <div className="rounded-md bg-background/50 py-2 px-1 border border-border/60">
                      <div className="text-muted-foreground">Avg project</div>
                      <div className="font-semibold text-sm">{c.avgProjectScore}/100</div>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2 mt-auto pt-1">
                    <Button variant="outline" size="sm" className="flex-1 min-w-[120px]" asChild>
                      <Link href={`/company-talent-pool?q=${encodeURIComponent(c.name)}`}>View profile</Link>
                    </Button>
                    <Button
                      size="sm"
                      variant="secondary"
                      className="flex-1 min-w-[120px] gap-1"
                      onClick={() => onShortlist(c)}
                    >
                      <UserPlus className="w-3.5 h-3.5" />
                      Shortlist
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
