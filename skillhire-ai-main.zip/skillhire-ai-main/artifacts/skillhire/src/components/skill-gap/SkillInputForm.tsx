import { useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sparkles } from "lucide-react";

export function SkillInputForm({
  currentSkillsText,
  onChangeCurrentSkillsText,
  targetRole,
  onChangeTargetRole,
  onRun,
  disabled,
}: {
  currentSkillsText: string;
  onChangeCurrentSkillsText: (next: string) => void;
  targetRole: string;
  onChangeTargetRole: (next: string) => void;
  onRun: () => void;
  disabled?: boolean;
}) {
  const helper = useMemo(() => {
    const count = currentSkillsText
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean).length;
    return count > 0 ? `${count} skills detected` : "Example: React, JavaScript, HTML, CSS";
  }, [currentSkillsText]);

  return (
    <Card className="border-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-primary" />
          AI Skill Gap Analysis
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>Target Role</Label>
          <Select value={targetRole} onValueChange={onChangeTargetRole} disabled={disabled}>
            <SelectTrigger className="border-primary/20">
              <SelectValue placeholder="Select a target role" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="frontend">Frontend Developer</SelectItem>
              <SelectItem value="backend">Backend Developer</SelectItem>
              <SelectItem value="fullstack">Full Stack Developer</SelectItem>
              <SelectItem value="data">Data Analyst</SelectItem>
              <SelectItem value="ml">ML Engineer</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Your Current Skills</Label>
          <Input
            value={currentSkillsText}
            onChange={(e) => onChangeCurrentSkillsText(e.target.value)}
            placeholder="React, JavaScript, HTML, CSS"
            className="border-primary/20"
            disabled={disabled}
          />
          <div className="text-xs text-muted-foreground">{helper}</div>
        </div>

        <Button
          onClick={onRun}
          disabled={disabled}
          className="w-full bg-primary hover:bg-primary/90 text-primary-foreground glow-green"
        >
          Run Analysis
        </Button>
      </CardContent>
    </Card>
  );
}

