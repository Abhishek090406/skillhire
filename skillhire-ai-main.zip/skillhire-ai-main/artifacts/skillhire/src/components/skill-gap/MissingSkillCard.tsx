import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { AlertTriangle } from "lucide-react";

export function MissingSkillCard({
  name,
  priority,
  explanation,
}: {
  name: string;
  priority: "Critical" | "High" | "Medium";
  explanation: string;
}) {
  // Keep colors neutral; green is reserved for score + primary CTA.
  const priorityClass =
    priority === "Critical"
      ? "border-border bg-secondary/20 text-foreground"
      : priority === "High"
      ? "border-border bg-secondary/20 text-foreground"
      : "border-border bg-secondary/20 text-foreground";

  return (
    <Card className="group hover:border-border/70 transition-colors">
      <CardContent className="p-4 space-y-2">
        <div className="flex items-start justify-between gap-2">
          <div className="font-semibold">{name}</div>
          <Badge variant="outline" className={priorityClass}>
            <AlertTriangle className="w-3.5 h-3.5 mr-1" />
            {priority}
          </Badge>
        </div>
        <p className="text-sm text-muted-foreground leading-relaxed line-clamp-1">{explanation}</p>
      </CardContent>
    </Card>
  );
}

