import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowRight, Sparkles } from "lucide-react";

export function SimulationCard({
  currentScore,
  futureScore,
  outcome,
}: {
  currentScore: number;
  futureScore: number;
  outcome: string;
}) {
  return (
    <Card className="border-primary/20 shadow-[0_0_35px_rgba(16,185,129,0.10)]">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-primary" />
          Before vs After (Simulation)
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center justify-center gap-3 text-2xl font-bold">
          <span className="text-muted-foreground">{Math.round(currentScore)}%</span>
          <ArrowRight className="w-6 h-6 text-primary" />
          <span className="text-primary">{Math.round(futureScore)}%</span>
        </div>
        <p className="text-sm text-muted-foreground text-center">{outcome}</p>
      </CardContent>
    </Card>
  );
}

