import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Sparkles } from "lucide-react";

export function AnalysisLoader({ stepLabel }: { stepLabel: string }) {
  return (
    <Card className="border-primary/20 shadow-[0_0_35px_rgba(16,185,129,0.10)]">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-primary" />
          AI Analysis Running
        </CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col items-center justify-center py-12 text-center space-y-4">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
        <div className="text-sm text-muted-foreground">{stepLabel}</div>
        <div className="text-xs text-muted-foreground">
          Generating explainable recommendations and next best actions…
        </div>
      </CardContent>
    </Card>
  );
}

