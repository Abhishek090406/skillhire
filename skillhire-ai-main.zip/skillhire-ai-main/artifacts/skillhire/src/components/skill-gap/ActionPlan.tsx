import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle2, Rocket } from "lucide-react";

export function ActionPlan({
  actions,
  onStartLearningPath,
}: {
  actions: string[];
  onStartLearningPath?: () => void;
}) {
  return (
    <Card className="border-primary/20 shadow-[0_0_35px_rgba(16,185,129,0.10)]">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Rocket className="w-5 h-5 text-primary" />
          What You Should Do Next
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <ol className="space-y-2">
          {actions.map((a, idx) => (
            <li key={`${a}-${idx}`} className="flex items-start gap-2 text-sm">
              <CheckCircle2 className="w-4 h-4 mt-0.5 text-primary" />
              <span>{a}</span>
            </li>
          ))}
        </ol>
        <div className="flex gap-2">
          <Link href="/learning-path">
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground glow-green">
              Start Learning Path
            </Button>
          </Link>
          {onStartLearningPath ? (
            <Button variant="outline" className="border-primary/30" onClick={onStartLearningPath}>
              Sync Roadmap
            </Button>
          ) : null}
        </div>
      </CardContent>
    </Card>
  );
}

