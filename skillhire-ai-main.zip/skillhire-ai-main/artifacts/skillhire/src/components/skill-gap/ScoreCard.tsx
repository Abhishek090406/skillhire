import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { BrainCircuit, Target } from "lucide-react";

export function ScoreCard({
  readinessScore,
  breakdown,
  confidencePercent,
}: {
  readinessScore: number;
  breakdown: { roleSkillsPercent: number; fundamentalsPercent: number; portfolioPercent: number };
  confidencePercent?: number;
}) {
  return (
    <Card className="border-primary/20 shadow-[0_0_35px_rgba(16,185,129,0.10)]">
      <CardHeader>
        <CardTitle className="flex items-center justify-between gap-3">
          <span className="flex items-center gap-2">
            <Target className="w-5 h-5 text-primary" />
            Readiness Score
          </span>
          {typeof confidencePercent === "number" ? (
            <Badge variant="outline" className="border-primary/30 text-primary">
              <BrainCircuit className="w-3.5 h-3.5 mr-1" />
              Confidence: {confidencePercent}%
            </Badge>
          ) : null}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="space-y-2">
          <div className="flex items-end justify-between">
            <div className="text-3xl font-bold text-primary">{Math.round(readinessScore)}%</div>
            <div className="text-xs text-muted-foreground">AI estimate based on benchmarks</div>
          </div>
          <Progress value={Math.round(readinessScore)} className="h-2 transition-all" />
        </div>

        <div className="space-y-3">
          <div className="text-sm font-semibold">Breakdown</div>
          <div className="space-y-3">
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Role Skills</span>
                <span>{breakdown.roleSkillsPercent}%</span>
              </div>
              <Progress value={breakdown.roleSkillsPercent} className="h-2" />
            </div>
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Fundamentals Fit</span>
                <span>{breakdown.fundamentalsPercent}%</span>
              </div>
              <Progress value={breakdown.fundamentalsPercent} className="h-2" />
            </div>
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Portfolio Signal</span>
                <span>{breakdown.portfolioPercent}%</span>
              </div>
              <Progress value={breakdown.portfolioPercent} className="h-2" />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

