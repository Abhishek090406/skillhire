import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Star, Sparkles } from "lucide-react";

export function RecommendedMentor({
  name,
  title,
  company,
  matchPercent,
  reason,
  relevantSkills,
  onBook,
  booked,
  available,
}: {
  name: string;
  title: string;
  company: string;
  matchPercent: number;
  reason: string;
  relevantSkills: string[];
  onBook: () => void;
  booked: boolean;
  available: boolean;
}) {
  return (
    <Card className="border-primary/30 shadow-[0_0_40px_rgba(16,185,129,0.12)]">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between gap-3">
          <span className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            Recommended Mentor
          </span>
          <Badge variant="outline" className="border-primary/30 text-primary bg-primary/5">
            <Star className="w-3.5 h-3.5 mr-1 fill-primary text-primary" />
            {matchPercent}% match
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
        <div className="space-y-2">
          <div className="font-semibold text-lg">{name}</div>
          <div className="text-sm text-muted-foreground">
            {title} • {company}
          </div>
          <div className="text-sm text-muted-foreground">{reason}</div>
          {relevantSkills.length ? (
            <div className="flex flex-wrap gap-2 pt-1">
              {relevantSkills.slice(0, 3).map((s) => (
                <Badge key={s} variant="secondary" className="text-xs">
                  {s}
                </Badge>
              ))}
            </div>
          ) : null}
        </div>
        <Button
          className="bg-primary hover:bg-primary/90 text-primary-foreground glow-green w-full md:w-auto"
          onClick={onBook}
          disabled={!available || booked}
        >
          {booked ? "✔ Session Booked" : available ? "Request Mentor" : "Unavailable"}
        </Button>
      </CardContent>
    </Card>
  );
}

