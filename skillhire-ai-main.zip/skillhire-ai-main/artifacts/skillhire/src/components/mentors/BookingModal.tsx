import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export function BookingModal({
  open,
  onOpenChange,
  mentorName,
  onSubmit,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  mentorName: string;
  onSubmit: (value: {
    sessionType: "Resume Review" | "Mock Interview" | "Project Feedback";
    dateTime: string;
    goal: string;
  }) => void;
}) {
  const [sessionType, setSessionType] = useState<"Resume Review" | "Mock Interview" | "Project Feedback">("Resume Review");
  const [dateTime, setDateTime] = useState("");
  const [goal, setGoal] = useState("");

  useEffect(() => {
    if (!open) {
      setSessionType("Resume Review");
      setDateTime("");
      setGoal("");
    }
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="border-primary/20">
        <DialogHeader>
          <DialogTitle>Book a session with {mentorName}</DialogTitle>
          <DialogDescription>Pick a session type, set a time, and define your goal.</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Session type</Label>
            <Select value={sessionType} onValueChange={(v) => setSessionType(v as any)}>
              <SelectTrigger className="border-primary/20">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Resume Review">Resume Review</SelectItem>
                <SelectItem value="Mock Interview">Mock Interview</SelectItem>
                <SelectItem value="Project Feedback">Project Feedback</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Date/time (mock)</Label>
            <Input
              value={dateTime}
              onChange={(e) => setDateTime(e.target.value)}
              placeholder="e.g. Sat 5:00 PM"
              className="border-primary/20"
            />
          </div>

          <div className="space-y-2">
            <Label>Goal</Label>
            <Textarea
              value={goal}
              onChange={(e) => setGoal(e.target.value)}
              placeholder="e.g. Fix my resume + prep for React interviews"
              className="h-24 border-primary/20"
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" className="border-primary/30" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            className="bg-primary hover:bg-primary/90 text-primary-foreground glow-green"
            disabled={!dateTime.trim() || !goal.trim()}
            onClick={() => onSubmit({ sessionType, dateTime: dateTime.trim(), goal: goal.trim() })}
          >
            Book Session
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

