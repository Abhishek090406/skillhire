import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Star, Building2, UserCircle, CheckCircle2 } from "lucide-react";

export type Mentor = {
  id: number;
  name: string;
  title: string;
  company: string;
  rating: number;
  sessionCount: number;
  expertise: string[];
  bio?: string;
  available: boolean;
  avatarUrl?: string;
};

export function MentorCard({
  mentor,
  matchPercent,
  relevantSkills,
  whyThisMentor,
  benefits,
  impactMetric,
  statusLabel,
  booked,
  onBook,
}: {
  mentor: Mentor;
  matchPercent: number;
  relevantSkills: string[];
  whyThisMentor: string;
  benefits: string[];
  impactMetric: string;
  statusLabel: string;
  booked: boolean;
  onBook: () => void;
}) {
  return (
    <Card className="flex flex-col overflow-hidden hover:border-primary/30 transition-all duration-200">
      <CardHeader className="pb-4 items-center text-center">
        <div className="w-20 h-20 rounded-full border-2 border-border overflow-hidden mb-2 bg-secondary flex items-center justify-center">
          {mentor.avatarUrl ? (
            <img src={mentor.avatarUrl} alt={mentor.name} className="w-full h-full object-cover" />
          ) : (
            <UserCircle className="w-12 h-12 text-muted-foreground" />
          )}
        </div>
        <CardTitle className="text-lg">{mentor.name}</CardTitle>
        <div className="text-sm text-muted-foreground font-medium">{mentor.title}</div>
        <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
          <Building2 className="w-3 h-3" /> {mentor.company}
        </div>
        <div className="flex flex-wrap items-center justify-center gap-2 mt-3">
          <Badge variant="outline" className="border-primary/30 text-primary bg-primary/5">
            <Star className="w-3.5 h-3.5 mr-1 fill-primary text-primary" /> {mentor.rating.toFixed(1)}
          </Badge>
          <Badge variant="secondary" className="text-xs">
            {mentor.sessionCount} sessions
          </Badge>
          <Badge variant="outline" className="text-xs">
            {statusLabel}
          </Badge>
          <Badge variant="outline" className="text-primary border-primary bg-primary/5 text-xs">
            {matchPercent}% match
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="flex-1 space-y-4">
        <div>
          <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2 text-center">
            Relevant skills
          </div>
          <div className="flex flex-wrap justify-center gap-1">
            {(relevantSkills.length ? relevantSkills : mentor.expertise).slice(0, 4).map((skill) => (
              <Badge key={skill} variant="secondary" className="text-[10px]">
                {skill}
              </Badge>
            ))}
          </div>
        </div>

        <div className="text-sm text-muted-foreground text-center">{whyThisMentor}</div>

        <div className="rounded-lg border border-border bg-secondary/10 p-3 space-y-2">
          <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground text-center">Session benefits</div>
          <div className="space-y-1 text-sm text-muted-foreground">
            {benefits.map((b) => (
              <div key={b} className="flex items-center gap-2 justify-center">
                <CheckCircle2 className="w-4 h-4 text-primary" />
                <span>{b}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="text-xs text-muted-foreground text-center">{impactMetric}</div>

        {mentor.bio ? (
          <p className="text-xs text-center text-muted-foreground line-clamp-2">{mentor.bio}</p>
        ) : null}
      </CardContent>

      <CardFooter className="pt-4 bg-secondary/10">
        <Button
          className="w-full gap-2"
          variant={mentor.available ? "default" : "secondary"}
          disabled={!mentor.available || booked}
          onClick={onBook}
        >
          {booked ? "✔ Session Booked" : mentor.available ? "Request Mentor" : "Unavailable"}
        </Button>
      </CardFooter>
    </Card>
  );
}

