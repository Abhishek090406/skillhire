import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db } from "@workspace/db";
import { mentorsTable, mentorRequestsTable } from "@workspace/db";
import {
  ListMentorsResponse,
  RequestMentorParams,
  RequestMentorBody,
  RequestMentorResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/mentors", async (req, res): Promise<void> => {
  const mentors = await db.select().from(mentorsTable).orderBy(mentorsTable.rating);
  res.json(ListMentorsResponse.parse(mentors.map(m => ({
    ...m,
    rating: Number(m.rating),
  }))));
});

router.post("/mentors/:id/request", async (req, res): Promise<void> => {
  const params = RequestMentorParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = RequestMentorBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const [mentor] = await db.select().from(mentorsTable).where(eq(mentorsTable.id, params.data.id));
  if (!mentor) {
    res.status(404).json({ error: "Mentor not found" });
    return;
  }
  const [request] = await db.insert(mentorRequestsTable).values({
    mentorId: params.data.id,
    studentId: body.data.studentId,
    message: body.data.message,
    topic: body.data.topic,
    status: "pending",
  }).returning();
  res.json(RequestMentorResponse.parse({
    ...request,
    createdAt: request.createdAt.toISOString(),
  }));
});

export default router;
