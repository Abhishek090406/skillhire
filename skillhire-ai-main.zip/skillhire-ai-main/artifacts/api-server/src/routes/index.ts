import { Router, type IRouter } from "express";
import healthRouter from "./health";
import studentsRouter from "./students";
import companiesRouter from "./companies";
import projectsRouter from "./projects";
import jobsRouter from "./jobs";
import mentorsRouter from "./mentors";
import skillsRouter from "./skills";
import dashboardRouter from "./dashboard";
import skillgapRouter from "./skillgap";

const router: IRouter = Router();

router.use(healthRouter);
router.use(studentsRouter);
router.use(companiesRouter);
router.use(projectsRouter);
router.use(jobsRouter);
router.use(mentorsRouter);
router.use(skillsRouter);
router.use(dashboardRouter);
router.use(skillgapRouter);

export default router;
