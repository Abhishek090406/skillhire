import { Router, type IRouter } from "express";
import { eq, sql } from "drizzle-orm";
import { db } from "@workspace/db";
import { studentsTable, companiesTable, projectsTable, jobsTable, skillsTable, mentorsTable } from "@workspace/db";
import {
  GetDashboardSummaryResponse,
  GetStudentDashboardParams,
  GetStudentDashboardResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/dashboard/summary", async (req, res): Promise<void> => {
  const [students] = await db.select({ count: sql<number>`count(*)::int` }).from(studentsTable);
  const [companies] = await db.select({ count: sql<number>`count(*)::int` }).from(companiesTable);
  const [projects] = await db.select({ count: sql<number>`count(*)::int` }).from(projectsTable);
  const [jobs] = await db.select({ count: sql<number>`count(*)::int` }).from(jobsTable);
  const [skills] = await db.select({ count: sql<number>`count(*)::int` }).from(skillsTable);
  const [avgScore] = await db.select({ avg: sql<number>`coalesce(avg(readiness_score)::int, 0)` }).from(studentsTable);

  res.json(GetDashboardSummaryResponse.parse({
    totalStudents: students.count,
    totalCompanies: companies.count,
    totalProjects: projects.count,
    totalJobs: jobs.count,
    avgReadinessScore: avgScore.avg,
    skillsTracked: skills.count,
  }));
});

router.get("/dashboard/student/:id", async (req, res): Promise<void> => {
  const params = GetStudentDashboardParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [student] = await db.select().from(studentsTable).where(eq(studentsTable.id, params.data.id));
  if (!student) {
    res.status(404).json({ error: "Student not found" });
    return;
  }

  const allProjects = await db.select().from(projectsTable).limit(3);
  const allJobs = await db.select().from(jobsTable).limit(3);

  const enrichedProjects = await Promise.all(allProjects.map(async p => {
    const [company] = await db.select().from(companiesTable).where(eq(companiesTable.id, p.companyId));
    return { ...p, companyName: company?.name ?? "Unknown", companyLogoUrl: company?.logoUrl ?? null, createdAt: p.createdAt.toISOString() };
  }));

  const enrichedJobs = await Promise.all(allJobs.map(async j => {
    const [company] = await db.select().from(companiesTable).where(eq(companiesTable.id, j.companyId));
    return { ...j, companyName: company?.name ?? "Unknown", companyLogoUrl: company?.logoUrl ?? null, createdAt: j.createdAt.toISOString() };
  }));

  const allSkills = await db.select().from(skillsTable).orderBy(sql`demand_score DESC`).limit(6);
  const recommendedSkills = allSkills
    .filter(s => !student.skills.includes(s.name))
    .slice(0, 4)
    .map(s => s.name);

  const careerGoal = student.careerGoal ?? "Full-Stack Developer";
  const learningPath = generateLearningPath(careerGoal, student.skills);

  res.json(GetStudentDashboardResponse.parse({
    student: { ...student, createdAt: student.createdAt.toISOString() },
    recommendedSkills,
    suggestedProjects: enrichedProjects,
    recommendedJobs: enrichedJobs,
    learningPath,
  }));
});

function generateLearningPath(careerGoal: string, currentSkills: string[]) {
  const pathMap: Record<string, Array<{ title: string; description: string; type: string; estimatedDuration: string }>> = {
    "Full-Stack Developer": [
      { title: "Master React Fundamentals", description: "Components, hooks, state management, and routing.", type: "course", estimatedDuration: "3 weeks" },
      { title: "Build REST APIs with Node.js", description: "Express, middleware, authentication, and databases.", type: "course", estimatedDuration: "2 weeks" },
      { title: "Database Design with PostgreSQL", description: "Schema design, queries, indexes, and ORMs.", type: "course", estimatedDuration: "2 weeks" },
      { title: "Build a Portfolio Project", description: "Full-stack app showcasing your skills end-to-end.", type: "project", estimatedDuration: "3 weeks" },
      { title: "AWS Cloud Basics Certification", description: "Deploy apps to the cloud with EC2, S3, and RDS.", type: "certification", estimatedDuration: "2 weeks" },
      { title: "Contribute to Open Source", description: "Make 5 meaningful contributions to GitHub projects.", type: "project", estimatedDuration: "4 weeks" },
    ],
    "Data Scientist": [
      { title: "Python for Data Science", description: "NumPy, Pandas, data wrangling, and visualization.", type: "course", estimatedDuration: "3 weeks" },
      { title: "Machine Learning Fundamentals", description: "Supervised, unsupervised learning, and model evaluation.", type: "course", estimatedDuration: "4 weeks" },
      { title: "Deep Learning with TensorFlow", description: "Neural networks, CNNs, RNNs, and transfer learning.", type: "course", estimatedDuration: "4 weeks" },
      { title: "Build an ML Portfolio Project", description: "End-to-end ML project with real dataset and deployment.", type: "project", estimatedDuration: "3 weeks" },
      { title: "Google Data Analytics Certificate", description: "Industry-recognized certification for data analytics.", type: "certification", estimatedDuration: "2 weeks" },
    ],
  };

  const path = pathMap[careerGoal] ?? pathMap["Full-Stack Developer"];
  return path.map((step, i) => ({
    step: i + 1,
    title: step.title,
    description: step.description,
    type: step.type,
    estimatedDuration: step.estimatedDuration,
    completed: i < currentSkills.length / 2,
  }));
}

export default router;
