import { Router, type IRouter } from "express";
import { eq, sql } from "drizzle-orm";
import { db } from "@workspace/db";
import { jobsTable, companiesTable, applicationsTable } from "@workspace/db";
import {
  ListJobsResponse,
  ListJobsQueryParams,
  CreateJobBody,
  GetJobParams,
  GetJobResponse,
  ApplyToJobParams,
  ApplyToJobBody,
  ApplyToJobResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

async function enrichJob(j: typeof jobsTable.$inferSelect) {
  const [company] = await db.select().from(companiesTable).where(eq(companiesTable.id, j.companyId));
  return {
    ...j,
    companyName: company?.name ?? "Unknown Company",
    companyLogoUrl: company?.logoUrl ?? null,
    createdAt: j.createdAt.toISOString(),
  };
}

router.get("/jobs", async (req, res): Promise<void> => {
  const query = ListJobsQueryParams.safeParse(req.query);
  let jobs = await db.select().from(jobsTable).orderBy(jobsTable.createdAt);
  if (query.success && query.data.type) {
    jobs = jobs.filter(j => j.type === query.data.type);
  }
  if (query.success && query.data.skill) {
    jobs = jobs.filter(j => j.requiredSkills.includes(query.data.skill as string));
  }
  const enriched = await Promise.all(jobs.map(enrichJob));
  res.json(ListJobsResponse.parse(enriched));
});

router.post("/jobs", async (req, res): Promise<void> => {
  const parsed = CreateJobBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [job] = await db.insert(jobsTable).values(parsed.data).returning();
  const enriched = await enrichJob(job);
  res.status(201).json(GetJobResponse.parse(enriched));
});

router.get("/jobs/:id", async (req, res): Promise<void> => {
  const params = GetJobParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [job] = await db.select().from(jobsTable).where(eq(jobsTable.id, params.data.id));
  if (!job) {
    res.status(404).json({ error: "Job not found" });
    return;
  }
  const enriched = await enrichJob(job);
  res.json(GetJobResponse.parse(enriched));
});

router.post("/jobs/:id/apply", async (req, res): Promise<void> => {
  const params = ApplyToJobParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = ApplyToJobBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const [application] = await db.insert(applicationsTable).values({
    studentId: body.data.studentId,
    targetId: params.data.id,
    targetType: "job",
    message: body.data.message ?? null,
    status: "pending",
  }).returning();
  await db.update(jobsTable)
    .set({ applicants: sql`${jobsTable.applicants} + 1` })
    .where(eq(jobsTable.id, params.data.id));
  res.json(ApplyToJobResponse.parse({
    ...application,
    createdAt: application.createdAt.toISOString(),
  }));
});

export default router;
