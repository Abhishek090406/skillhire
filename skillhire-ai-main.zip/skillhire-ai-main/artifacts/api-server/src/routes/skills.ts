import { Router, type IRouter } from "express";
import { desc } from "drizzle-orm";
import { db } from "@workspace/db";
import { skillsTable } from "@workspace/db";
import {
  ListSkillsResponse,
  GetTrendingSkillsResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/skills", async (req, res): Promise<void> => {
  const skills = await db.select().from(skillsTable).orderBy(skillsTable.name);
  res.json(ListSkillsResponse.parse(skills));
});

router.get("/skills/trending", async (req, res): Promise<void> => {
  const skills = await db.select().from(skillsTable).orderBy(desc(skillsTable.demandScore)).limit(10);
  const trending = skills.map(s => ({
    skill: s.name,
    category: s.category,
    demandScore: s.demandScore,
    growthPercent: Math.round((s.demandScore / 100) * 35 + Math.random() * 15),
    jobCount: Math.round(s.demandScore * 12 + Math.random() * 100),
  }));
  res.json(GetTrendingSkillsResponse.parse(trending));
});

export default router;
