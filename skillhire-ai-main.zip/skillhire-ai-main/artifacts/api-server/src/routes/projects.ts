import { Router, type IRouter } from "express";
import { eq, sql } from "drizzle-orm";
import { db } from "@workspace/db";
import { projectsTable, companiesTable, applicationsTable } from "@workspace/db";
import {
  ListProjectsResponse,
  ListProjectsQueryParams,
  CreateProjectBody,
  GetProjectParams,
  GetProjectResponse,
  ApplyToProjectParams,
  ApplyToProjectBody,
  ApplyToProjectResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

async function enrichProject(p: typeof projectsTable.$inferSelect) {
  const [company] = await db.select().from(companiesTable).where(eq(companiesTable.id, p.companyId));
  return {
    ...p,
    companyName: company?.name ?? "Unknown Company",
    companyLogoUrl: company?.logoUrl ?? null,
    createdAt: p.createdAt.toISOString(),
  };
}

router.get("/projects", async (req, res): Promise<void> => {
  const query = ListProjectsQueryParams.safeParse(req.query);
  let projects = await db.select().from(projectsTable).orderBy(projectsTable.createdAt);
  if (query.success && query.data.difficulty) {
    projects = projects.filter(p => p.difficulty === query.data.difficulty);
  }
  if (query.success && query.data.skill) {
    projects = projects.filter(p => p.requiredSkills.includes(query.data.skill as string));
  }
  const enriched = await Promise.all(projects.map(enrichProject));
  res.json(ListProjectsResponse.parse(enriched));
});

router.post("/projects", async (req, res): Promise<void> => {
  const parsed = CreateProjectBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [project] = await db.insert(projectsTable).values(parsed.data).returning();
  const enriched = await enrichProject(project);
  res.status(201).json(GetProjectResponse.parse(enriched));
});

router.get("/projects/:id", async (req, res): Promise<void> => {
  const params = GetProjectParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [project] = await db.select().from(projectsTable).where(eq(projectsTable.id, params.data.id));
  if (!project) {
    res.status(404).json({ error: "Project not found" });
    return;
  }
  const enriched = await enrichProject(project);
  res.json(GetProjectResponse.parse(enriched));
});

router.post("/projects/:id/apply", async (req, res): Promise<void> => {
  const params = ApplyToProjectParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = ApplyToProjectBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const [application] = await db.insert(applicationsTable).values({
    studentId: body.data.studentId,
    targetId: params.data.id,
    targetType: "project",
    message: body.data.message ?? null,
    status: "pending",
  }).returning();
  await db.update(projectsTable)
    .set({ applicants: sql`${projectsTable.applicants} + 1` })
    .where(eq(projectsTable.id, params.data.id));
  res.json(ApplyToProjectResponse.parse({
    ...application,
    createdAt: application.createdAt.toISOString(),
  }));
});

export default router;
