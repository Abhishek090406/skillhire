import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { skillsTable, studentsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import {
  AnalyzeSkillGapParams,
  AnalyzeSkillGapBody,
  AnalyzeSkillGapResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

const careerSkillMap: Record<string, string[]> = {
  "Full-Stack Developer": ["React", "Node.js", "TypeScript", "PostgreSQL", "REST APIs", "GraphQL", "Docker", "AWS"],
  "Frontend Developer": ["React", "TypeScript", "CSS", "Next.js", "Tailwind CSS", "Testing", "Performance Optimization"],
  "Backend Developer": ["Node.js", "Python", "PostgreSQL", "Redis", "Docker", "Kubernetes", "REST APIs", "Microservices"],
  "Data Scientist": ["Python", "Machine Learning", "TensorFlow", "Pandas", "SQL", "Statistics", "Data Visualization"],
  "DevOps Engineer": ["Docker", "Kubernetes", "AWS", "CI/CD", "Linux", "Terraform", "Monitoring"],
  "Mobile Developer": ["React Native", "Swift", "Android", "TypeScript", "REST APIs", "Firebase"],
  "Product Manager": ["Agile", "Roadmapping", "User Research", "Analytics", "SQL", "Stakeholder Management"],
};

router.post("/students/:id/skill-gap", async (req, res): Promise<void> => {
  const params = AnalyzeSkillGapParams.safeParse({ id: Number(req.params.id) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const body = AnalyzeSkillGapBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const { currentSkills, careerGoal } = body.data;

  const requiredSkills = careerSkillMap[careerGoal] ?? careerSkillMap["Full-Stack Developer"];
  const currentSet = new Set(currentSkills.map(s => s.toLowerCase()));
  const missingSkills = requiredSkills.filter(s => !currentSet.has(s.toLowerCase()));
  const matchedCount = requiredSkills.length - missingSkills.length;
  const readinessScore = Math.round((matchedCount / requiredSkills.length) * 100);

  const trendingSkills = await db.select().from(skillsTable).orderBy(desc(skillsTable.demandScore)).limit(8);
  const industryDemandSkills = trendingSkills.map(s => ({
    skill: s.name,
    demandLevel: s.demandScore,
    trend: s.demandScore > 80 ? "rising" : s.demandScore > 60 ? "stable" : "declining",
  }));

  const learningPath = missingSkills.slice(0, 6).map((skill, i) => ({
    step: i + 1,
    title: `Learn ${skill}`,
    description: `Master ${skill} through hands-on projects and structured learning resources.`,
    type: i % 3 === 0 ? "course" : i % 3 === 1 ? "project" : "certification",
    estimatedDuration: `${Math.floor(Math.random() * 3) + 1} weeks`,
    completed: false,
  }));

  const summary = readinessScore >= 80
    ? `You are highly prepared for ${careerGoal}! Focus on mastering ${missingSkills.slice(0, 2).join(" and ")} to reach expert level.`
    : readinessScore >= 50
    ? `Good progress toward ${careerGoal}. Acquiring ${missingSkills.length} more skills will significantly boost your readiness.`
    : `Starting your ${careerGoal} journey with ${matchedCount} foundational skills. Follow the learning path to build industry-ready expertise.`;

  await db.update(studentsTable)
    .set({ readinessScore, careerGoal })
    .where(eq(studentsTable.id, params.data.id));

  res.json(AnalyzeSkillGapResponse.parse({
    readinessScore,
    missingSkills,
    industryDemandSkills,
    learningPath,
    summary,
  }));
});

export default router;
