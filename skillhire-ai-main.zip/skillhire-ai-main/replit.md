# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **Frontend**: React + Vite + TailwindCSS + shadcn/ui + Recharts

## Project: SkillHire AI — Industry Readiness Platform

A full-stack platform bridging the gap between students and industry skill requirements.

### Features

1. **Landing Page** — Hero with CTA, feature sections for Skill Gap Analysis, Learning, Projects, Job Matching
2. **Student Dashboard** — Profile completion, readiness score gauge (Recharts), recommended skills, suggested projects/internships
3. **Skill Gap Analysis** — Input current skills + career goal → AI-simulated output with missing skills, industry demand chart, learning path
4. **Learning Path** — Roadmap steps with progress tracking, timeline visualization
5. **Project Marketplace** — Real-world tasks posted by companies; filter by skill/difficulty; Apply button
6. **Internship & Job Matching** — Job cards with match %, required skills, apply flow
7. **Company Dashboard** — Stats, post projects/jobs, view/filter students
8. **Student Profile** — Skills, certifications, GitHub/LinkedIn, readiness score radial chart
9. **Mentorship** — Mentor cards with expertise, ratings; request mentor modal

### Artifacts

- `artifacts/skillhire` — React + Vite frontend (port: 19900, preview path: `/`)
- `artifacts/api-server` — Express API server (port: 8080, path: `/api`)

### Database Tables

- `students` — student profiles with skills array, readiness score, career goal
- `companies` — company profiles (Google, Stripe, Figma, Vercel, OpenAI seeded)
- `projects` — project marketplace listings
- `jobs` — internship and job listings
- `mentors` — mentor profiles
- `applications` — student applications to projects and jobs
- `mentor_requests` — student mentor requests
- `skills` — skill catalog with demand scores

### Simulated AI Features

- **Skill Gap Analysis** — maps career goal to required skills, computes readiness score from current skills vs. required, generates learning path
- **Learning Path Generator** — career-goal-aware multi-step roadmap (courses, projects, certifications)
- **Trending Skills** — demand score-based ranking with growth % calculations

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally
- `pnpm --filter @workspace/skillhire run dev` — run frontend locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
