const fs = require('fs');
const path = require('path');

const schemaDir = path.join(__dirname, '../lib/db/src/schema');

function migrateFile(filePath) {
  let content = fs.readFileSync(filePath, 'utf8');

  // Replace import types that are not in sqlite-core
  content = content.replace(/serial,\s*/g, '');
  content = content.replace(/timestamp,\s*/g, '');
  content = content.replace(/boolean,\s*/g, '');
  
  // Also if they are at the end:
  content = content.replace(/,\s*serial/g, '');
  content = content.replace(/,\s*timestamp/g, '');
  content = content.replace(/,\s*boolean/g, '');

  content = content.replace(/import {([^}]*)} from "drizzle-orm\/sqlite-core";/, (match, p1) => {
    let imports = p1.split(',').map(s => s.trim()).filter(s => s.length > 0);
    if (!imports.includes('integer')) imports.push('integer');
    return `import { ${imports.join(', ')} } from "drizzle-orm/sqlite-core";`;
  });

  // Replace timestamp columns
  content = content.replace(/timestamp\(([^)]+)\)\.notNull\(\)\.defaultNow\(\)/g, "integer($1, { mode: 'timestamp' }).notNull().$defaultFn(() => new Date())");
  content = content.replace(/timestamp\(([^)]+)\)/g, "integer($1, { mode: 'timestamp' })");
  
  // Replace boolean columns
  content = content.replace(/boolean\("([^"]+)"\)/g, "integer(\"$1\", { mode: 'boolean' })");
  
  fs.writeFileSync(filePath, content, 'utf8');
  console.log(`Migrated ${filePath}`);
}

const files = fs.readdirSync(schemaDir).filter(f => f.endsWith('.ts'));

files.forEach(f => {
  migrateFile(path.join(schemaDir, f));
});

console.log("Done refactoring schemas.");
