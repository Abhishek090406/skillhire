-- SkillHire AI: Core Supabase schema for real workflow
-- Flow: Student -> GitHub Submission -> Admin Review -> Verified Skill
--
-- Assumes you already have `public.user_profiles` table (linked to auth.users) as created earlier.

-- 1) Students profile table (optional but useful)
create table if not exists public.students (
  user_id uuid primary key references auth.users (id) on delete cascade,
  name text not null default '',
  role text not null default 'student',
  skills text[] not null default '{}'::text[],
  readiness_score int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 2) GitHub submissions for verification
create table if not exists public.submissions (
  id uuid primary key default gen_random_uuid(),
  student_user_id uuid not null references auth.users (id) on delete cascade,
  project_title text not null,
  github_link text not null,
  skill text not null,
  status text not null default 'Pending', -- Pending | Approved | Rejected
  score integer not null default 0,
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);

-- If the table already existed without score, add the column (safe to re-run).
alter table public.submissions add column if not exists score integer not null default 0;

-- 3) Verified skills (proof awarded by admin)
create table if not exists public.verified_skills (
  id uuid primary key default gen_random_uuid(),
  student_user_id uuid not null references auth.users (id) on delete cascade,
  skill text not null,
  created_at timestamptz not null default now()
);

-- 4) Applications (minimal pipeline table)
create table if not exists public.applications (
  id uuid primary key default gen_random_uuid(),
  student_user_id uuid not null references auth.users (id) on delete cascade,
  job_title text not null,
  status text not null default 'Applied', -- Applied | Under Review | Approved | Rejected
  github_link text,
  portfolio_link text,
  created_at timestamptz not null default now()
);

-- Enable RLS
alter table public.students enable row level security;
alter table public.submissions enable row level security;
alter table public.verified_skills enable row level security;
alter table public.applications enable row level security;

-- Helper: company/admin check using user_profiles.role = 'company'
-- NOTE: You must have public.user_profiles(user_id, role)

-- STUDENTS policies
drop policy if exists "students_select_own" on public.students;
create policy "students_select_own"
on public.students for select
to authenticated
using (auth.uid() = user_id);

drop policy if exists "students_upsert_own" on public.students;
create policy "students_upsert_own"
on public.students for insert
to authenticated
with check (auth.uid() = user_id);

drop policy if exists "students_update_own" on public.students;
create policy "students_update_own"
on public.students for update
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

-- SUBMISSIONS policies
drop policy if exists "submissions_insert_own" on public.submissions;
create policy "submissions_insert_own"
on public.submissions for insert
to authenticated
with check (auth.uid() = student_user_id);

drop policy if exists "submissions_select_own" on public.submissions;
create policy "submissions_select_own"
on public.submissions for select
to authenticated
using (auth.uid() = student_user_id);

drop policy if exists "submissions_select_company" on public.submissions;
create policy "submissions_select_company"
on public.submissions for select
to authenticated
using (
  exists (
    select 1 from public.user_profiles up
    where up.user_id = auth.uid() and up.role = 'company'
  )
);

drop policy if exists "submissions_update_company" on public.submissions;
create policy "submissions_update_company"
on public.submissions for update
to authenticated
using (
  exists (
    select 1 from public.user_profiles up
    where up.user_id = auth.uid() and up.role = 'company'
  )
)
with check (
  exists (
    select 1 from public.user_profiles up
    where up.user_id = auth.uid() and up.role = 'company'
  )
);

-- Allow company to delete demo rows (for reset button)
drop policy if exists "submissions_delete_company" on public.submissions;
create policy "submissions_delete_company"
on public.submissions for delete
to authenticated
using (
  exists (
    select 1 from public.user_profiles up
    where up.user_id = auth.uid() and up.role = 'company'
  )
);

-- VERIFIED_SKILLS policies
drop policy if exists "verified_skills_select_own" on public.verified_skills;
create policy "verified_skills_select_own"
on public.verified_skills for select
to authenticated
using (auth.uid() = student_user_id);

drop policy if exists "verified_skills_select_company" on public.verified_skills;
create policy "verified_skills_select_company"
on public.verified_skills for select
to authenticated
using (
  exists (
    select 1 from public.user_profiles up
    where up.user_id = auth.uid() and up.role = 'company'
  )
);

drop policy if exists "verified_skills_insert_company" on public.verified_skills;
create policy "verified_skills_insert_company"
on public.verified_skills for insert
to authenticated
with check (
  exists (
    select 1 from public.user_profiles up
    where up.user_id = auth.uid() and up.role = 'company'
  )
);

-- APPLICATIONS policies
drop policy if exists "applications_insert_own" on public.applications;
create policy "applications_insert_own"
on public.applications for insert
to authenticated
with check (auth.uid() = student_user_id);

drop policy if exists "applications_select_own" on public.applications;
create policy "applications_select_own"
on public.applications for select
to authenticated
using (auth.uid() = student_user_id);

drop policy if exists "applications_select_company" on public.applications;
create policy "applications_select_company"
on public.applications for select
to authenticated
using (
  exists (
    select 1 from public.user_profiles up
    where up.user_id = auth.uid() and up.role = 'company'
  )
);

drop policy if exists "applications_update_company" on public.applications;
create policy "applications_update_company"
on public.applications for update
to authenticated
using (
  exists (
    select 1 from public.user_profiles up
    where up.user_id = auth.uid() and up.role = 'company'
  )
)
with check (
  exists (
    select 1 from public.user_profiles up
    where up.user_id = auth.uid() and up.role = 'company'
  )
);

-- Allow company to delete demo rows (for reset button)
drop policy if exists "applications_delete_company" on public.applications;
create policy "applications_delete_company"
on public.applications for delete
to authenticated
using (
  exists (
    select 1 from public.user_profiles up
    where up.user_id = auth.uid() and up.role = 'company'
  )
);

