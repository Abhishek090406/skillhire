import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const applicationsTable = sqliteTable("applications", {
  id: integer("id").primaryKey({ autoincrement: true }),
  studentId: integer("student_id").notNull(),
  targetId: integer("target_id").notNull(),
  targetType: text("target_type").notNull(),
  status: text("status").notNull().default("pending"),
  message: text("message"),
  createdAt: integer("created_at", { withTimezone: true }, { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
});

export const mentorRequestsTable = sqliteTable("mentor_requests", {
  id: integer("id").primaryKey({ autoincrement: true }),
  mentorId: integer("mentor_id").notNull(),
  studentId: integer("student_id").notNull(),
  message: text("message").notNull(),
  topic: text("topic").notNull(),
  status: text("status").notNull().default("pending"),
  createdAt: integer("created_at", { withTimezone: true }, { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
});

export const insertApplicationSchema = createInsertSchema(applicationsTable).omit({ id: true, createdAt: true });
export type InsertApplication = z.infer<typeof insertApplicationSchema>;
export type Application = typeof applicationsTable.$inferSelect;

export const insertMentorRequestSchema = createInsertSchema(mentorRequestsTable).omit({ id: true, createdAt: true });
export type InsertMentorRequest = z.infer<typeof insertMentorRequestSchema>;
export type MentorRequest = typeof mentorRequestsTable.$inferSelect;
