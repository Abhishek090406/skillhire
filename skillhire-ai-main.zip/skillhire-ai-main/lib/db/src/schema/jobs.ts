import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const jobsTable = sqliteTable("jobs", {
  id: integer("id").primaryKey({ autoincrement: true }),
  title: text("title").notNull(),
  companyId: integer("company_id").notNull(),
  type: text("type").notNull().default("internship"),
  location: text("location"),
  remote: integer("remote", { mode: 'boolean' }).notNull().default(false),
  requiredSkills: text("required_skills").array().notNull().default([]),
  stipend: text("stipend"),
  description: text("description").notNull(),
  applicants: integer("applicants").notNull().default(0),
  status: text("status").notNull().default("open"),
  createdAt: integer("created_at", { withTimezone: true }, { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
});

export const insertJobSchema = createInsertSchema(jobsTable).omit({
  id: true,
  createdAt: true,
  applicants: true,
});
export type InsertJob = z.infer<typeof insertJobSchema>;
export type Job = typeof jobsTable.$inferSelect;
