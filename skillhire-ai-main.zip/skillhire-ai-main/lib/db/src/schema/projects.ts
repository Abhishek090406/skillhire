import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const projectsTable = sqliteTable("projects", {
  id: integer("id").primaryKey({ autoincrement: true }),
  title: text("title").notNull(),
  description: text("description").notNull(),
  companyId: integer("company_id").notNull(),
  requiredSkills: text("required_skills").array().notNull().default([]),
  difficulty: text("difficulty").notNull().default("intermediate"),
  duration: text("duration").notNull(),
  reward: text("reward"),
  certificate: integer("certificate", { mode: 'boolean' }).notNull().default(false),
  applicants: integer("applicants").notNull().default(0),
  status: text("status").notNull().default("open"),
  createdAt: integer("created_at", { withTimezone: true }, { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
});

export const insertProjectSchema = createInsertSchema(projectsTable).omit({
  id: true,
  createdAt: true,
  applicants: true,
});
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projectsTable.$inferSelect;
