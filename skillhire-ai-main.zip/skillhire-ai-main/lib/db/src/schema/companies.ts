import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const companiesTable = sqliteTable("companies", {
  id: integer("id").primaryKey({ autoincrement: true }),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  industry: text("industry").notNull(),
  logoUrl: text("logo_url"),
  description: text("description"),
  website: text("website"),
  location: text("location"),
  size: text("size"),
  createdAt: integer("created_at", { withTimezone: true }, { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
});

export const insertCompanySchema = createInsertSchema(companiesTable).omit({
  id: true,
  createdAt: true,
});
export type InsertCompany = z.infer<typeof insertCompanySchema>;
export type Company = typeof companiesTable.$inferSelect;
