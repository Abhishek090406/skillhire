import { sqliteTable, text, integer, real } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const mentorsTable = sqliteTable("mentors", {
  id: integer("id").primaryKey({ autoincrement: true }),
  name: text("name").notNull(),
  title: text("title").notNull(),
  company: text("company").notNull(),
  avatarUrl: text("avatar_url"),
  expertise: text("expertise").array().notNull().default([]),
  bio: text("bio"),
  rating: real("rating").notNull().default(5.0),
  sessionCount: integer("session_count").notNull().default(0),
  available: integer("available", { mode: 'boolean' }).notNull().default(true),
  createdAt: integer("created_at", { withTimezone: true }, { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
});

export const insertMentorSchema = createInsertSchema(mentorsTable).omit({
  id: true,
  createdAt: true,
});
export type InsertMentor = z.infer<typeof insertMentorSchema>;
export type Mentor = typeof mentorsTable.$inferSelect;
