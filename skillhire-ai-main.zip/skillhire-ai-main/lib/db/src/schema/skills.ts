import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const skillsTable = sqliteTable("skills", {
  id: integer("id").primaryKey({ autoincrement: true }),
  name: text("name").notNull().unique(),
  category: text("category").notNull(),
  demandScore: integer("demand_score").notNull().default(50),
});

export const insertSkillSchema = createInsertSchema(skillsTable).omit({ id: true });
export type InsertSkill = z.infer<typeof insertSkillSchema>;
export type Skill = typeof skillsTable.$inferSelect;
