import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const studentsTable = sqliteTable("students", {
  id: integer("id").primaryKey({ autoincrement: true }),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  avatarUrl: text("avatar_url"),
  bio: text("bio"),
  skills: text("skills").array().notNull().default([]),
  careerGoal: text("career_goal"),
  readinessScore: integer("readiness_score").notNull().default(0),
  profileCompletion: integer("profile_completion").notNull().default(0),
  githubUrl: text("github_url"),
  linkedinUrl: text("linkedin_url"),
  certifications: text("certifications").array().notNull().default([]),
  completedProjects: integer("completed_projects").notNull().default(0),
  createdAt: integer("created_at", { withTimezone: true }, { mode: 'timestamp' }).notNull().$defaultFn(() => new Date()),
});

export const insertStudentSchema = createInsertSchema(studentsTable).omit({
  id: true,
  createdAt: true,
});
export type InsertStudent = z.infer<typeof insertStudentSchema>;
export type Student = typeof studentsTable.$inferSelect;
